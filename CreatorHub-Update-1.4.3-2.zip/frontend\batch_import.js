// V1.3 批量导入：标准模板下载 → 上传 → 字段映射 → 预览去重 → 授权确认 → 分批写入
const SAMPLE_POLICY_HINT = "公开渠道获取的商务合作资料，仅用于内部选号与提报";
const state = {
  upload: null, mapping: {}, preview: null, fields: [], templates: [], projects: [],
  file: null, committed: null,
};

const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = v => (v == null || v === "" ? "0" : Number(v).toLocaleString("zh-CN"));
const metricVal = v => (v == null || v === "" ? "未知" : Number(v).toLocaleString("zh-CN"));
const iso = d => d.toISOString().slice(0, 10);
const plus = n => iso(new Date(Date.now() + n * 86400000));

function stats(counts, total) {
  const cells = [
    ["总数据行", total, "total"],
    ["预计新增", counts.to_add, "add"],
    ["预计更新已有", counts.to_update, "update"],
    ["表内重复去重", counts.in_file_duplicates, "dup"],
    ["无变化跳过", counts.unchanged, "skip"],
    ["错误行隔离", counts.errors, "error"],
  ];
  return '<div class="stat-row">' + cells.map(([label, value, kind]) =>
    '<div class="stat ' + kind + '"><b>' + num(value) + "</b><span>" + esc(label) + "</span></div>").join("") + "</div>";
}

function mappingRows() {
  const headers = state.upload ? state.upload.headers : [];
  const preview = state.preview || {};
  const sample = {};
  (preview.sample_rows || []).forEach(row => { });
  return headers.map(header => {
    const field = state.mapping[header] || "";
    const chip = field ? '<span class="chip good">已识别</span>' : '<span class="chip bad">未映射 · 默认忽略</span>';
    return "<tr><td><code>" + esc(header) + "</code><br>" + chip + "</td>" +
      '<td><select data-map="' + esc(header) + '">' +
      '<option value="">忽略此列</option>' +
      state.fields.map(item => '<option value="' + esc(item.field) + '"' + (item.field === field ? " selected" : "") + ">" +
        esc(item.zh) + " · " + esc(item.en) + "</option>").join("") +
      "</select></td></tr>";
  }).join("");
}

function errorRows() {
  const preview = state.preview;
  if (!preview) return "";
  const errors = preview.errors || [];
  const duplicates = preview.duplicates || [];
  if (!errors.length && !duplicates.length) return "";
  let html = "";
  if (errors.length) {
    html += '<div class="panel"><h3>错误行定位（共 ' + num(preview.total_errors) + " 行）</h3><table><thead><tr><th>行号</th><th>原始值</th><th>原因</th></tr></thead><tbody>" +
      errors.slice(0, 60).map(e => "<tr><td>第 " + e.line + " 行</td><td><code>" + esc(e.raw) + "</code></td><td>" + esc(e.reason) + "</td></tr>").join("") +
      "</tbody></table></div>";
  }
  if (duplicates.length) {
    html += '<div class="panel"><h3>表内重复</h3><p class="hint">' +
      duplicates.slice(0, 40).map(d => "第 " + d.line + " 行与第 " + d.first_line + " 行重复（" + esc(d.platform) + " " + esc(d.account_id) + "）").join("；") +
      "</p></div>";
  }
  return html;
}

function sampleTable() {
  const preview = state.preview;
  if (!preview || !preview.sample_rows.length) return "";
  const label = { to_add: "新增", to_update: "更新已有", unchanged: "无变化" };
  return '<div class="panel table-card"><div class="card-head"><h3>导入动作预览（前 ' + preview.sample_rows.length + " 行）</h3></div>" +
    '<div class="table-scroll"><table><thead><tr><th>行号</th><th>动作</th><th>平台</th><th>账号</th><th>昵称</th><th>粉丝量</th><th>字段变化</th></tr></thead><tbody>' +
    preview.sample_rows.map(row => "<tr><td>第 " + row.line + " 行</td><td><span class=\"chip " +
      (row.action === "to_add" ? "good" : row.action === "to_update" ? "" : "bad") + "\">" + label[row.action] + "</span></td><td>" +
      esc(row.platform) + "</td><td><code>" + esc(row.account_id) + "</code></td><td>" + esc(row.display_name || "") +
      "</td><td>" + metricVal(row.followers) + "</td><td>" + (row.changed && row.changed.length ? "更新: " + esc(row.changed.join(", ")) : "—") +
      "</td></tr>").join("") + "</tbody></table></div></div>";
}

export async function batchImportPage(main, api, toast) {
  const [fieldData, projects] = await Promise.all([
    api("/imports/fields").catch(() => ({ catalog: [], templates: [] })),
    api("/projects").catch(() => []),
  ]);
  state.fields = fieldData.catalog || [];
  state.templates = fieldData.templates || [];
  state.projects = Array.isArray(projects) ? projects : [];

  main.innerHTML =
    '<section class="hero"><div><h1>批量导入与更新达人</h1>' +
    "<p>下载标准 Excel 模板，填好后一次导入数千行；系统自动识别中英文表头、去重、定位错误行，并保护已有人工报价与合作记录。</p></div>" +
    '<div class="hero-summary"><a class="btn primary" href="/api/imports/template" download="CreatorHub-Import-Template-V1.3.xlsx">下载标准模板 .xlsx</a>' +
    '<a class="btn" href="/api/imports/template?examples=1" download="CreatorHub-Import-Template-Examples-V1.3.xlsx">含示例模板</a></div></section>' +

    '<section class="panel" id="batch-links-panel"><h2>0. 批量链接导入与自动补全（无需模板）</h2>' +
    '<p class="hint">每行粘贴一个达人主页链接（YouTube / TikTok / Instagram / X），系统自动识别平台与账号、去重入库，并尝试通过合规公开渠道（如 YouTube 官方 RSS）补全资料；即使补全失败或资料缺失也会正常入库。</p>' +
    '<label class="field">达人主页链接（每行一条，最多 500 条）<textarea id="batch-links-text" rows="5" placeholder="https://www.youtube.com/@handle&#10;https://www.tiktok.com/@creator&#10;https://www.instagram.com/creator/"></textarea></label>' +
    '<div class="actions"><label class="field">BD（可选，不填不分配）<input id="batch-links-bd" maxlength="120" placeholder="负责人姓名"></label>' +
    '<label class="field">写入项目<select id="batch-links-project"><option value="">仅写入达人总库</option>' +
    state.projects.map(p => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join("") + "</select></label>" +
    '<label class="option"><input type="checkbox" id="batch-links-enrich" checked> 自动补全公开资料</label>' +
    '<button class="primary" id="batch-links-submit" type="button">识别链接并入库</button></div>' +
    '<div id="batch-links-result"></div></section>' +

    '<section class="panel"><h2>1. 上传 Excel / CSV</h2>' +
    '<p class="hint">支持 .xlsx、.csv（UTF-8 / GBK）、.tsv，单次 5,000+ 行自动分批；单文件上限 20MB、20,000 行。</p>' +
    '<div class="actions"><label class="field">选择文件<input id="batch-file" type="file" accept=".xlsx,.csv,.tsv"></label>' +
    '<label class="field">工作表<select id="batch-sheet"><option value="">默认</option></select></label>' +
    '<label class="field">映射模板<select id="batch-preset"><option value="">不使用</option></select></label></div>' +
    '<div class="actions"><span class="hint" id="batch-upload-hint">尚未上传文件</span></div></section>' +

    '<section class="panel" id="batch-map-panel" hidden><h2>2. 字段识别与映射</h2>' +
    '<div class="table-scroll"><table><thead><tr><th>上传列</th><th>映射到系统字段</th></tr></thead><tbody id="batch-map-rows"></tbody></table></div>' +
    '<div class="actions"><label class="option"><input type="checkbox" id="batch-update-existing" checked> 已存在达人：批量更新非空字段（空单元格不覆盖）</label>' +
    '<label class="option"><input type="checkbox" id="batch-preserve-manual" checked> 保留已有一轮报价、合作记录与原有授权</label></div>' +
    '<div class="actions"><label class="field">默认报价币种<input id="batch-currency" value="USD" maxlength="3"></label>' +
    '<label class="field">写入项目<select id="batch-project"><option value="">仅更新达人总库</option>' +
    state.projects.map(p => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join("") + "</select></label>" +
    '<button class="primary" id="batch-repreview">重新校验与预览</button></div></section>' +

    '<section id="batch-preview"></section>' +

    '<section class="panel" id="batch-commit-panel" hidden><h2>3. 确认并写入</h2>' +
    '<details class="stack"><summary>可选：补充数据来源与授权说明（默认自动记录文件名）</summary>' +
    '<div class="actions"><label class="field">来源类型<select id="batch-source"><option value="independent">独立公开资料</option><option value="authorized">授权导入</option></select></label>' +
    '<label class="field">来源名称<input id="batch-source-name" placeholder="默认自动记录导入文件名"></label>' +
    '<label class="field">授权依据<input id="batch-permission" placeholder="可选，默认：默认导入（本地业务资料整理）"></label></div>' +
    '<div class="actions"><label class="field">删除责任人<input id="batch-owner" placeholder="可选，默认：operator"></label>' +
    '<label class="field">获取日期<input id="batch-acquired" type="date" value="' + iso(new Date()) + '"></label>' +
    '<label class="field">生效日期<input id="batch-effective" type="date" value="' + iso(new Date()) + '"></label>' +
    '<label class="field">保存截止<input id="batch-expires" type="date" value="' + plus(365) + '"></label></div>' +
    '<div class="actions"><label class="option"><input type="checkbox" data-purpose="view" checked> 查看</label>' +
    '<label class="option"><input type="checkbox" data-purpose="tag" checked> 标签</label>' +
    '<label class="option"><input type="checkbox" data-purpose="match" checked> 匹配</label>' +
    '<label class="option"><input type="checkbox" data-purpose="export" checked> 导出与提报</label></div></details>' +
    '<div class="actions"><button class="primary" id="batch-commit">确认批量导入</button>' +
    '<span class="hint">无需额外填写即可直接导入；分批写入每批 500 行，错误行自动隔离。</span></div>' +
    '<div id="batch-progress" hidden><progress aria-label="导入进度"></progress><span class="hint" id="batch-progress-text">正在分批写入，请稍候…</span></div>' +
    '<div id="batch-receipt"></div></section>';

  const $ = s => main.querySelector(s);

  $("#batch-links-submit").addEventListener("click", async () => {
    const linksText = ($("#batch-links-text").value || "").trim();
    if (!linksText) {
      toast("请先输入至少 1 条达人主页链接");
      return;
    }
    const btn = $("#batch-links-submit");
    btn.disabled = true;
    $("#batch-links-result").innerHTML = '<p class="hint">正在识别平台、去重并尝试补全公开资料，请稍候…</p>';
    try {
      const projVal = $("#batch-links-project").value;
      const res = await api("/imports/batch-links", "POST", {
        links_text: linksText,
        bd: ($("#batch-links-bd").value || "").trim(),
        project_id: projVal ? Number(projVal) : null,
        enrich: $("#batch-links-enrich").checked,
      });
      const rejectedHtml = (res.rejected && res.rejected.length)
        ? '<ul class="evidence-list">' + res.rejected.map(r => '<li>第 ' + r.line + ' 行 · ' + esc(r.url) + ' · ' + esc(r.reason) + '</li>').join("") + '</ul>'
        : "";
      const itemsHtml = (res.items && res.items.length)
        ? '<div class="table-scroll"><table><thead><tr><th>行号</th><th>平台</th><th>账号</th><th>昵称</th><th>动作</th><th>补全状态</th></tr></thead><tbody>' +
          res.items.slice(0, 50).map(it => '<tr><td>第 ' + it.line + ' 行</td><td>' + esc(it.platform) + '</td><td><code>' + esc(it.identifier) + '</code></td><td>' + esc(it.display_name || "—") + '</td><td>' + esc(it.action) + '</td><td>' + esc(it.enrich_note || it.enrich_status) + '</td></tr>').join("") +
          '</tbody></table></div>'
        : "";
      $("#batch-links-result").innerHTML =
        '<p class="callout">共 ' + num(res.total) + ' 条 · 新增 ' + num(res.added) + ' · 更新 ' + num(res.updated) +
        ' · 重复 ' + num(res.duplicates) + ' · 补全成功 ' + num(res.enriched) +
        ' · 补全失败(仍已入库) ' + num(res.enrich_failed) + ' · 无效 ' + num((res.rejected || []).length) + '</p>' +
        rejectedHtml + itemsHtml;
      toast("批量链接导入完成");
    } catch (err) {
      $("#batch-links-result").innerHTML = '<p class="callout warn">' + esc(err.message || "批量链接导入失败") + '</p>';
    } finally {
      btn.disabled = false;
    }
  });

  const render = () => {
    if (!state.upload) return;
    $("#batch-map-panel").hidden = false;
    $("#batch-map-rows").innerHTML = mappingRows();
    const preview = state.preview;
    if (!preview) return;
    $("#batch-preview").innerHTML = stats(preview.counts, preview.total_rows) + errorRows() + sampleTable();
    $("#batch-commit-panel").hidden = false;
  };

  $("#batch-file").addEventListener("change", async event => {
    const file = event.target.files[0];
    if (!file) return;
    state.file = file;
    $("#batch-upload-hint").textContent = "正在上传解析…";
    try {
      const response = await fetch("/api/imports/upload?filename=" + encodeURIComponent(file.name), {
        method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: file,
      });
      const data = await response.json();
      if (!response.ok) throw Error(typeof data.detail === "string" ? data.detail : "上传失败");
      state.upload = data;
      state.mapping = { ...data.auto_mapping };
      state.preview = data.preview;
      $("#batch-sheet").innerHTML = '<option value="">默认</option>' +
        data.sheets.map(name => '<option value="' + esc(name) + '"' + (name === data.selected_sheet ? " selected" : "") + ">" + esc(name) + "</option>").join("");
      $("#batch-upload-hint").textContent = data.filename + " · " + data.headers.length + " 列 · " + data.preview.total_rows + " 行数据";
      render();
      toast("已解析 " + data.preview.total_rows + " 行");
    } catch (error) {
      $("#batch-upload-hint").textContent = "上传失败";
      toast(error.message, true);
    }
  });

  main.addEventListener("change", event => {
    const header = event.target.dataset && event.target.dataset.map;
    if (header !== undefined) {
      state.mapping[header] = event.target.value;
    }
    if (event.target.id === "batch-confirm") {
      $("#batch-commit").disabled = !event.target.checked;
    }
  });

  $("#batch-repreview").addEventListener("click", async () => {
    try {
      const body = {
        upload_id: state.upload.upload_id,
        sheet: $("#batch-sheet").value,
        mapping: state.mapping,
        update_existing: $("#batch-update-existing").checked,
        preserve_manual_fields: $("#batch-preserve-manual").checked,
        default_currency: ($("#batch-currency").value || "USD").toUpperCase(),
      };
      const preview = await api("/imports/preview", "POST", body);
      state.preview = preview;
      render();
      toast("预览已更新");
    } catch (error) { toast(error.message, true); }
  });

  $("#batch-commit").addEventListener("click", async event => {
    event.target.disabled = true;
    const progressBox = $("#batch-progress");
    const progressText = $("#batch-progress-text");
    const totalExpected = state.preview ? state.preview.total_rows : 0;
    const estBatches = Math.max(1, Math.ceil(totalExpected / 500));
    progressBox.hidden = false;
    progressText.textContent = "正在分批写入（共 " + num(totalExpected) + " 行，预计 " + estBatches + " 批，每批 500 行），请勿关闭页面…";
    try {
      const purposes = [...main.querySelectorAll("[data-purpose]")].filter(box => box.checked).map(box => box.dataset.purpose);
      const mapping = state.mapping;
      const fields = [...new Set(Object.values(mapping).filter(Boolean))];
      const sourceName = $("#batch-source-name").value.trim();
      const permission = $("#batch-permission").value.trim();
      const owner = $("#batch-owner").value.trim();
      const hasCustomPolicy = Boolean(sourceName || permission || owner);
      const policy = hasCustomPolicy ? {
        source_name: sourceName || (state.upload && state.upload.filename) || "本地表格导入",
        permission: permission || "默认导入（本地业务资料整理）",
        deletion_owner: owner || "operator",
        effective_on: $("#batch-effective").value,
        acquired_on: $("#batch-acquired").value,
        expires_on: $("#batch-expires").value,
        allowed_fields: [...new Set([...fields, "platform", "account_id", "url"])],
        purposes: purposes.length ? purposes : ["view", "tag", "match", "export"],
      } : null;
      const body = {
        upload_id: state.upload.upload_id,
        sheet: $("#batch-sheet").value,
        mapping,
        update_existing: $("#batch-update-existing").checked,
        preserve_manual_fields: $("#batch-preserve-manual").checked,
        default_currency: ($("#batch-currency").value || "USD").toUpperCase(),
        source: $("#batch-source").value,
        confirmed: true,
        project_id: Number($("#batch-project").value) || null,
        policy,
      };
      const receipt = await api("/imports/commit", "POST", body);
      state.committed = receipt;
      const successCount = (receipt.added || 0) + (receipt.updated || 0);
      $("#batch-receipt").innerHTML =
        '<div class="panel"><h3>导入完成</h3><p>成功处理 <b>' + num(successCount) + '</b> 条（新增 <b>' + num(receipt.added) + "</b> · 更新已有 <b>" + num(receipt.updated) +
        "</b>）· 表内去重 <b>" + num(receipt.in_file_duplicates) + "</b> 条 · 无变化 <b>" + num(receipt.unchanged) +
        "</b> 条 · 失败隔离 <b>" + num(receipt.rejected.length) + "</b> 条 · 内部批次 <b>" + receipt.chunks +
        "</b> 批 · 耗时 <b>" + receipt.elapsed_ms + " ms</b> · 回执 <code>#" + esc(receipt.batch_id) + "</code></p>" +
        "<p class=\"hint\">保留人工报价 " + num(receipt.preserved_quotes) + " 条、合作记录 " + num(receipt.preserved_collaborations) +
        " 条。</p><div class=\"actions\"><a class=\"btn\" href=\"#library\">查看达人总库</a><a class=\"btn\" href=\"#intake\">前往提报</a></div></div>";
      toast("批量导入完成");
    } catch (error) { toast(error.message, true); }
    finally { progressBox.hidden = true; event.target.disabled = false; }
  });
}
