"""V1.3 batch import: standard template, staged upload, preview and chunked commit.

The module deliberately reuses the existing governed-import pipeline so that
batch uploads obey exactly the same permission, identity and normalisation
rules as the single-file intake flow.
"""
from __future__ import annotations

import csv
import io
import re
import secrets
import time
from datetime import date, datetime, timedelta
from decimal import Decimal
from urllib.parse import urlsplit

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from pydantic import BaseModel, Field

from . import discovery
from . import freshness
from .domain import COUNTRIES, LANGUAGES, PLATFORMS, count, detect_platform_from_url, identity, rules
from .imports import (FIELD_CATALOG, FIELD_KEYS, FIELD_LABELS, FIELD_NOTES, FIELDS,
                      parse_quote, resolve_header)
from .permissions import (DEPENDENCIES, IDENTITY, ImportPolicy, active_fields,
                          governed_profile, prepare_policy)
from .store import dump, load, now

MAX_BYTES = 20 * 1024 * 1024
MAX_ROWS = 20_000
CHUNK_SIZE = 500
TTL_SECONDS = 30 * 60
MAX_UPLOADS = 8
HEADER_ROW = 1
ZERO_VALID = {"0"}
UNKNOWN_TOKENS = {"", "未知", "暂无", "待定", "n/a", "na", "—", "-", "--", "null", "none"}
NUMERIC_FIELDS = {"followers", "views", "recent_average", "recent_median", "recent_count",
                  "followers_k", "views_k"}

HEADERS = [zh for _key, zh, _en, _req, _ex in FIELD_CATALOG]
CATALOG_BY_KEY = {key: {"field": key, "zh": zh, "en": en, "required": req, "example": ex,
                        "note": FIELD_NOTES.get(key, "")}
                  for key, zh, en, req, ex in FIELD_CATALOG}


class TemplateRequest(BaseModel):
    examples: bool = False


class PreviewRequest(BaseModel):
    upload_id: str = Field(min_length=4, max_length=64)
    sheet: str = Field(default="", max_length=80)
    mapping: dict[str, str] = Field(default_factory=dict, max_length=200)
    update_existing: bool = True
    preserve_manual_fields: bool = True
    default_currency: str = Field(default="USD", pattern=r"^[A-Z]{3}$")


class CommitRequest(PreviewRequest):
    source: str = Field(default="independent", pattern="^(independent|authorized)$")
    policy: ImportPolicy | None = None
    confirmed: bool = True
    project_id: int | None = None
    template_name: str = Field(default="", max_length=80)


# ---------------------------------------------------------------- template
def _style_header(sheet, columns):
    fill = PatternFill("solid", fgColor="E4F0E7")
    for index, (width, _title) in enumerate(columns, start=1):
        cell = sheet.cell(row=HEADER_ROW, column=index)
        cell.font = Font(bold=True)
        cell.fill = fill
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        sheet.column_dimensions[get_column_letter(index)].width = width
    sheet.freeze_panes = "A2"


def build_template_xlsx(*, include_examples: bool = False) -> bytes:
    book = Workbook()
    sheet = book.active
    sheet.title = "达人导入模板"
    for index, header in enumerate(HEADERS, start=1):
        sheet.cell(row=HEADER_ROW, column=index, value=header)
    widths = [(12, "平台"), (20, "账号ID"), (42, "主页链接"), (20, "达人昵称"), (10, "国家"),
              (10, "语种"), (12, "粉丝量"), (12, "均播"), (20, "最近10条平均播放量"),
              (20, "最近10条中位播放量"), (26, "逐条播放量"), (12, "统计样本数"), (20, "统计范围"),
              (18, "实际商务一轮报价"), (16, "工具预估报价"), (22, "合作记录"), (26, "联系方式"),
              (12, "邮箱状态"), (34, "邮箱来源"), (12, "账号类型"), (30, "简介"), (30, "近期内容"),
              (40, "近期内容链接"), (18, "平台Tag"), (24, "粉丝画像"), (34, "画像来源"), (18, "账号别名"), (16, "BD")]
    _style_header(sheet, widths)
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(HEADERS))}1"
    platform_dv = DataValidation(type="list", formula1='"YouTube,Instagram,TikTok,X"', allow_blank=True)
    state_dv = DataValidation(type="list", formula1='"verified,not_found,manual,unavailable"', allow_blank=True)
    sheet.add_data_validation(platform_dv)
    sheet.add_data_validation(state_dv)
    platform_index = HEADERS.index("平台") + 1
    state_index = HEADERS.index("邮箱状态") + 1
    platform_dv.add(f"{get_column_letter(platform_index)}2:{get_column_letter(platform_index)}2001")
    state_dv.add(f"{get_column_letter(state_index)}2:{get_column_letter(state_index)}2001")

    if include_examples:
        examples = [
            {"平台": "YouTube", "账号ID": "@synthetic_demo_yt",
             "主页链接": "https://www.youtube.com/@synthetic_demo_yt", "达人昵称": "Synthetic Demo YT",
             "国家": "US", "语种": "en", "粉丝量": "125000", "均播": "18000",
             "最近10条平均播放量": "15400", "实际商务一轮报价": "USD 1200",
             "合作记录": "2026Q3 已合作", "联系方式": "demo@example.invalid",
             "邮箱状态": "manual", "邮箱来源": "https://example.invalid/about"},
            {"平台": "Instagram", "账号ID": "synthetic_demo_ig",
             "主页链接": "https://www.instagram.com/synthetic_demo_ig/", "达人昵称": "Synthetic Demo IG",
             "国家": "GB", "语种": "en", "粉丝量": "5.95K", "均播": "3200",
             "实际商务一轮报价": "USD 800", "联系方式": "hello@example.invalid",
             "邮箱状态": "manual", "邮箱来源": "https://example.invalid/contact"},
        ]
        for offset, item in enumerate(examples, start=2):
            for index, header in enumerate(HEADERS, start=1):
                sheet.cell(row=offset, column=index, value=item.get(header, ""))

    guide = book.create_sheet("字段说明与中英文对照")
    titles = ["中文字段", "English", "必填", "示例", "说明"]
    for index, title in enumerate(titles, start=1):
        guide.cell(row=1, column=index, value=title)
    _style_header(guide, [(18, ""), (26, ""), (8, ""), (28, ""), (56, "")])
    for row_index, (key, zh, en, required, example) in enumerate(FIELD_CATALOG, start=2):
        guide.cell(row=row_index, column=1, value=zh)
        guide.cell(row=row_index, column=2, value=en)
        guide.cell(row=row_index, column=3, value="是" if required else "否")
        guide.cell(row=row_index, column=4, value=example)
        note = FIELD_NOTES.get(key, "")
        if key in ("display_name", "country", "language", "email"):
            note = (note + " 空单元格不会覆盖已有有效数据").strip()
        guide.cell(row=row_index, column=5, value=note)
    guide.cell(row=len(FIELD_CATALOG) + 3, column=1,
               value="空单元格绝不覆盖已有有效数据；默认保留已有人工报价、合作记录及原有授权信息。")

    buffer = io.BytesIO()
    book.save(buffer)
    return buffer.getvalue()


# ------------------------------------------------------------ upload cache
class UploadStore:
    """Bounded in-memory staging so preview remaps never require a re-upload."""

    def __init__(self):
        self._items: dict[str, dict] = {}

    def _prune(self):
        cutoff = time.time() - TTL_SECONDS
        for key in [k for k, v in self._items.items() if v["created"] < cutoff]:
            self._items.pop(key, None)
        while len(self._items) >= MAX_UPLOADS:
            oldest = min(self._items, key=lambda k: self._items[k]["created"])
            self._items.pop(oldest, None)

    def put(self, record: dict) -> str:
        self._prune()
        upload_id = secrets.token_urlsafe(12)
        record["created"] = time.time()
        self._items[upload_id] = record
        return upload_id

    def get(self, upload_id: str) -> dict:
        record = self._items.get(upload_id)
        if not record or record["created"] < time.time() - TTL_SECONDS:
            raise ValueError("上传已过期，请重新上传文件")
        return record


UPLOADS = UploadStore()


def _cell_text(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return format(Decimal(str(value)).normalize(), "f")
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value).strip()


def _rows_from_cells(rows):
    headers, data = [], []
    for row in rows:
        cells = [_cell_text(cell.value) for cell in row]
        line = row[0].row
        if not any(cells):
            continue
        if not headers:
            headers = [cell.strip() for cell in cells]
            continue
        data.append((line, cells))
    return headers, data


def _rows_from_sheet(rows):
    headers, data = [], []
    for index, raw in enumerate(rows, start=1):
        cells = [_cell_text(cell) for cell in raw]
        if not any(cells):
            continue
        if not headers:
            headers = [cell.strip() for cell in cells]
            continue
        data.append((index, cells))
    return headers, data


def _load_xlsx(raw: bytes, sheet_name: str):
    book = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
    names = list(book.sheetnames)
    target = sheet_name if sheet_name in names else names[0]
    sheet = book[target]
    headers, rows = _rows_from_cells(sheet.iter_rows())
    book.close()
    if not headers:
        raise ValueError("工作表没有表头")
    return names, target, headers, rows


def _load_delimited(raw: bytes):
    text = None
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError("文件编码无法识别，请使用 UTF-8 或 GBK")
    first = text.splitlines()[0] if text.splitlines() else ""
    delimiter = "\t" if ("\t" in first or ("," not in first)) else ","
    reader = list(csv.reader(io.StringIO(text), delimiter=delimiter))
    headers, rows = _rows_from_sheet(reader)
    if not headers:
        raise ValueError("文件没有表头")
    return ["数据"], "数据", headers, rows


def parse_uploaded_file(raw: bytes, filename: str, sheet_name: str = ""):
    if len(raw) > MAX_BYTES:
        raise ValueError("文件超过 20MB，请拆分后上传")
    if not raw:
        raise ValueError("文件为空")
    lowered = (filename or "").lower()
    if lowered.endswith((".xlsx", ".xlsm")):
        names, target, headers, rows = _load_xlsx(raw, sheet_name)
        sheets = names
    elif lowered.endswith((".csv", ".tsv", ".txt")):
        names, target, headers, rows = _load_delimited(raw)
        sheets = names
    else:
        raise ValueError("仅支持 .xlsx、.csv、.tsv")
    if len(rows) > MAX_ROWS:
        raise ValueError(f"单次最多 {MAX_ROWS} 行，请拆分文件")
    if not rows:
        raise ValueError("表格没有数据行")
    return {"filename": filename or "upload", "sheets": sheets, "selected_sheet": target,
            "headers": headers, "rows": rows}


def auto_mapping(headers):
    mapping, used = {}, set()
    for header in headers:
        field = resolve_header(header)
        if field in ("followers_k", "views_k"):
            field = field[:-2]
        if field and field in used:
            field = ""
        if field:
            used.add(field)
        mapping[header] = field or ""
    return mapping


# ------------------------------------------------------------- row helpers
def _clean_value(field, value, default_currency):
    text = (value or "").strip()
    if not text:
        return ""
    if field in NUMERIC_FIELDS and text.casefold() in UNKNOWN_TOKENS:
        return ""
    if field in ("quote", "estimated_quote") and re.fullmatch(r"[0-9]+(?:\.[0-9]{1,2})?", text):
        return f"{default_currency} {text}"
    return text


def _effective_headers(mapping):
    active = {}
    for header, field in mapping.items():
        if not field:
            continue
        if field in active.values():
            raise ValueError("存在含义重复的导入列")
        active[header] = field
    if "url" not in active.values() and "account_id" not in active.values():
        raise ValueError("至少需要映射主页链接或账号ID")
    return active


def _canonical(row, active, default_currency):
    data = {}
    for header, field in active.items():
        value = _clean_value(field, row.get(header, ""), default_currency)
        if value:
            data[field] = value
    for derived in ("followers", "views"):
        key = derived + "_k"
        if derived not in data and key in data:
            raw = data.pop(key)
            data[derived] = raw if re.search(r"[A-Za-z万千]", raw) else raw + "K"
    if not data.get("platform") and data.get("url"):
        url = data["url"].strip()
        if "://" not in url:
            url = "https://" + url
            data["url"] = url
        elif url.startswith("http://"):
            url = "https://" + url[len("http://"):]
            data["url"] = url
        platform = detect_platform_from_url(url)
        if platform:
            data["platform"] = platform
    return data


def _preview_grant(active, today):
    allowed = set(active.values()) | set(IDENTITY) | {"email", "email_url", "email_state"}
    policy = ImportPolicy(source_name="preview", permission="preview", deletion_owner="preview",
                          effective_on=today, acquired_on=today,
                          expires_on=date.fromordinal(today.toordinal() + 30),
                          allowed_fields=sorted(allowed), purposes=["view", "tag", "match", "export"])
    return prepare_policy(policy, today)


def _existing_index(db):
    rows = db.execute("SELECT id, source, platform, account_id, url, display_name, followers, views, "
                      "country, language, email_state, raw FROM accounts WHERE workspace_id=1").fetchall()
    by_key, by_url, by_alias, records = {}, {}, {}, {}
    for row in rows:
        records[row["id"]] = {k: row[k] for k in row.keys()}
        by_key.setdefault((row["platform"], str(row["account_id"]).casefold()), row["id"])
        by_url.setdefault((row["platform"], row["url"]), row["id"])
    for alias, platform, account in db.execute(
            "SELECT alias, platform, account FROM account_aliases WHERE workspace_id=1").fetchall():
        by_alias[(platform, str(alias).casefold())] = account
    return by_key, by_url, by_alias, records


def _diff(prior_raw, profile, provided):
    updated, preserved = [], []
    for field in provided:
        if field not in profile:
            continue
        new = profile[field]
        if new in (None, "", []):
            continue
        old = prior_raw.get(field)
        if old in (None, "", []):
            updated.append(field)
        elif old != new:
            updated.append(field)
    return updated


PREVIEW_KEYS = ("platform", "account_id", "url", "display_name", "country", "language",
                "followers", "views", "quote", "collaboration", "email", "email_state")


def preview_batch(db, upload, mapping, update_existing=True, preserve_manual_fields=True,
                  default_currency="USD", today=None):
    today = today or date.today()
    headers, rows = upload["headers"], upload["rows"]
    active = _effective_headers(mapping)
    grant = _preview_grant(active, today)
    by_key, by_url, by_alias, records = _existing_index(db)
    counts = {"to_add": 0, "to_update": 0, "unchanged": 0, "in_file_duplicates": 0, "errors": 0}
    errors, duplicates, samples = [], [], []
    seen = {}
    total = 0
    for offset, (line, cells) in enumerate(rows):
        row = {header: (cells[i] if i < len(cells) else "") for i, header in enumerate(headers)}
        if not any((v or "").strip() for v in row.values()):
            continue
        total += 1
        try:
            data = _canonical(row, active, default_currency)
            profile = governed_profile(data, "independent", grant, f"preview:{line}", lenient=True)
        except ValueError as error:
            counts["errors"] += 1
            if len(errors) < 200:
                errors.append({"line": line, "raw": row.get(next(iter(active))) or "",
                               "field": "-", "reason": str(error)})
            continue
        platform, identifier = profile["platform"], str(profile["account_id"])
        key = (platform, identifier.casefold())
        if key in seen:
            counts["in_file_duplicates"] += 1
            if len(duplicates) < 100:
                duplicates.append({"line": line, "first_line": seen[key], "platform": platform,
                                   "account_id": identifier})
            continue
        seen[key] = line
        existing = by_key.get(key) or by_url.get((platform, profile["url"]))
        if existing:
            prior = load(records[existing]["raw"])
            changed = _diff(prior, profile, active.values())
            if update_existing and changed:
                counts["to_update"] += 1
                action = "to_update"
            else:
                counts["unchanged"] += 1
                action = "unchanged"
        else:
            counts["to_add"] += 1
            action = "to_add"
        if len(samples) < 30:
            samples.append({"line": line, "action": action, "platform": platform,
                            "account_id": identifier, "url": profile["url"],
                            "display_name": profile.get("display_name"),
                            "followers": profile.get("followers"),
                            "changed": _diff(load(records[existing]["raw"]), profile, active.values())
                            if existing else []})
    assert total == sum(counts.values()), "行数守恒失败"
    return {"total_rows": total, "counts": counts, "headers": headers, "mapping": mapping,
            "unmapped_headers": [h for h in headers if not mapping.get(h)],
            "sample_rows": samples, "errors": errors, "total_errors": counts["errors"],
            "duplicates": duplicates}


# ---------------------------------------------------------------- commit
def _merge_account(db, account_id, profile, provided, batch_id, timestamp, preserve_manual=True):
    row = db.execute("SELECT raw FROM accounts WHERE id=?", (account_id,)).fetchone()
    prior = load(row["raw"])
    prior_prov = prior.get("provenance") or {"fields": {}}
    incoming = profile.get("provenance") or {"fields": {}}
    merged = dict(prior)
    changed, preserved_quotes, preserved_collab = [], 0, 0
    for field in active_fields_only(provided):
        value = profile.get(field)
        if value in (None, "", []):
            continue
        if preserve_manual and field == "quote" and prior.get("quote"):
            preserved_quotes += 1
            continue
        if preserve_manual and field == "collaboration" and prior.get("collaboration"):
            preserved_collab += 1
            continue
        if field == "bd" and prior.get("bd"):
            continue
        if prior.get(field) != value:
            merged[field] = value
            changed.append(field)
    if not changed:
        return 0, preserved_quotes, preserved_collab
    fields = dict(prior_prov.get("fields") or {})
    for field in changed:
        if field in incoming.get("fields", {}):
            fields[field] = {**incoming["fields"][field], "updated_at": timestamp}
    history = list(prior_prov.get("update_history") or [])[-19:]
    history.append({"batch_id": batch_id, "source_name": incoming.get("source_name"),
                    "updated_fields": changed, "recorded_at": timestamp})
    provenance = {**prior_prov, "fields": fields, "update_history": history}
    merged["provenance"] = provenance
    merged["account_id"] = prior.get("account_id")
    merged["url"] = prior.get("url")
    expires = min(grant["expires_on"] for key, grant in fields.items() if key in IDENTITY) \
        if all(key in fields for key in IDENTITY) else None
    db.execute(
        "UPDATE accounts SET display_name=?,country=?,language=?,followers=?,views=?,bd=?,raw=?,updated_at=?,"
        "expires_at=? WHERE id=?",
        (merged.get("display_name"), merged.get("country"), merged.get("language"),
         merged.get("followers"), merged.get("views"), merged.get("bd"), dump(merged), timestamp,
         expires + "T00:00:00+00:00" if expires else None, account_id))
    if any(field in provided for field in ("email", "email_url", "email_state")):
        db.execute("INSERT INTO contacts VALUES(?,?,?,?,?) ON CONFLICT(account) DO UPDATE SET "
                   "email=excluded.email,url=excluded.url,state=excluded.state,updated_at=excluded.updated_at",
                   (account_id, merged.get("email"), merged.get("email_url"),
                    merged.get("email_state") or "unavailable", timestamp))
    freshness.sync_account_states(
        db, account_id, merged, "import", incoming.get("source_name") or "batch_import",
        timestamp, only_fields=changed,
    )
    return len(changed), preserved_quotes, preserved_collab


def active_fields_only(provided):
    return [field for field in provided if field]


def commit_batch(store, db_factory, upload, body, today=None):
    if not body.confirmed:
        raise ValueError("请先确认资料来源与授权")
    today = today or date.today()
    active = _effective_headers(body.mapping)
    policy_obj = body.policy
    if policy_obj is None:
        allowed_fields = sorted(set(active.values()) | set(IDENTITY) | {"email", "email_url", "email_state"})
        policy_obj = ImportPolicy(
            source_name=(upload.get("filename") or "本地表格导入")[:120],
            permission="默认导入（本地业务资料整理）",
            effective_on=today,
            acquired_on=today,
            expires_on=date.fromordinal(today.toordinal() + 365),
            deletion_owner="operator",
            allowed_fields=allowed_fields,
            purposes=["view", "tag", "match", "export"],
        )
    basis, allowed = prepare_policy(policy_obj, today)
    grant = (basis, allowed)
    headers, rows = upload["headers"], upload["rows"]
    present = set()
    for _line, cells in rows:
        row = {header: (cells[i] if i < len(cells) else "") for i, header in enumerate(upload["headers"])}
        try:
            present.update(_canonical(row, active, body.default_currency).keys())
        except ValueError:
            continue
    present -= set(IDENTITY)
    missing = present - set(basis["allowed_fields"])
    if missing:
        raise ValueError("授权字段未覆盖表内出现的列：" + "、".join(sorted(missing)))
    batch_id = secrets.token_hex(6)
    timestamp = now()
    counts = {"added": 0, "updated": 0, "unchanged": 0, "in_file_duplicates": 0,
              "preserved_quotes": 0, "preserved_collaborations": 0, "preserved_provider": 0,
              "rejected": []}
    seen, chunks, start = {}, 0, time.time()
    for offset in range(0, len(rows), CHUNK_SIZE):
        chunks += 1
        with db_factory(True) as db:
            for line, cells in rows[offset:offset + CHUNK_SIZE]:
                row = {header: (cells[i] if i < len(cells) else "") for i, header in enumerate(headers)}
                db.execute("SAVEPOINT batch_row")
                try:
                    data = _canonical(row, active, body.default_currency)
                    profile = governed_profile(data, body.source, grant, f"{batch_id}:{line}", lenient=True)
                    key = (profile["platform"], str(profile["account_id"]).casefold())
                    if key in seen:
                        counts["in_file_duplicates"] += 1
                        db.execute("RELEASE batch_row")
                        continue
                    seen[key] = line
                    found = db.execute(
                        "SELECT id,source FROM accounts WHERE workspace_id=1 AND platform=? "
                        "AND (account_id=? OR url=?)",
                        (profile["platform"], profile["account_id"], profile["url"])).fetchall()
                    if len(found) > 1:
                        raise ValueError("账号 ID 与主页归属不同记录，需要人工核实")
                    if not found:
                        account_id, _ = store.save_account(db, profile)
                        counts["added"] += 1
                    else:
                        account_id = found[0]["id"]
                        prior_row = found[0]
                        if prior_row and prior_row["source"] in ("youtube_api", "fixture"):
                            counts["preserved_provider"] += 1
                            counts["unchanged"] += 1
                        elif not body.update_existing:
                            counts["unchanged"] += 1
                        else:
                            changed, quotes, collabs = _merge_account(
                                db, account_id, profile, list(data.keys()), batch_id,
                                timestamp, body.preserve_manual_fields)
                            counts["preserved_quotes"] += quotes
                            counts["preserved_collaborations"] += collabs
                            counts["updated" if changed else "unchanged"] += 1
                    if body.project_id:
                        _link_project(store, db, body.project_id, account_id)
                    db.execute("RELEASE batch_row")
                except ValueError as error:
                    db.execute("ROLLBACK TO batch_row")
                    db.execute("RELEASE batch_row")
                    if len(counts["rejected"]) < 500:
                        counts["rejected"].append({"line": line, "reason": str(error)[:160]})
    elapsed = int((time.time() - start) * 1000)
    receipt = {"batch_id": batch_id, "filename": upload["filename"], "total_rows": len(rows),
               "chunks": chunks, "elapsed_ms": elapsed, **counts}
    with db_factory(True) as db:
        db.execute("INSERT INTO import_history(policy, result, recorded_at) VALUES(?,?,?)",
                   (dump({"mode": "batch_v13", "policy": basis, "mapping": active,
                          "filename": upload["filename"]}), dump(receipt), timestamp))
    return receipt


def _link_project(store, db, project_id, account_id):
    row = db.execute("SELECT criteria FROM projects WHERE id=?", (project_id,)).fetchone()
    if not row:
        raise ValueError("目标项目不存在")
    criteria = load(row["criteria"]) if row["criteria"] else {}
    store.apply_match(db, project_id, account_id, criteria)


class BatchLinksRequest(BaseModel):
    links_text: str = Field(min_length=1, max_length=200_000)
    bd: str = Field(default="", max_length=120)
    source: str = Field(default="independent", pattern="^(independent|authorized)$")
    project_id: int | None = None
    enrich: bool = True


def _resolve_youtube_channel_id(identifier: str, url: str) -> str | None:
    if re.fullmatch(r"UC[A-Za-z0-9_-]{22}", identifier or ""):
        return identifier
    from .intelligent_discovery import _http_get
    html = _http_get(url)
    for pattern in (
        r'"externalId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"',
        r'"channelId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"',
        r'youtube\.com/channel/(UC[A-Za-z0-9_-]{22})',
    ):
        match = re.search(pattern, html)
        if match:
            return match.group(1)
    return None


def _default_youtube_enricher(identifier: str, url: str) -> dict:
    from .intelligent_discovery import OfficialRssDiscoveryProvider, split_video_metrics
    channel_id = _resolve_youtube_channel_id(identifier, url)
    if not channel_id:
        raise RuntimeError("未能解析 YouTube 频道 ID（UC...）")
    rss = OfficialRssDiscoveryProvider.fetch_rss(channel_id)
    videos = rss.get("videos") or []
    metrics = split_video_metrics(videos)
    overall_avg = metrics.get("overall_avg")
    overall_med = metrics.get("overall_median")
    samples = [str(v["views"]) for v in videos[:10] if isinstance(v.get("views"), int)]
    enriched = {
        "account_id": channel_id,
        "url": f"https://www.youtube.com/channel/{channel_id}",
        "display_name": rss.get("display_name") or identifier,
        "alias": identifier if identifier.startswith("@") else "",
    }
    if videos:
        enriched["content_titles"] = "|".join(v["title"] for v in videos[:10])
        enriched["content_urls"] = "|".join(v["url"] for v in videos[:10])
    if overall_avg is not None:
        enriched["views"] = str(round(overall_avg))
        enriched["recent_average"] = str(round(overall_avg, 4))
    if overall_med is not None:
        enriched["recent_median"] = str(round(overall_med, 4))
    if samples:
        enriched["recent_samples"] = "|".join(samples)
        enriched["recent_count"] = str(len(samples))
        enriched["recent_scope"] = f"YouTube 官方 RSS 最近 {len(samples)} 条公开视频"
    return enriched


def batch_import_links(store, db_factory, body: BatchLinksRequest, *, today=None, enricher=None):
    lines = [(i, raw_line.strip()) for i, raw_line in enumerate(body.links_text.splitlines(), 1) if raw_line.strip()]
    if not lines:
        raise ValueError("请输入至少 1 条达人主页链接")
    if len(lines) > 500:
        raise ValueError("单次最多导入 500 条主页链接")
    today = today or date.today()
    expires = date.fromordinal(today.toordinal() + 365)
    allowed_fields = sorted(set(FIELD_KEYS) | set(IDENTITY))
    policy = ImportPolicy(
        source_name="批量链接导入",
        permission="用户手动提交的公开达人主页链接整理与合规补全",
        effective_on=today,
        acquired_on=today,
        expires_on=expires,
        deletion_owner=(body.bd or "").strip() or "operator",
        allowed_fields=allowed_fields,
        purposes=["view", "tag", "match", "export"],
    )
    grant = prepare_policy(policy, today)
    batch_id = secrets.token_hex(6)
    timestamp = now()
    yt_enricher = enricher or _default_youtube_enricher

    counts = {
        "total": len(lines), "added": 0, "updated": 0, "duplicates": 0,
        "enriched": 0, "enrich_failed": 0, "rejected": [], "items": [],
    }
    seen = {}
    with db_factory(True) as db:
        for line_no, raw_url in lines:
            db.execute("SAVEPOINT link_row")
            try:
                clean_url = raw_url
                if "://" not in clean_url:
                    clean_url = "https://" + clean_url
                platform = detect_platform_from_url(clean_url)
                if not platform:
                    raise ValueError("仅支持 YouTube、TikTok、Instagram、X 主页链接")
                identifier, norm_url = identity(platform, "", clean_url)
                row_data = {"platform": platform, "account_id": identifier, "url": norm_url}
                if (body.bd or "").strip():
                    row_data["bd"] = body.bd.strip()

                enrich_status = "skipped"
                enrich_note = ""
                if body.enrich:
                    if platform == "YouTube":
                        try:
                            extra = yt_enricher(identifier, norm_url) or {}
                            for k, v in extra.items():
                                if v not in (None, ""):
                                    row_data[k] = v
                            enrich_status = "ok"
                            counts["enriched"] += 1
                        except Exception as exc:
                            enrich_status = "failed"
                            enrich_note = str(exc)[:120]
                            counts["enrich_failed"] += 1
                    else:
                        enrich_status = "platform_limited"
                        enrich_note = f"{platform} 无公开免 Key 自动补全接口，已保留链接与账号标识"

                profile = governed_profile(row_data, body.source, grant, f"{batch_id}:{line_no}", lenient=True)
                key = (profile["platform"], str(profile["account_id"]).casefold())
                if key in seen:
                    counts["duplicates"] += 1
                    db.execute("RELEASE link_row")
                    continue
                seen[key] = line_no

                found = db.execute(
                    "SELECT id, source FROM accounts WHERE workspace_id=1 AND platform=? "
                    "AND (account_id=? OR url=? OR id IN (SELECT account FROM account_aliases "
                    "WHERE workspace_id=1 AND platform=? AND alias=?))",
                    (profile["platform"], profile["account_id"], profile["url"],
                     profile["platform"], profile.get("alias") or profile["account_id"]),
                ).fetchall()
                if not found:
                    account_id, _ = store.save_account(db, profile)
                    action = "added"
                    counts["added"] += 1
                else:
                    account_id = found[0]["id"]
                    if found[0]["source"] in ("youtube_api", "fixture"):
                        action = "duplicate"
                        counts["duplicates"] += 1
                    else:
                        changed, _, _ = _merge_account(
                            db, account_id, profile, list(row_data.keys()), batch_id, timestamp, preserve_manual=True
                        )
                        if changed:
                            action = "updated"
                            counts["updated"] += 1
                        else:
                            action = "duplicate"
                            counts["duplicates"] += 1
                if body.project_id:
                    _link_project(store, db, body.project_id, account_id)
                counts["items"].append({
                    "line": line_no, "account_id": account_id, "platform": profile["platform"],
                    "identifier": profile["account_id"], "url": profile["url"],
                    "display_name": profile.get("display_name"), "action": action,
                    "enrich_status": enrich_status, "enrich_note": enrich_note,
                })
                db.execute("RELEASE link_row")
            except (ValueError, OverflowError) as exc:
                db.execute("ROLLBACK TO link_row")
                db.execute("RELEASE link_row")
                counts["rejected"].append({"line": line_no, "url": raw_url[:160], "reason": str(exc)[:160]})
    return counts
