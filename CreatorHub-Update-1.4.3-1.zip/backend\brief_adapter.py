"""Optional structured brief parser. Runtime has no live provider."""
import asyncio
import logging
import sqlite3
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from .domain import PLATFORMS, parse_brief
from .model_api import fallback_reason

LOG = logging.getLogger("creatorhub")


class BriefRequirement(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    kind: Literal["market", "language", "follower", "reading", "content", "budget", "schedule", "other"]
    quote: str = Field(min_length=1, max_length=300)


class ModelBrief(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    platforms: list[str] = Field(max_length=4)
    needs_review: list[str] = Field(max_length=12)
    requirements: list[BriefRequirement] = Field(default_factory=list, max_length=12)


def checked_brief(raw, brief):
    output = ModelBrief.model_validate(raw)
    if any(p not in PLATFORMS for p in output.platforms):
        raise ValueError("platform")
    if any(not entry.strip() or len(entry) > 300 or entry not in brief
           for entry in output.needs_review + [item.quote for item in output.requirements]):
        raise ValueError("unverified quote")
    return output


class BriefAdapter:
    def __init__(self, model=None, limit=20, timeout=3, source="mock_suggestions"):
        self.model = model
        self.remaining = limit
        self.timeout = timeout
        self.source = source

    async def parse(self, brief):
        baseline = parse_brief(brief)
        if self.model is None:
            return baseline
        try:
            if self.remaining is not None:
                if self.remaining <= 0:
                    raise ValueError("budget")
                self.remaining -= 1
            raw = await asyncio.wait_for(self.model(brief, ModelBrief.model_json_schema()), self.timeout)
            output = checked_brief(raw, brief)
        except (TimeoutError, ValidationError, ValueError, RuntimeError, OSError, sqlite3.Error) as error:
            reason = fallback_reason(error)
            LOG.warning("brief model fallback: %s", reason)
            return {**baseline, "model_status": "fallback", "fallback_reason": reason,
                    "note": "模型解析失败或额度已用完。已保留原文与规则结果，请人工确认。"}
        return {**baseline, "model_status": self.source,
                "model_platforms": output.platforms, "model_review": output.needs_review,
                "model_requirements": [item.model_dump() for item in output.requirements],
                "note": "请核对规则条件及模型提示；模型提示不直接用于筛选。"}
