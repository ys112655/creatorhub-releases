"""Brand brief parsing, account identity and evidence-based classification."""
import re
from urllib.parse import urlsplit

PLATFORMS = ("YouTube", "Instagram", "TikTok", "X")
DIMENSIONS = ("行业领域", "职业身份", "内容主题", "工具及技术", "应用场景", "内容形式")
COUNTRIES = {
    "US": ("美国", "United States"), "GB": ("英国", "United Kingdom", "UK"),
    "CA": ("加拿大", "Canada"), "DE": ("德国", "Germany"), "FR": ("法国", "France"),
    "IT": ("意大利", "Italy"), "ES": ("西班牙", "Spain"), "NL": ("荷兰", "Netherlands"),
    "SE": ("瑞典", "Sweden"), "NO": ("挪威", "Norway"), "IE": ("爱尔兰", "Ireland"),
    "KR": ("韩国", "韓國", "Korea", "South Korea"), "JP": ("日本", "Japan"),
    "CN": ("中国", "China"), "AU": ("澳大利亚", "Australia"),
    "TW": ("台湾", "中国台湾", "Taiwan"), "HK": ("香港", "中国香港", "Hong Kong"),
    "SG": ("新加坡", "Singapore"), "MY": ("马来西亚", "Malaysia"),
    "TH": ("泰国", "Thailand"), "VN": ("越南", "Vietnam"),
    "PH": ("菲律宾", "Philippines"), "ID": ("印尼", "印度尼西亚", "Indonesia"),
    "IN": ("印度", "India"), "BR": ("巴西", "Brazil"), "MX": ("墨西哥", "Mexico"),
    "RU": ("俄罗斯", "Russia"), "AE": ("阿联酋", "UAE"),
}
LANGUAGES = {"en": ("英语", "英文", "English"), "zh": ("中文", "Chinese"),
             "ja": ("日语", "日語", "日文", "Japanese"), "ko": ("韩语", "韓語", "韩文", "Korean"), "es": ("西语", "Spanish"),
             "de": ("德语", "German"), "fr": ("法语", "French")}
WEST = sorted(set(COUNTRIES) - {"JP", "CN", "AU"})
TAXONOMY = {
    "行业领域": {
        "AI": ("artificial intelligence", "AI", "人工智能"),
        "游戏开发": ("game dev", "game development", "Unity", "Unreal Engine", "游戏开发"),
        "摄影": ("photography", "摄影"), "美妆": ("makeup", "beauty", "美妆"),
        "小企业": ("small business", "SMB", "小企业"), "家庭": ("parenting", "育儿", "家庭"),
    },
    "职业身份": {
        "设计师": ("designer", "设计师"), "律师": ("lawyer", "attorney", "律师"),
        "医生": ("physician", "medical doctor", "医生"), "教师": ("teacher", "教师"),
        "学生": ("student", "学生"), "模特": ("fashion model", "模特"),
        "小企业主": ("small business owner", "founder", "小企业主"),
        "摄影师": ("photographer", "摄影师"),
    },
    "内容主题": {
        "AI电影": ("AI film", "AI cinema", "AI short film", "AI电影"),
        "VFX": ("VFX", "visual effects", "AI特效"), "AI助手": ("AI assistant", "AI助手"),
        "AI编程": ("AI coding", "AI programming", "AI编程"),
        "AI模型": ("AI model", "LLM", "AI模型"),
        "AI视频生成": ("AI video generation", "generative video", "AIGC视频", "AI视频生成"),
    },
    "工具及技术": {
        "ComfyUI": ("ComfyUI", "Comfy UI"), "Runway": ("Runway", "RunwayML"),
        "Sora": ("Sora", "OpenAI Sora"), "Blender": ("Blender",),
        "Unreal Engine": ("Unreal Engine", "UE5"), "CapCut": ("CapCut", "剪映"),
    },
    "应用场景": {
        "视频剪辑": ("video editing", "edit videos", "视频剪辑"),
        "影视制作": ("filmmaking", "film production", "影视制作"),
        "3D游戏开发": ("3D game development", "3D game dev", "3D游戏开发"),
        "品牌内容": ("brand content", "ads creative", "品牌内容"),
    },
    "内容形式": {
        "教程": ("tutorial", "walkthrough", "教程"),
        "测评": ("product review", "tool review", "测评"),
        "短片": ("short film", "micro film", "短片"),
        "案例拆解": ("case study", "breakdown", "案例拆解"),
    },
}

def has(text, word):
    escaped = re.escape(word)
    if word.isascii():
        # CJK immediately adjacent to an English tool name is a common brief format.
        escaped = r"(?<![A-Za-z0-9])" + escaped + r"(?![A-Za-z0-9])"
    return bool(re.search(escaped, text, re.I))

UNKNOWN_METRIC_TOKENS = {"", "未知", "暂无", "待定", "n/a", "na", "none", "null", "-", "—", "--"}


def code(value, aliases, *, lenient=False):
    value = str(value or "").strip()
    if not value or value.casefold() in UNKNOWN_METRIC_TOKENS:
        return None
    for key, names in aliases.items():
        if value.casefold() in {key.casefold(), *(name.casefold() for name in names)}:
            return key
    pattern = r"[A-Za-z]{2}" if aliases is COUNTRIES else r"[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})?"
    if not re.fullmatch(pattern, value):
        if lenient:
            return None
        raise ValueError(f"无法识别的国家或语言值：{value[:30]}")
    return value.upper() if aliases is COUNTRIES else value.split("-")[0].lower()

def count(value, *, lenient=False):
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip().replace(",", "")
    if text.casefold() in UNKNOWN_METRIC_TOKENS:
        return None
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([kKmM万千]?)", text)
    if not match:
        if lenient:
            return None
        raise ValueError("粉丝量、均播和门槛需为非负数字，可用 K、M、万")
    result = round(float(match[1]) * {"k": 1000, "m": 1000000, "万": 10000, "千": 1000, "": 1}[match[2].lower()])
    if result > 10**12:
        if lenient:
            return None
        raise ValueError("数值超出支持范围")
    return result


def detect_platform_from_url(link):
    """Detect supported creator platform from a profile URL, or return None."""
    text = str(link or "").strip()
    if not text:
        return None
    if "://" not in text:
        text = "https://" + text
    host = (urlsplit(text).hostname or "").lower().removeprefix("www.")
    mapping = {
        "YouTube": {"youtube.com", "m.youtube.com"},
        "Instagram": {"instagram.com"},
        "TikTok": {"tiktok.com"},
        "X": {"x.com", "twitter.com", "mobile.twitter.com"},
    }
    for platform, hosts in mapping.items():
        if host in hosts or any(host.endswith("." + item) for item in hosts):
            return platform
    return None

def parse_brief(brief):
    conditions, preferences, topics, keywords = {}, {}, [], []
    groups = []
    pending = []
    if re.search(r"繁[体體]中文(?:内容|內容|语言|語言)|繁中内容", brief):
        pending.append({"label": "繁体中文内容", "text": "现有语言字段不能区分简体和繁体，需核验作品。"})
    metric = r"(\d+(?:\.\d+)?\s*[kKmM万千]?)"
    categories = r"(AI(?:类|测评)?|商业设计(?:类)?|重点传播(?:类)?)"
    multi = list(re.finditer(categories + r"\s*[:：]?\s*" + metric + r"\s*\+?\s*[/／]\s*" + metric, brief, re.I))
    for found in multi:
        label, followers, views = found.groups()
        groups.append({"label": label, "followers": count(followers), "median_views": count(views)})
    if not groups:
        parts = list(re.finditer(r"(?:^|[，。；;,、\n])\s*" + categories + r"(?![A-Za-z])", brief, re.I))
        for i, part in enumerate(parts):
            clause = brief[part.end():parts[i+1].start() if i+1 < len(parts) else len(brief)]
            f = re.search(r"(?:订阅|粉丝)(?:量|数)?[^\d]{0,12}" + metric, clause)
            v = re.search(r"(?:中位(?:数)?播放(?:量)?|播放(?:量)?中位数)[^\d]{0,12}" + metric, clause)
            if f:
                groups.append({"label": part[1], "followers": count(f[1]), "median_views": count(v[1]) if v else None})
    for label, pattern in (
        ("同类长视频中位播放", r"中位|均播|长视频|播放量|median|average views"),
        ("视频样本与统计窗口", r"样本|\d+\s*天|\d+\s*分钟|\d+\s*条"),
        ("专业背景", r"专业|职业|背景|工作经验|从业|资历"),
        ("受众条件", r"受众|画像|观众|audience"),
        ("繁体中文市场", r"繁[体體]中文|繁中"),
    ):
        for segment in re.split(r"[；;。\n]+", brief):
            if re.search(pattern, segment, re.I):
                pending.append({"label": label, "text": segment.strip()})
    declared_groups = {re.sub(r"类$", "", m[1]).casefold() for m in re.finditer(
        r"(?:^|[，。；;,、\n])\s*" + categories + r"(?![A-Za-z])", brief, re.I)}
    if len(declared_groups) >= 2 or groups:
        pending.append({"label": "分类门槛", "text": "当前达人库不能可靠确认所属类别，分类门槛需人工核验。"})
    if groups and (len({g["label"] for g in groups}) != len(groups)
                   or any(g["median_views"] is None for g in groups)):
        pending.append({"label": "部分分类门槛待确认", "text": "请对照原文检查缺失或重复的分类门槛。"})
    seen_thresholds = {}

    for segment in re.split(r"[，,。；;\n]+", brief):
        if not segment.strip():
            continue
        preferred = bool(re.search(r"优先|最好|加分|prefer|ideally|nice to have", segment, re.I))
        target = preferences if preferred else conditions
        threshold = re.search(r"(?:粉丝(?:量|数)?|订阅(?:量|数)?|followers?|subscribers?)\D{0,18}(\d+(?:\.\d+)?\s*[kKmM万千]?)", segment, re.I)
        if not threshold:
            threshold = re.search(r"(\d+(?:\.\d+)?\s*[kKmM万千]?)\s*(?:以上|起|\+)?\s*(?:粉丝|订阅|followers?|subscribers?)", segment, re.I)
        if threshold:
            field = "max_followers" if re.search(r"以下|以内|不超过|最多|至多|at most|under", segment, re.I) else "min_followers"
            value = count(threshold[1])
            key = (preferred, field)
            if key in seen_thresholds and seen_thresholds[key] != value and not groups:
                pending.append({"label": "订阅门槛冲突", "text": segment.strip()})
            seen_thresholds[key] = value
            target[field] = value
        if re.search(r"邮箱|e-?mail", segment, re.I):
            target["email"] = True
        countries = [item for item, names in COUNTRIES.items() if any(has(segment, n) for n in names)]
        if re.search(r"欧美|western markets", segment, re.I):
            countries.extend(WEST)
        if countries:
            target["countries"] = sorted(set(target.get("countries", []) + countries))
        languages = [item for item, names in LANGUAGES.items() if any(has(segment, n) for n in names)]
        if languages:
            target["languages"] = sorted(set(target.get("languages", []) + languages))
        for dimension, labels in TAXONOMY.items():
            for label, aliases in labels.items():
                if any(has(segment, n) for n in aliases):
                    topic = {"dimension": dimension, "label": label, "preferred": preferred}
                    if topic not in topics:
                        topics.append(topic)
                    keywords.extend(n for n in aliases if n.isascii())
    if not keywords:
        keywords = [brief.strip()[:100]] if brief.strip() else []
    detected = [p for p in PLATFORMS if has(brief, p)]
    if groups or len(declared_groups) >= 2 or any(p["label"] == "订阅门槛冲突" for p in pending):
        for target in (conditions, preferences):
            target.pop("min_followers", None)
            target.pop("max_followers", None)
    if conditions.get("min_followers", 0) > conditions.get("max_followers", 10**12):
        pending.append({"label": "订阅上下限冲突", "text": "请手动核对最低和最高订阅条件。"})
        conditions.pop("min_followers", None)
        conditions.pop("max_followers", None)
    if any(p["label"] == "繁体中文市场" for p in pending) and conditions.get("countries"):
        pending.append({"label": "地区组合", "text": "已识别地区：" + "、".join(
            COUNTRIES[c][0] for c in conditions["countries"]) +
            "。繁体中文市场无法用国家字段表示，整组地区暂由人工核验。"})
        conditions.pop("countries")
    return {"groups": groups, "pending": pending, "hard": conditions, "preferences": preferences, "topics": topics,
            "keywords": list(dict.fromkeys(keywords))[:16], "platforms": detected,
            "note": "规则解析。请核对地区范围、数值门槛和关键词。必备字段未知时进入人工核实。主题默认用于召回。"}

def identity(platform, identifier, link):
    if platform not in PLATFORMS:
        raise ValueError("请选择支持录入的平台")
    identifier, link = identifier.strip(), link.strip()
    if link and "://" not in link:
        link = "https://" + link
    parts = urlsplit(link)
    valid_hosts = {"YouTube": {"youtube.com", "m.youtube.com"},
                   "Instagram": {"instagram.com"}, "TikTok": {"tiktok.com"},
                   "X": {"x.com", "twitter.com", "mobile.twitter.com"}}
    host = (parts.hostname or "").lower().removeprefix("www.")
    if link and (parts.scheme not in ("http", "https") or host not in valid_hosts[platform] or parts.username or parts.password):
        raise ValueError("主页链接与平台不匹配")
    path = parts.path.strip("/").split("/") if link else []
    yt_id = re.compile(r"UC[A-Za-z0-9_-]{22}")
    if platform == "YouTube":
        if path and ((len(path) == 1 and path[0].startswith("@")) or
                     (len(path) == 2 and path[0] in {"channel", "c", "user"})):
            link_id = path[-1]
        elif path:
            raise ValueError("请输入 YouTube 频道主页链接")
        else:
            link_id = ""
        if path and path[0] == "channel" and not yt_id.fullmatch(link_id):
            raise ValueError("YouTube 频道 ID 格式无效")
        if yt_id.fullmatch(identifier) and yt_id.fullmatch(link_id) and identifier != link_id:
            raise ValueError("账号 ID 与频道链接冲突")
        stable = next((value for value in (identifier, link_id) if yt_id.fullmatch(value)), "")
        alias = link_id or identifier
        if not stable and (not alias or not re.fullmatch(r"@?[\w.-]{2,100}", alias)):
            raise ValueError("请填写 YouTube 频道 ID 或 @账号")
        if identifier and not stable and link_id and identifier.lstrip("@").casefold() != link_id.lstrip("@").casefold():
            raise ValueError("账号与链接不一致")
        slug = "/".join(path) if path else "@" + alias.lstrip("@")
        return (stable or (slug if not slug.startswith("@") else slug.casefold()),
                "https://www.youtube.com/" + ("channel/" + stable if stable else slug))
    if path and (len(path) != 1 or (platform == "TikTok" and not path[0].startswith("@")) or
                 path[0].casefold() in {"explore", "reels", "stories", "intent", "home", "search", "i"}):
        raise ValueError("请输入账号主页链接")
    name = (path[0] if path else identifier).lstrip("@").casefold()
    if identifier and identifier.lstrip("@").casefold() != name:
        raise ValueError("账号 ID 与主页链接不一致")
    if not re.fullmatch(r"[\w.]{1,64}", name):
        raise ValueError("平台账号格式无效")
    base = {"Instagram": "https://www.instagram.com/", "TikTok": "https://www.tiktok.com/@", "X": "https://x.com/"}
    return name, base[platform] + name

def rules(profile):
    """Require distinct attestations for core tags and retain per-tag evidence."""
    sources = []
    if profile.get("bio"):
        sources.append({"title": profile["bio"], "url": profile["url"], "kind": "bio"})
    seen_titles = set()
    for item in profile.get("content", []):
        title = item.get("title", "").strip().casefold()
        if title and title not in seen_titles:
            sources.append({**item, "kind": "content"})
            seen_titles.add(title)
    tags = []
    for dimension, labels in TAXONOMY.items():
        for label, aliases in labels.items():
            evidence = [item for item in sources if any(
                has(" ".join(str(item.get(k, "")) for k in ("title", "description", "tags")), term) for term in aliases)]
            if not evidence:
                continue
            recurring = sum(e["kind"] == "content" for e in evidence) >= 2
            corroborated = len(evidence) >= 2 and any(e["kind"] == "bio" for e in evidence)
            tags.append({"dimension": dimension, "label": label,
                         "tier": "core" if recurring or corroborated else "secondary",
                         "evidence": evidence[:5], "model": "rules-v1"})
    return tags

def evaluate(profile, criteria, *, use_topics=True):
    unknown, failed, preferred, matched = [], [], [], []
    hard = criteria.get("hard", {})
    for key, condition in hard.items():
        actual = {"countries": profile.get("country"), "languages": profile.get("language"),
                  "min_followers": profile.get("followers"), "max_followers": profile.get("followers"),
                  "email": profile.get("email_state")}.get(key)
        if actual is None or actual in ("unknown", "manual", "unavailable"):
            unknown.append(key)
        elif key in ("countries", "languages") and actual not in condition:
            failed.append(key)
        elif key == "min_followers" and actual < condition:
            failed.append(key)
        elif key == "max_followers" and actual > condition:
            failed.append(key)
        elif key == "email" and actual != "verified":
            failed.append(key)
    likes = criteria.get("preferences", {})
    if likes.get("email") and profile.get("email_state") == "verified":
        preferred.append("已核实公开商务邮箱")
    if profile.get("country") in likes.get("countries", []):
        preferred.append("符合偏好地区")
    if profile.get("language") in likes.get("languages", []):
        preferred.append("符合偏好语言")
    for key, op in (("min_followers", lambda a, b: a >= b), ("max_followers", lambda a, b: a <= b)):
        if key in likes and profile.get("followers") is not None and op(profile["followers"], likes[key]):
            preferred.append("符合偏好粉丝范围")
            break
    if use_topics:
        tags = {(t["dimension"], t["label"]): t["tier"] for t in profile.get("tags", [])}
        for topic in criteria.get("topics", []):
            tier = tags.get((topic["dimension"], topic["label"]))
            if tier:
                matched.append({"label": topic["label"], "tier": tier})
        if criteria.get("topics") and not matched:
            unknown.append("topics")
    unknown.extend(dict.fromkeys(item["label"] for item in criteria.get("pending", [])))
    state = "excluded" if failed else "review" if unknown or not use_topics else "eligible"
    return {"state": state, "failed": failed, "unknown": unknown, "preferences": preferred, "topics": matched}
