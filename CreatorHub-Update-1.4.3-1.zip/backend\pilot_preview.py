"""Independent synthetic pilot console. The HTTP process opens SQLite read-only."""
import argparse
from base64 import b64encode
from collections import Counter
from hashlib import sha256
from html import escape
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse

from .youtube_pilot import FixtureTransport, LIMITS, Pilot

LOGO = Path(__file__).with_name("pilot_youtube_logo.svg")
CHANNEL = "synthetic_b0e_channel"
SCRIPT = """addEventListener('pagehide',()=>document.getElementById('api-values').replaceChildren());addEventListener('pageshow',event=>{if(event.persisted)location.reload()});"""
SCRIPT_HASH = b64encode(sha256(SCRIPT.encode()).digest()).decode()
STYLE = """
*{box-sizing:border-box}body{margin:0;background:#f3f6fa;color:#182536;font:15px/1.6 system-ui,sans-serif}
main{max-width:980px;margin:0 auto;padding:36px 24px}h1,h2,p{margin:0}h1{font-size:30px}h2{font-size:19px}
header{display:flex;justify-content:space-between;gap:16px;align-items:start}small{color:#475569}
strong.mode{background:#e3f1eb;color:#165a43;border-radius:6px;padding:4px 11px;white-space:nowrap}
section{background:white;border:1px solid #d9e2eb;border-radius:12px;margin-top:18px;padding:20px}
dl{display:grid;grid-template-columns:8em 1fr;gap:3px 12px;margin:8px 0 0}
dt{color:#475569}dd{margin:0;overflow-wrap:anywhere}.source{display:flex;gap:20px;align-items:center;flex-wrap:wrap}
img{display:block;width:112px;height:auto}article+article{border-top:1px solid #d9e2eb;margin-top:14px;padding-top:12px}
code{overflow-wrap:anywhere}
"""


def seed(directory):
    responses = [
        (200, {"items": [{"snippet": {"channelId": CHANNEL}}]}),
        (200, {"items": []}),
        (200, {"items": []}),
        (200, {"items": [{"id": CHANNEL, "snippet": {"title": "合成频道 Atlas", "defaultLanguage": "en"}}]}),
    ]
    pilot = Pilot(directory, FixtureTransport(responses), mode="offline", create=True)
    pilot.run()
    pilot.record_independent(CHANNEL, "https://example.invalid/creatorhub-review",
                             "合成凭证：人工核验待确认", source="independent", authorized=True)


def fields(values):
    return "<dl>" + "".join(
        f"<dt>{escape(label)}</dt><dd>{escape(str(value) if value is not None else '未知')}</dd>"
        for label, value in values
    ) + "</dl>"


def render(pilot):
    counts = Counter(endpoint for endpoint, _, _ in pilot.ledger())
    quotas = " · ".join(f"{endpoint} {counts[endpoint]}/{limit}" for endpoint, limit in LIMITS.items())
    channels = []
    for evidence in pilot.evidence():
        if evidence["origin"].endswith("/channels"):
            for channel, raw in evidence["raw_fields"].items():
                snippet, stats = raw["snippet"], raw["statistics"]
                channels.append("<article>" + fields([
                    ("频道 ID", channel), ("标题", snippet.get("title")), ("描述", snippet.get("description")),
                    ("语言", snippet.get("defaultLanguage")), ("国家", snippet.get("country")),
                    ("发布日期", snippet.get("publishedAt")), ("订阅数", stats.get("subscriberCount")),
                    ("隐藏订阅数", stats.get("hiddenSubscriberCount")), ("上传列表", raw.get("uploads")),
                    ("获取时间 UTC", evidence["acquired_at"]),
                ]) + "</article>")
    observations = "".join("<article>" + fields([
        ("关联编号", channel), ("独立来源", url), ("记录时间 UTC", acquired), ("人工核验", note),
    ]) + "</article>" for channel, url, acquired, note in pilot.independent_evidence())
    state = pilot.batch_state()
    mode = "模拟数据" if pilot.simulated else "真实试跑"
    return f"""<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CreatorHub 试跑预览</title><style>{STYLE}</style><main>
<header><div><h1>CreatorHub 试跑预览</h1><small>批次 {escape(pilot.directory.name)} · {state}</small></div>
<strong class="mode">{mode} · 只读</strong></header>
<section><h2>请求预算 {sum(counts.values())}/{sum(LIMITS.values())}</h2><p>{quotas}</p></section>
<section><div class="source"><h2>YouTube Data API 原值</h2>
<a href="https://www.youtube.com/" rel="noreferrer" aria-label="打开 YouTube 首页"><img src="/youtube-logo.svg" alt="YouTube"></a></div>
<div id="api-values">{''.join(channels) or '<p>无可读取的 API 原值。</p>'}</div></section>
<section><h2>独立来源与人工核验</h2><small>人工记录与 YouTube 无关。</small>
{observations or '<p>无独立来源记录。</p>'}</section>
</main><script>{SCRIPT}</script></html>"""


def create_preview(directory):
    pilot = Pilot(directory, FixtureTransport([]), mode="offline", readonly=True)
    return preview_app(pilot)


def preview_app(pilot):
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware("http")
    async def preview_headers(request: Request, call_next):
        if request.url.hostname != "127.0.0.1":
            response = PlainTextResponse("Loopback only", status_code=403)
        else:
            response = await call_next(request)
        response.headers.update({
            "Cache-Control": "no-store, private, max-age=0",
            "Pragma": "no-cache",
            "Referrer-Policy": "no-referrer",
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; "
            f"script-src 'sha256-{SCRIPT_HASH}'; frame-ancestors 'none'; form-action 'none'; base-uri 'none'",
        })
        return response

    @app.get("/", response_class=HTMLResponse)
    def preview():
        return render(pilot)

    @app.get("/youtube-logo.svg", response_class=FileResponse)
    def logo():
        return FileResponse(LOGO, media_type="image/svg+xml")

    return app


if __name__ == "__main__":
    import uvicorn

    parser = argparse.ArgumentParser(description="Synthetic CreatorHub pilot preview")
    parser.add_argument("action", choices=("seed", "serve", "finish"))
    parser.add_argument("directory", type=Path)
    parser.add_argument("--port", type=int, default=44239)
    args = parser.parse_args()
    if args.action == "seed":
        seed(args.directory)
    elif args.action == "finish":
        Pilot(args.directory, FixtureTransport([]), mode="offline").purge(finish=True)
    else:
        uvicorn.run(create_preview(args.directory), host="127.0.0.1", port=args.port)
