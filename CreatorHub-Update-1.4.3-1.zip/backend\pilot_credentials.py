"""Read the dedicated Windows generic credential only after launch authorization."""
import ctypes
from ctypes import wintypes


TARGET = "CreatorHub-Pilot-YouTube"


class Credential(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD),
        ("TargetName", wintypes.LPWSTR), ("Comment", wintypes.LPWSTR),
        ("LastWritten", wintypes.FILETIME), ("CredentialBlobSize", wintypes.DWORD),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)), ("Persist", wintypes.DWORD),
        ("AttributeCount", wintypes.DWORD), ("Attributes", ctypes.c_void_p),
        ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR),
    ]


def read_key():
    library = ctypes.WinDLL("advapi32.dll", use_last_error=True)
    read, free = library.CredReadW, library.CredFree
    pointer = ctypes.POINTER(Credential)()
    read.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(type(pointer))]
    read.restype = wintypes.BOOL
    free.argtypes, free.restype = [ctypes.c_void_p], None
    if not read(TARGET, 1, 0, ctypes.byref(pointer)):  # CRED_TYPE_GENERIC
        raise RuntimeError("CREDENTIAL_UNAVAILABLE")
    try:
        blob, size = pointer.contents.CredentialBlob, pointer.contents.CredentialBlobSize
        if not blob or not 2 <= size <= 258 or size % 2:
            raise RuntimeError("CREDENTIAL_INVALID")
        return ctypes.string_at(blob, size).decode("utf-16-le").removesuffix("\0")
    finally:
        free(pointer)
