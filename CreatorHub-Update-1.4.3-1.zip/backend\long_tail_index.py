"""Lightweight SQLite long-tail creator index fed by streaming open datasets (E-drive tiered)."""
from __future__ import annotations

import json
from pathlib import Path
import re
import sqlite3
from urllib.parse import quote
from urllib.request import Request, urlopen

from .store import dump, load, now

USER_AGENT = "CreatorHub/1.4 (+long-tail-index)"

OPEN_DATASETS = (
    {
        "dataset": "limloop/youtube_channels_embeddings_dataset",
        "license": "MIT(数据集卡片声明；底层为 YouTube 公开元数据，仅作内部发现线索)",
        "label": "开放数据集线索 (limloop, MIT 卡片)",
    },
    {
        "dataset": "common-pile/youtube",
        "license": "视频级 CC BY（数据集卡片无整体许可声明；仅作内部发现线索）",
        "label": "开放数据集线索 (Common Pile YouTube, CC BY 视频)",
    },
)


def default_index_path() -> Path:
    """Portable location: env override, else next to the business DB (user data dir), else ./var."""
    import os
    override = os.environ.get("CREATORHUB_LONGTAIL_INDEX")
    if override:
        return Path(override)
    db = os.environ.get("CREATORHUB_DB")
    if db:
        return Path(db).resolve().parent / "long_tail_index.sqlite3"
    local_dir = Path(__file__).resolve().parents[1] / "var"
    local_dir.mkdir(parents=True, exist_ok=True)
    return local_dir / "long_tail_index.sqlite3"


class LongTailIndex:
    """Lightweight SQLite index separate from formal business accounts."""

    def __init__(self, path: Path | None = None):
        self.path = path or default_index_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute(
                """
                CREATE TABLE IF NOT EXISTS long_tail_channels (
                    channel_id TEXT PRIMARY KEY,
                    channel_name TEXT NOT NULL,
                    channel_url TEXT NOT NULL,
                    handle TEXT,
                    sample_titles TEXT NOT NULL DEFAULT '[]',
                    content_tags TEXT NOT NULL DEFAULT '[]',
                    latest_published_at TEXT,
                    source_dataset TEXT NOT NULL,
                    license TEXT NOT NULL,
                    indexed_at TEXT NOT NULL
                )
                """
            )
            db.execute("CREATE INDEX IF NOT EXISTS idx_lt_name ON long_tail_channels(channel_name)")

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def stats(self) -> dict:
        with self._connect() as db:
            count = db.execute("SELECT COUNT(*) FROM long_tail_channels").fetchone()[0]
        size_bytes = self.path.stat().st_size if self.path.exists() else 0
        return {"channels": count, "size_bytes": size_bytes, "path": str(self.path)}

    def upsert_many(self, rows: list[dict]) -> int:
        if not rows:
            return 0
        ts = now()
        inserted = 0
        with self._connect() as db:
            for item in rows:
                cid = item.get("channel_id")
                if not cid or not str(cid).startswith("UC"):
                    continue
                existing = db.execute(
                    "SELECT sample_titles, content_tags, latest_published_at FROM long_tail_channels WHERE channel_id=?",
                    (cid,),
                ).fetchone()
                titles = load(existing["sample_titles"]) if existing else []
                tags = load(existing["content_tags"]) if existing else []
                for t in item.get("sample_titles") or []:
                    if t and t not in titles and len(titles) < 10:
                        titles.append(t[:200])
                for tg in item.get("content_tags") or []:
                    if tg and tg not in tags and len(tags) < 15:
                        tags.append(str(tg)[:60])
                pub = item.get("latest_published_at") or (existing["latest_published_at"] if existing else None)
                if existing and item.get("latest_published_at") and existing["latest_published_at"]:
                    pub = max(existing["latest_published_at"], item["latest_published_at"])
                db.execute(
                    """
                    INSERT INTO long_tail_channels(
                        channel_id, channel_name, channel_url, handle, sample_titles, content_tags,
                        latest_published_at, source_dataset, license, indexed_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(channel_id) DO UPDATE SET
                        sample_titles=excluded.sample_titles,
                        content_tags=excluded.content_tags,
                        latest_published_at=excluded.latest_published_at,
                        indexed_at=excluded.indexed_at
                    """,
                    (
                        cid,
                        (item.get("channel_name") or cid)[:200],
                        item.get("channel_url") or f"https://www.youtube.com/channel/{cid}",
                        item.get("handle"),
                        dump(titles),
                        dump(tags),
                        pub,
                        item["source_dataset"],
                        item["license"],
                        ts,
                    ),
                )
                if not existing:
                    inserted += 1
        return inserted

    def search_local(self, keywords: list[str], limit: int = 50) -> list[dict]:
        if not keywords:
            return []
        clauses = []
        params = []
        for kw in keywords[:8]:
            like = f"%{kw.strip()}%"
            clauses.append("(channel_name LIKE ? OR sample_titles LIKE ? OR content_tags LIKE ?)")
            params.extend([like, like, like])
        sql = f"SELECT * FROM long_tail_channels WHERE {' OR '.join(clauses)} LIMIT ?"
        params.append(limit)
        with self._connect() as db:
            rows = db.execute(sql, params).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["sample_titles"] = load(d["sample_titles"])
            d["content_tags"] = load(d["content_tags"])
            out.append(d)
        return out

    def stream_search_and_index(self, keywords: list[str], limit_per_query: int = 15) -> list[dict]:
        """Stream matching metadata rows from HuggingFace datasets-server (no full download, no transcripts)."""
        collected: dict[str, dict] = {}
        for kw in keywords[:6]:
            for ds_cfg in OPEN_DATASETS:
                ds = ds_cfg["dataset"]
                url = (
                    "https://datasets-server.huggingface.co/search?"
                    f"dataset={quote(ds)}&config=default&split=train&length={limit_per_query}&query={quote(kw)}"
                )
                try:
                    req = Request(url, headers={"User-Agent": USER_AGENT})
                    with urlopen(req, timeout=12) as resp:
                        payload = json.loads(resp.read().decode("utf-8"))
                except Exception:
                    continue
                for entry in payload.get("rows") or []:
                    row = entry.get("row") or {}
                    if ds == "limloop/youtube_channels_embeddings_dataset":
                        c_url = str(row.get("channel_url") or "")
                        m = re.search(r"(UC[A-Za-z0-9_-]{22})", c_url)
                        if not m:
                            continue
                        cid = m.group(1)
                        item = {
                            "channel_id": cid,
                            "channel_name": str(row.get("title") or cid),
                            "channel_url": f"https://www.youtube.com/channel/{cid}",
                            "handle": row.get("uploader_id"),
                            "sample_titles": [kw],
                            "content_tags": [kw],
                            "latest_published_at": None,
                            "source_dataset": ds_cfg["label"],
                            "license": ds_cfg["license"],
                        }
                    else:
                        cid = str(row.get("channel_id") or "")
                        if not re.fullmatch(r"UC[A-Za-z0-9_-]{22}", cid):
                            continue
                        raw_tags = row.get("tags")
                        if isinstance(raw_tags, list):
                            tags = [str(t) for t in raw_tags[:10]]
                        elif isinstance(raw_tags, str) and raw_tags not in ("None", ""):
                            tags = [raw_tags[:60]]
                        else:
                            tags = [kw]
                        item = {
                            "channel_id": cid,
                            "channel_name": cid,
                            "channel_url": f"https://www.youtube.com/channel/{cid}",
                            "handle": None,
                            "sample_titles": [str(row.get("title") or "")[:200]] if row.get("title") else [],
                            "content_tags": tags,
                            "latest_published_at": str(row.get("published_time") or "")[:19] or None,
                            "source_dataset": ds_cfg["label"],
                            "license": ds_cfg["license"],
                        }
                    if cid not in collected:
                        collected[cid] = item
                    else:
                        for t in item["sample_titles"]:
                            if t and t not in collected[cid]["sample_titles"]:
                                collected[cid]["sample_titles"].append(t)
        rows = list(collected.values())
        self.upsert_many(rows)
        return rows
