"""B1 launcher: execute and clean up one synthetic batch only."""
from argparse import ArgumentParser
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from .pilot_wer import verify_noheap
from .pilot_approval import ROOT, POLICY_VERSION, authorized_batch


POLICY = Path(__file__).resolve().parents[1] / "04_reports" / "PHASE_2_B1_OPERATOR_POLICY.md"
WER_FAILURES = {
    21: "WER_UNAVAILABLE",
    22: "WER_READ_FAILED",
    23: "WER_SET_FAILED",
    24: "WER_FLAG_MISSING",
}


def worker(batch):
    status = verify_noheap()
    if status != "WER_NOHEAP_VERIFIED":
        return next((code for code, name in WER_FAILURES.items() if name == status), 21)
    try:
        from .pilot_preview import seed
        from .youtube_pilot import FixtureTransport, LIMITS, Pilot

        data = batch / "data"
        if (not batch.name.startswith("b1-synthetic-")
                or Path(tempfile.gettempdir()).resolve() != (batch / "tmp").resolve()):
            return 25
        seed(data)
        pilot = Pilot(data, FixtureTransport([]), mode="offline")
        count = len(pilot.ledger())
        if count != 4 or sum(LIMITS.values()) != 15 or not pilot.evidence():
            return 26
        pilot.purge(finish=True)
        if pilot.evidence() or len(pilot.ledger()) != count or not pilot.independent_evidence():
            return 26
        return 0
    except Exception:
        return 26


def grant_for(root, batch, consent):
    from .pilot_approval import APPROVED_SHA256
    import re

    if not APPROVED_SHA256 or not re.fullmatch(r"live-[a-z0-9-]{1,48}", batch or ""):
        return None
    path = root / f"{batch}.approval.json"
    with path.open("rb") as file:
        grant = file.read(4097)
    return grant if len(grant) <= 4096 and authorized_batch(root, batch, consent, grant) else None


def live_worker(batch, consent):
    try:
        grant = grant_for(ROOT, batch.name, consent)
        if (grant is None or batch != ROOT / batch.name or batch.resolve() != batch
                or Path(tempfile.gettempdir()).resolve() != (batch / "tmp").resolve()):
            return 25
        status = verify_noheap()
        if status != "WER_NOHEAP_VERIFIED":
            return next((code for code, name in WER_FAILURES.items() if name == status), 21)
        from .pilot_credentials import read_key
        from .youtube_pilot import Pilot

        pilot = Pilot(batch / "data", mode="live", approval=grant, api_key=read_key(), create=True)
        pilot.run()
        return 0
    except Exception:
        return 26


def finish(root, batch_id, consent):
    try:
        grant = grant_for(root, batch_id, consent)
        if grant is None:
            return {"status": "LIVE_LOCKED"}
        from .youtube_pilot import Pilot

        pilot = Pilot(root / batch_id / "data", mode="live", approval=grant, cleanup_only=True)
        pilot.purge(finish=True)
        return {"status": "CLEANUP_VERIFIED" if not pilot.evidence() else "CLEANUP_FAILED",
                "attempts": len(pilot.ledger())}
    except Exception:
        return {"status": "CLEANUP_FAILED"}


def view(root, batch_id, consent):
    try:
        grant = grant_for(root, batch_id, consent)
        if grant is None:
            return 1
        if verify_noheap() != "WER_NOHEAP_VERIFIED":
            return 1
        import uvicorn
        from .pilot_preview import preview_app
        from .youtube_pilot import Pilot

        pilot = Pilot(root / batch_id / "data", mode="live", approval=grant,
                      cleanup_only=True, readonly=True)
        uvicorn.run(preview_app(pilot), host="127.0.0.1", port=44239, log_config=None, access_log=False)
        return 0
    except Exception:
        return 1


def launch(root, *, mode, consent, batch_id=None):
    if mode not in ("synthetic", "live"):
        return {"status": "LIVE_LOCKED", "real_requests": 0}
    live = mode == "live"
    if live:
        try:
            if grant_for(root, batch_id, consent) is None:
                return {"status": "LIVE_LOCKED", "real_requests": 0}
        except OSError:
            return {"status": "LIVE_LOCKED", "real_requests": 0}
    if consent != POLICY_VERSION or not POLICY.is_file():
        return {"status": "CONSENT_REQUIRED", "real_requests": 0}
    try:
        if not root.is_dir() or root.resolve(strict=True) != root.absolute():
            return {"status": "BATCH_ROOT_INVALID", "real_requests": 0}
        if live:
            batch = root / batch_id
            batch.mkdir()
        else:
            batch = Path(tempfile.mkdtemp(prefix="b1-synthetic-", dir=root))
        for name in ("tmp", "data", "logs"):
            (batch / name).mkdir()
        env = {key: value for key, value in os.environ.items()
               if key.upper() in {"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC"}}
        env.update(dict.fromkeys(("TEMP", "TMP", "TMPDIR"), str(batch / "tmp")))
        try:
            command = [sys.executable, "-E", "-s", "-m", "backend.pilot_launcher"]
            command += ["--live-worker", str(batch), consent] if live else ["--worker", str(batch)]
            result = subprocess.run(
                command,
                cwd=POLICY.parents[1],
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=135 if live else 60,
                check=False,
            )
            status = WER_FAILURES.get(result.returncode, "BATCH_REJECTED" if result.returncode == 25 else "RUN_FAILED")
            if result.returncode == 0:
                status = "LIVE_COMPLETE" if live else "WER_NOHEAP_VERIFIED"
        except (OSError, subprocess.TimeoutExpired):
            status = "WORKER_FAILED"
        summary = {"status": status}
        if not live or status in {*WER_FAILURES.values(), "BATCH_REJECTED"}:
            summary["real_requests"] = 0
        if status == "WER_NOHEAP_VERIFIED":
            summary.update(synthetic_attempts=4, budget=15, cleanup_verified=True, policy=POLICY_VERSION)
        (batch / "logs" / "summary.log").write_text(json.dumps(summary) + "\n", encoding="utf-8")
        (batch / "logs" / "diagnostic.log").write_text(status + "\n", encoding="utf-8")
        return summary
    except OSError:
        return {"status": "LOCAL_IO_FAILED"} if live else {"status": "LOCAL_IO_FAILED", "real_requests": 0}


def main(argv):
    if len(argv) == 3 and argv[0] == "--live-worker":
        return live_worker(Path(argv[1]), argv[2])
    if len(argv) == 2 and argv[0] == "--worker":
        return worker(Path(argv[1]))
    parser = ArgumentParser(description="CreatorHub 合成预检，真实模式锁定")
    parser.add_argument("--show-policy", action="store_true")
    parser.add_argument("--accept-policy")
    parser.add_argument("--mode", choices=("synthetic", "live"), default="synthetic")
    parser.add_argument("--batch")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--finish", action="store_true")
    action.add_argument("--view", action="store_true")
    args = parser.parse_args(argv)
    if args.show_policy:
        print(POLICY.read_text(encoding="utf-8"))
        return 0
    if args.view:
        return view(ROOT, args.batch, args.accept_policy)
    summary = (finish(ROOT, args.batch, args.accept_policy) if args.finish else
               launch(ROOT, mode=args.mode, consent=args.accept_policy, batch_id=args.batch))
    print(json.dumps(summary))
    return 0 if summary["status"] in {"WER_NOHEAP_VERIFIED", "LIVE_COMPLETE", "CLEANUP_VERIFIED"} else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
