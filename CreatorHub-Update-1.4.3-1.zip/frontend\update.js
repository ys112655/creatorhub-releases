// 设置与软件更新：显示当前版本，检查更新，一键更新并重启
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export async function updatePage(main, api, toast) {
  let info = { version: {}, manifest_url: "" };
  try { info = await api("/update/info"); } catch (e) { info = { version: {}, manifest_url: "" }; }

  main.innerHTML =
    '<section class="hero"><div><h1>设置与软件更新</h1>' +
    "<p>查看当前版本，检查并安装新版本。更新会下载、校验、自动备份数据并在完成后重启。</p></div></section>" +
    '<section class="panel"><h2>当前版本</h2>' +
    '<p class="hint">版本 <b>' + esc((info.version && info.version.version) || "未知") + "</b> · 构建 " +
    esc((info.version && info.version.build) ?? "—") + " · 数据库结构 " +
    esc((info.version && info.version.schema_version) ?? "—") + " · 当前达人数 <b>" +
    esc(info.accounts_count ?? 0) + "</b></p>" +
    '<div class="actions"><button class="primary" id="update-check">检查更新</button>' +
    '<span class="hint" id="update-manifest">' + (info.manifest_url ? "更新源：" + esc(info.manifest_url) : "未配置更新源") + "</span></div>" +
    '<div id="update-result"></div></section>' +
    '<section class="panel"><h2>数据迁移（V1.2 → V1.3）</h2>' +
    '<p class="hint">导入 V1.2 的业务数据库时，不会改动 V1.2 原文件，并在覆盖前自动备份当前 V1.3 数据库。</p>' +
    '<div class="form"><label>V1.2 UserData 目录或 trial.sqlite3 路径' +
    '<input id="v12-source" value="' + esc(info.v12_detected || "") + '" placeholder="例如 C:\\Users\\...\\Downloads\\CreatorHub-V1.2\\UserData"></label></div>' +
    '<div class="actions"><button id="v12-migrate">从 V1.2 导入业务数据库</button></div>' +
    '<div id="v12-result"></div></section>';

  const $ = s => main.querySelector(s);
  const result = $("#update-result");
  const v12Result = $("#v12-result");

  $("#v12-migrate").addEventListener("click", async ev => {
    ev.target.disabled = true;
    try {
      const res = await api("/update/migrate-v12", "POST", { source_path: $("#v12-source").value.trim() });
      v12Result.innerHTML = '<p class="hint">迁移成功：导入达人 <b>' + esc(res.accounts_count) + '</b> 条、项目 <b>' + esc(res.projects_count) + '</b> 个。' +
        (res.backup_path ? "（已自动备份原库至 " + esc(res.backup_path) + "）" : "") + "</p>";
      toast("V1.2 数据迁移完成");
    } catch (error) {
      toast(error.message, true);
    } finally {
      ev.target.disabled = false;
    }
  });

  $("#update-check").addEventListener("click", async e => {
    e.target.disabled = true;
    try {
      const data = await api("/update/check", "POST");
      if (!data.update_available) {
        result.innerHTML = '<p class="hint">已是最新版本。</p>';
        return;
      }
      const m = data.manifest || {};
      result.innerHTML =
        '<div class="panel"><h3>发现新版本 ' + esc(m.version) + "</h3>" +
        "<p>更新日志：</p><ul>" + (m.changelog || []).map(line => "<li>" + esc(line) + "</li>").join("") + "</ul>" +
        '<div class="actions"><button class="primary" id="update-apply">立即更新</button></div></div>';
      $("#update-apply").addEventListener("click", async ev => {
        ev.target.disabled = true;
        ev.target.textContent = "更新中，请稍候…";
        try {
          const applied = await api("/update/apply", "POST");
          result.innerHTML = '<div class="panel"><h3>更新完成</h3><p>已升级到 ' + esc(applied.installed) +
            "，应用即将重启。</p></div>";
          toast("更新完成，正在重启…");
          api("/update/restart", "POST").catch(() => {});
          setTimeout(() => location.reload(), 3000);
        } catch (error) { toast(error.message, true); }
      });
    } catch (error) {
      toast(error.message, true);
    } finally {
      e.target.disabled = false;
    }
  });
}
