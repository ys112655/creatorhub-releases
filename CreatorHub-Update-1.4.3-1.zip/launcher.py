import sys
from pathlib import Path
port = int(sys.argv[2])
sys.path.insert(0, str(Path(__file__).parent))
import uvicorn
config = uvicorn.Config("backend.app:runtime_app", factory=True,
                        host="127.0.0.1", port=port, access_log=False, loop="asyncio", http="h11", ws="none")
uvicorn.Server(config).run()
