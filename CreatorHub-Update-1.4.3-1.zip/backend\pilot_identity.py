"""SQLite application IDs reserved for the isolated offline pilot."""

PILOT_DATABASE_IDS = (0x43504132, 0x43504932)
