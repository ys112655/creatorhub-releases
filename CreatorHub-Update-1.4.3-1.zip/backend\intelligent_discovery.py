"""V1.4 Intelligent YouTube Discovery: rule-based brief->keywords, pluggable providers, Shorts separation, cache reuse."""
from __future__ import annotations

from datetime import date, timedelta
import html
from io import BytesIO
import json
from pathlib import Path
import re
from statistics import median
import sys
from threading import Event, Thread
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

from . import discovery
from . import freshness
from .long_tail_index import LongTailIndex
from .permissions import prepare_policy, governed_profile, ImportPolicy
from .store import dump, load, now

SCALE_TARGETS = {"quick": 30, "standard": 100, "deep": 300}

EXTENDED_KEYWORDS = (
    ("AI Video", ("ai video", "sora", "runway", "kling", "veo", "luma", "hailuo", "视频生成"),
     ("AI video generation", "AI video workflow")),
    ("ComfyUI", ("comfyui", "comfy", "node", "flux", "wan2"),
     ("ComfyUI workflow", "ComfyUI video tutorial")),
    ("AI Filmmaking", ("filmmaking", "ai film", "short film", "cinema", "电影"),
     ("AI filmmaking", "AI short film")),
    ("VFX & CGI", ("vfx", "after effects", "blender", "unreal", "houdini", "特效"),
     ("VFX tutorial", "AI VFX breakdown")),
    ("AI Animation", ("animation", "anime", "动画", "cartoon"),
     ("AI animation", "AI character animation")),
)

USER_AGENT = "CreatorHub/1.4 (+intelligent-discovery)"


def _try_import_ytdlp():
    try:
        import yt_dlp  # type: ignore
        return yt_dlp
    except ImportError:
        poc_vendor = Path(__file__).resolve().parents[2] / "keyless-discovery-poc" / "vendor"
        if poc_vendor.is_dir() and str(poc_vendor) not in sys.path:
            sys.path.insert(0, str(poc_vendor))
            try:
                import yt_dlp  # type: ignore
                return yt_dlp
            except ImportError:
                return None
    return None


def get_experimental_enabled(db) -> bool:
    row = db.execute("SELECT value FROM discovery_settings WHERE key='experimental_ytdlp_enabled'").fetchone()
    return bool(row and row["value"] == "1")


def set_experimental_enabled(db, enabled: bool) -> bool:
    db.execute(
        "INSERT INTO discovery_settings(key, value, updated_at) VALUES('experimental_ytdlp_enabled', ?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
        ("1" if enabled else "0", now()),
    )
    return enabled


def brief_to_keywords(brief: str) -> list[str]:
    """Convert natural-language brief into YouTube search keywords without LLM calls."""
    text = (brief or "").strip()
    lowered = text.casefold()
    found: list[str] = []
    for _label, needles, terms in EXTENDED_KEYWORDS:
        if any(n in lowered for n in needles):
            for t in terms:
                if t not in found:
                    found.append(t)
    # Extract multi-word English phrases (e.g., "3D printing", "AI video generation")
    for phrase in re.findall(r"[A-Za-z0-9][A-Za-z0-9.+-]*(?:\s+[A-Za-z0-9.+-]+){1,3}", text):
        cleaned = phrase.strip()
        if len(cleaned) >= 4 and cleaned not in found:
            found.append(cleaned)
    # Fallback: split CJK/comma clauses or single English words if nothing matched
    if not found and text:
        for part in re.split(r"[，,。；;\n]+", text):
            p = part.strip()
            if 2 <= len(p) <= 40 and p not in found:
                found.append(p)
    for word in re.findall(r"[A-Za-z][A-Za-z0-9.+-]{2,}", text):
        if word.lower() not in {"youtube", "creator", "creators", "channel", "channels", "for", "and", "the"} and word not in found:
            found.append(word)
    return found[:8]


def _parse_compact_count(raw: str) -> int | None:
    if not raw:
        return None
    m = re.search(r"([\d,.]+)\s*([KMBkmb]?)", str(raw))
    if not m:
        return None
    val = float(m.group(1).replace(",", ""))
    mult = {"": 1, "k": 1_000, "m": 1_000_000, "b": 1_000_000_000}.get((m.group(2) or "").upper(), 1)
    return int(round(val * mult))


def _http_get(url: str, timeout: int = 12) -> str:
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"})
    try:
        with urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except HTTPError as exc:
        if exc.code in (403, 429):
            raise RateLimitError(f"触发平台限流或访问限制 HTTP {exc.code}") from None
        raise RuntimeError(f"HTTP {exc.code}") from None
    except (URLError, TimeoutError, OSError) as exc:
        raise RuntimeError(f"网络请求失败：{exc}") from None


class RateLimitError(RuntimeError):
    pass


def split_video_metrics(videos: list[dict]) -> dict:
    """Separate long-form videos from Shorts so mixed averages do not mislead."""
    long_views, short_views, all_views = [], [], []
    long_count, shorts_count = 0, 0
    for v in videos:
        url = (v.get("url") or "").lower()
        title = (v.get("title") or "").lower()
        desc = (v.get("description") or "").lower()
        dur = v.get("duration")
        is_short = "/shorts/" in url or "#shorts" in title or "#shorts" in desc or (isinstance(dur, (int, float)) and 0 < dur <= 60)
        views = v.get("views")
        if is_short:
            shorts_count += 1
            if isinstance(views, int):
                short_views.append(views)
                all_views.append(views)
        else:
            long_count += 1
            if isinstance(views, int):
                long_views.append(views)
                all_views.append(views)
    return {
        "recent_sample_count": len(all_views),
        "recent_avg_views": round(sum(all_views) / len(all_views), 2) if all_views else None,
        "recent_median_views": round(float(median(all_views)), 2) if all_views else None,
        "long_count": long_count,
        "long_avg_views": round(sum(long_views) / len(long_views), 2) if long_views else None,
        "long_median_views": round(float(median(long_views)), 2) if long_views else None,
        "shorts_count": shorts_count,
        "shorts_avg_views": round(sum(short_views) / len(short_views), 2) if short_views else None,
    }


def analyze_verticality_and_relevance(brief: str, keywords: list[str], display_name: str, videos: list[dict]) -> tuple[list[str], int, list[str]]:
    """Rule-based vertical classification + relevance score + human-readable evidence."""
    corpus_parts = [display_name or ""]
    for v in videos[:15]:
        corpus_parts.append(v.get("title") or "")
        corpus_parts.append(v.get("description") or "")
    corpus = " ".join(corpus_parts).casefold()

    verticals: list[str] = []
    evidence: list[str] = []
    for label, needles, _terms in EXTENDED_KEYWORDS:
        hits = [n for n in needles if n in corpus]
        if hits:
            verticals.append(label)
            evidence.append(f"垂直领域「{label}」命中词：{', '.join(hits[:3])}")

    kw_hits = []
    for kw in keywords:
        tokens = [t for t in re.split(r"\s+", kw.casefold()) if len(t) >= 2]
        if kw.casefold() in corpus or (tokens and all(t in corpus for t in tokens)):
            kw_hits.append(kw)
    if kw_hits:
        evidence.append(f"命中检索关键词：{', '.join(kw_hits[:3])}")

    sample_titles = [v.get("title", "") for v in videos[:2] if v.get("title")]
    if sample_titles:
        evidence.append("近期代表作：" + " / ".join(t[:48] for t in sample_titles))

    score = min(100, 20 + len(verticals) * 20 + len(kw_hits) * 20 + (10 if videos else 0))
    if not verticals and not kw_hits:
        score = 15
    return verticals, score, evidence


class OfficialRssDiscoveryProvider:
    """Official unauthenticated YouTube Atom RSS + optional public channel page subscriber count."""

    source_type = "official_rss"
    source_name = "YouTube 官方 Atom RSS"

    @staticmethod
    def fetch_rss(channel_id: str) -> dict:
        xml_text = _http_get(f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}")
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as exc:
            raise RuntimeError("YouTube RSS 返回格式异常") from exc
        ns = {"atom": "http://www.w3.org/2005/Atom", "media": "http://search.yahoo.com/mrss/"}
        title = (root.findtext("atom:title", default="", namespaces=ns) or "").strip()
        videos = []
        for entry in root.findall("atom:entry", ns)[:15]:
            v_title = (entry.findtext("atom:title", default="", namespaces=ns) or "").strip()
            link_el = entry.find("atom:link", ns)
            v_url = link_el.attrib.get("href", "") if link_el is not None else ""
            pub = (entry.findtext("atom:published", default="", namespaces=ns) or "").strip()
            desc = (entry.findtext("media:group/media:description", default="", namespaces=ns) or "").strip()
            stats = entry.find("media:group/media:community/media:statistics", ns)
            views = int(stats.attrib["views"]) if (stats is not None and stats.attrib.get("views", "").isdigit()) else None
            if v_title:
                videos.append({"title": v_title[:300], "url": v_url, "published": pub, "views": views, "description": desc[:400]})
        return {"display_name": title, "videos": videos}

    @staticmethod
    def fetch_public_subscribers(channel_id: str) -> tuple[int | None, str | None]:
        page = _http_get(f"https://www.youtube.com/channel/{channel_id}")
        m = re.search(r'"subscriberCountText":\{"(?:accessibility":\{[^}]*\},"|simpleText":")([^"]+)"', page)
        if not m:
            m = re.search(r'([\d.,]+\s*[KMB]?)\s+subscribers', page, re.I)
        subs = _parse_compact_count(m.group(1)) if m else None
        hm = re.search(r'https://www\.youtube\.com/(@[A-Za-z0-9_.-]+)', page)
        return subs, (hm.group(1) if hm else None)


class WikidataRssDiscoveryProvider:
    """Compliant keyless discovery via Wikidata Action API (CC0 P2397) + Official YouTube Atom RSS."""

    source_type = "wikidata_rss"
    source_name = "Wikidata (CC0) + YouTube 官方 RSS"
    rate_limited = False

    def search_channels(self, keywords: list[str], target_count: int, cancel_event: Event) -> list[dict]:
        discovered: dict[str, dict] = {}
        for kw in keywords[:5]:
            if cancel_event.is_set() or len(discovered) >= target_count:
                break
            time.sleep(0.4)
            query = f"haswbstatement:P2397 {kw}"
            search_url = (
                "https://www.wikidata.org/w/api.php?action=query&list=search&srlimit=25&format=json&srsearch="
                + quote(query)
            )
            try:
                data = json.loads(_http_get(search_url))
            except RateLimitError:
                self.rate_limited = True
                break  # back off: keep what was already found
            except Exception:
                continue
            hits = data.get("query", {}).get("search", [])
            qids = [h["title"] for h in hits if h.get("title")]
            if not qids:
                continue
            ent_url = (
                "https://www.wikidata.org/w/api.php?action=wbgetentities&ids="
                + quote("|".join(qids[:25]))
                + "&props=labels|descriptions|claims&languages=en&format=json"
            )
            try:
                entities = json.loads(_http_get(ent_url)).get("entities", {})
            except RateLimitError:
                self.rate_limited = True
                break
            except Exception:
                continue
            for qid, ent in entities.items():
                claims = ent.get("claims", {}).get("P2397", [])
                label = ent.get("labels", {}).get("en", {}).get("value") or qid
                for claim in claims:
                    cid = claim.get("mainsnak", {}).get("datavalue", {}).get("value")
                    if cid and str(cid).startswith("UC") and cid not in discovered:
                        discovered[cid] = {
                            "channel_id": cid,
                            "display_name": label,
                            "url": f"https://www.youtube.com/channel/{cid}",
                            "source_type": self.source_type,
                            "source_name": self.source_name,
                            "skip_html_subs": True,
                        }
                        if len(discovered) >= target_count:
                            return list(discovered.values())
        return list(discovered.values())


class ExperimentalYtDlpDiscoveryProvider:
    """Default-OFF experimental adapter reusing yt-dlp flat search (no cookies, no video download)."""

    source_type = "experimental_ytdlp"
    source_name = "yt-dlp 公开检索实验适配器 + 官方 RSS"

    def search_channels(self, keywords: list[str], target_count: int, cancel_event: Event) -> list[dict]:
        yt_dlp = _try_import_ytdlp()
        if yt_dlp is None:
            raise RuntimeError("未检测到 yt-dlp 模块，请使用本地库匹配、官方 RSS 或授权批量导入")
        per_kw = max(15, min(60, (target_count // max(1, len(keywords))) + 15))
        discovered: dict[str, dict] = {}
        opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "skip_download": True, "ignoreerrors": True}
        with yt_dlp.YoutubeDL(opts) as ydl:
            for kw in keywords:
                if cancel_event.is_set():
                    break
                info = ydl.extract_info(f"ytsearch{per_kw}:{kw}", download=False)
                for entry in (info or {}).get("entries") or []:
                    if not entry:
                        continue
                    cid = entry.get("channel_id")
                    if not cid or not str(cid).startswith("UC"):
                        continue
                    if cid not in discovered:
                        discovered[cid] = {
                            "channel_id": cid,
                            "display_name": entry.get("channel") or entry.get("uploader") or cid,
                            "url": f"https://www.youtube.com/channel/{cid}",
                            "matched_video": {"title": entry.get("title") or "", "url": entry.get("url") or "", "views": entry.get("view_count"), "duration": entry.get("duration")},
                        }
                    if len(discovered) >= target_count:
                        return list(discovered.values())
        return list(discovered.values())


class IntelligentDiscoveryService:
    """Orchestrates V1.4 discovery jobs: brief->keywords -> local cache -> optional provider -> review -> commit."""

    def __init__(self, store, index: LongTailIndex | None = None):
        self.store = store
        self.db_factory = store.connection
        self.index = index or LongTailIndex()
        self._cancel_flags: dict[int, Event] = {}

    def config(self) -> dict:
        with self.db_factory(True) as db:
            enabled = get_experimental_enabled(db)
        return {
            "experimental_ytdlp_enabled": enabled,
            "ytdlp_available": _try_import_ytdlp() is not None,
            "scales": SCALE_TARGETS,
        }

    def set_config(self, experimental_ytdlp_enabled: bool) -> dict:
        with self.db_factory(True) as db:
            set_experimental_enabled(db, experimental_ytdlp_enabled)
        return self.config()

    def start_job(
        self,
        brief: str,
        keywords: list[str] | None = None,
        scale: str = "standard",
        project_id: int | None = None,
        mode: str = "auto",
        authorized_candidates: list[dict] | None = None,
    ) -> dict:
        if scale not in SCALE_TARGETS:
            raise ValueError("不支持的搜索规模")
        target = SCALE_TARGETS[scale]
        kw_list = [k.strip() for k in (keywords or []) if k and k.strip()] or brief_to_keywords(brief)
        if not kw_list:
            raise ValueError("请提供自然语言需求或至少一个搜索关键词")
        with self.db_factory(True) as db:
            exp_enabled = get_experimental_enabled(db)
            effective_mode = mode
            if mode == "auto":
                effective_mode = "experimental_ytdlp" if exp_enabled else "local_and_rss"
            if effective_mode == "experimental_ytdlp" and not exp_enabled:
                raise ValueError("非官方自动采集适配器默认关闭；请先在合规开关中确认启用，或使用本地库匹配与授权导入")
            ts = now()
            cur = db.execute(
                "INSERT INTO discovery_jobs(project, brief, scale, target_count, provider, status, keywords, created_at, updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?)",
                (project_id, brief.strip(), scale, target, effective_mode, "running", dump(kw_list), ts, ts),
            )
            job_id = cur.lastrowid

        cancel_ev = Event()
        self._cancel_flags[job_id] = cancel_ev
        Thread(
            target=self._run_job,
            args=(job_id, brief.strip(), kw_list, target, effective_mode, authorized_candidates or [], cancel_ev),
            daemon=True,
        ).start()
        return self.get_job(job_id)

    def control_job(self, job_id: int, action: str) -> dict:
        if action == "cancel":
            ev = self._cancel_flags.get(job_id)
            if ev:
                ev.set()
            with self.db_factory(True) as db:
                db.execute("UPDATE discovery_jobs SET status='cancelled', updated_at=? WHERE id=? AND status='running'", (now(), job_id))
            return self.get_job(job_id)
        if action == "retry":
            job = self.get_job(job_id)
            return self.start_job(
                job["brief"], keywords=job["keywords"], scale=job["scale"],
                project_id=job["project"], mode=job["provider"],
            )
        raise ValueError("不支持的操作")

    def _run_job(self, job_id: int, brief: str, keywords: list[str], target: int, mode: str, authorized_candidates: list[dict], cancel_ev: Event):
        try:
            seen_cids: set[str] = set()
            notes: list[str] = []
            local_matched = 0

            # Step 1: Local DB cache priority match (YouTube)
            with self.db_factory(True) as db:
                rows = db.execute("SELECT id, platform, account_id, url, display_name, followers, views, raw, updated_at FROM accounts WHERE workspace_id=1 AND platform='YouTube'").fetchall()
                for r in rows:
                    if cancel_ev.is_set() or len(seen_cids) >= target:
                        break
                    raw = load(r["raw"])
                    content = raw.get("content") or []
                    videos = [{"title": c.get("title", ""), "url": c.get("url", ""), "description": c.get("description", ""), "views": c.get("views")} for c in content]
                    verticals, score, evidence = analyze_verticality_and_relevance(brief, keywords, r["display_name"], videos)
                    if score < 35:
                        continue
                    cid = r["account_id"]
                    seen_cids.add(cid)
                    local_matched += 1
                    metrics = split_video_metrics(videos)
                    if not metrics["recent_avg_views"] and r["views"]:
                        metrics["recent_avg_views"] = float(r["views"])
                    evidence.insert(0, "命中本地达人库缓存")
                    self._upsert_candidate(db, job_id, {
                        "channel_id": cid,
                        "url": r["url"],
                        "display_name": r["display_name"],
                        "subscribers": r["followers"],
                        "subscribers_approx": 0,
                        **metrics,
                        "verticals": verticals,
                        "relevance_score": score,
                        "relevance_evidence": evidence,
                        "sample_videos": videos[:5],
                        "source_type": "local_cache",
                        "source_name": "本地达人库缓存",
                        "fetched_at": r["updated_at"],
                        "in_local_db": 1,
                        "local_account_id": r["id"],
                    })

                db.execute(
                    "UPDATE discovery_jobs SET local_matched=?, discovered_total=?, processed=?, succeeded=?, updated_at=? WHERE id=?",
                    (local_matched, len(seen_cids), len(seen_cids), len(seen_cids), now(), job_id),
                )

            # Step 2: Authorized candidates (or RSS enrichment) or Experimental yt-dlp
            to_enrich: list[dict] = []
            for item in authorized_candidates:
                cid = item.get("channel_id") or item.get("account_id")
                if cid and cid not in seen_cids and len(seen_cids) + len(to_enrich) < target:
                    to_enrich.append(item)

            if mode == "experimental_ytdlp" and not cancel_ev.is_set() and len(seen_cids) + len(to_enrich) < target:
                remaining = target - len(seen_cids) - len(to_enrich)
                yt_items = ExperimentalYtDlpDiscoveryProvider().search_channels(keywords, remaining, cancel_ev)
                for item in yt_items:
                    if item["channel_id"] not in seen_cids:
                        to_enrich.append(item)
            elif mode == "local_and_rss" and not authorized_candidates and not cancel_ev.is_set() and len(seen_cids) + len(to_enrich) < target:
                remaining = target - len(seen_cids) - len(to_enrich)
                # 2a. Local lightweight long-tail index
                for lt in self.index.search_local(keywords, limit=remaining):
                    if lt["channel_id"] not in seen_cids:
                        to_enrich.append({
                            "channel_id": lt["channel_id"],
                            "display_name": lt["channel_name"],
                            "url": lt["channel_url"],
                            "handle": lt.get("handle"),
                            "source_type": "open_dataset_rss",
                            "source_name": f"{lt['source_dataset']} + YouTube 官方 RSS",
                            "skip_html_subs": True,
                        })
                # 2b. Wikidata (CC0 P2397) — back off on 429, keep other sources' results
                if not cancel_ev.is_set() and len(seen_cids) + len(to_enrich) < target:
                    wd = WikidataRssDiscoveryProvider()
                    try:
                        wd_items = wd.search_channels(keywords, target - len(seen_cids) - len(to_enrich), cancel_ev)
                    except Exception as exc:
                        wd_items = []
                        notes.append("Wikidata 暂不可用，已跳过：" + str(exc)[:80])
                    if wd.rate_limited:
                        notes.append("Wikidata 触发限流，已退避并保留已得结果")
                    for item in wd_items:
                        if item["channel_id"] not in seen_cids and all(x["channel_id"] != item["channel_id"] for x in to_enrich):
                            to_enrich.append(item)
                # 2c. Streaming open datasets (HuggingFace datasets-server -> cached in long_tail_index)
                if not cancel_ev.is_set() and len(seen_cids) + len(to_enrich) < target:
                    try:
                        ds_items = self.index.stream_search_and_index(keywords, limit_per_query=15)
                    except Exception as exc:
                        ds_items = []
                        notes.append("开放数据集接口暂不可用，已跳过：" + str(exc)[:80])
                    for lt in ds_items:
                        if lt["channel_id"] not in seen_cids and all(x["channel_id"] != lt["channel_id"] for x in to_enrich):
                            to_enrich.append({
                                "channel_id": lt["channel_id"],
                                "display_name": lt["channel_name"],
                                "url": lt["channel_url"],
                                "handle": lt.get("handle"),
                                "source_type": "open_dataset_rss",
                                "source_name": f"{lt['source_dataset']} + YouTube 官方 RSS",
                                "skip_html_subs": True,
                            })
                            if len(seen_cids) + len(to_enrich) >= target:
                                break

            with self.db_factory(True) as db:
                db.execute("UPDATE discovery_jobs SET discovered_total=?, updated_at=? WHERE id=?", (len(seen_cids) + len(to_enrich), now(), job_id))

            processed, succeeded, failed = len(seen_cids), len(seen_cids), 0
            for item in to_enrich:
                if cancel_ev.is_set():
                    break
                cid = item["channel_id"]
                if cid in seen_cids:
                    continue
                seen_cids.add(cid)
                processed += 1
                try:
                    videos = item.get("videos") or []
                    display_name = item.get("display_name") or cid
                    subs = item.get("subscribers")
                    handle = item.get("handle")
                    source_type = item.get("source_type") or "official_rss"
                    source_name = item.get("source_name") or "YouTube 官方 Atom RSS + 公开频道页"
                    if not videos and str(cid).startswith("UC"):
                        rss = OfficialRssDiscoveryProvider.fetch_rss(cid)
                        videos = rss["videos"]
                        if rss["display_name"]:
                            display_name = rss["display_name"]
                        if subs is None and not item.get("skip_html_subs"):
                            subs, handle = OfficialRssDiscoveryProvider.fetch_public_subscribers(cid)
                    metrics = split_video_metrics(videos)
                    verticals, score, evidence = analyze_verticality_and_relevance(brief, keywords, display_name, videos)
                    with self.db_factory(True) as db:
                        self._upsert_candidate(db, job_id, {
                            "channel_id": cid,
                            "url": item.get("url") or f"https://www.youtube.com/channel/{cid}",
                            "display_name": display_name,
                            "handle": handle,
                            "subscribers": subs,
                            "subscribers_approx": 1,
                            **metrics,
                            "verticals": verticals,
                            "relevance_score": score,
                            "relevance_evidence": evidence,
                            "sample_videos": [{"title": v.get("title"), "url": v.get("url"), "views": v.get("views")} for v in videos[:5]],
                            "source_type": source_type,
                            "source_name": source_name,
                            "fetched_at": now(),
                            "in_local_db": 0,
                            "local_account_id": None,
                        })
                        succeeded += 1
                        db.execute("UPDATE discovery_jobs SET processed=?, succeeded=?, updated_at=? WHERE id=?", (processed, succeeded, now(), job_id))
                except RateLimitError as exc:
                    failed += 1
                    with self.db_factory(True) as db:
                        db.execute("UPDATE discovery_jobs SET status='rate_limited', processed=?, failed=?, error=?, updated_at=? WHERE id=?", (processed, failed, str(exc), now(), job_id))
                    return
                except Exception as exc:
                    failed += 1
                    with self.db_factory(True) as db:
                        db.execute("UPDATE discovery_jobs SET processed=?, failed=?, updated_at=? WHERE id=?", (processed, failed, now(), job_id))

            final_status = "cancelled" if cancel_ev.is_set() else "done"
            with self.db_factory(True) as db:
                db.execute("UPDATE discovery_jobs SET status=?, processed=?, succeeded=?, failed=?, error=?, updated_at=? WHERE id=?", (final_status, processed, succeeded, failed, ("；".join(notes) or None), now(), job_id))
        except Exception as exc:
            with self.db_factory(True) as db:
                db.execute("UPDATE discovery_jobs SET status='failed', error=?, updated_at=? WHERE id=?", (str(exc)[:300], now(), job_id))
        finally:
            self._cancel_flags.pop(job_id, None)

    @staticmethod
    def _upsert_candidate(db, job_id: int, data: dict):
        db.execute(
            "INSERT INTO discovery_candidates(job, channel_id, platform, url, display_name, handle, subscribers, subscribers_approx, "
            "recent_avg_views, recent_median_views, recent_sample_count, long_avg_views, long_median_views, long_count, "
            "shorts_avg_views, shorts_count, verticals, relevance_score, relevance_evidence, sample_videos, "
            "source_type, source_name, fetched_at, in_local_db, local_account_id) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(job, channel_id) DO NOTHING",
            (
                job_id, data["channel_id"], "YouTube", data["url"], data["display_name"], data.get("handle"),
                data.get("subscribers"), data.get("subscribers_approx", 1),
                data.get("recent_avg_views"), data.get("recent_median_views"), data.get("recent_sample_count", 0),
                data.get("long_avg_views"), data.get("long_median_views"), data.get("long_count", 0),
                data.get("shorts_avg_views"), data.get("shorts_count", 0),
                dump(data.get("verticals") or []), int(data.get("relevance_score", 0)),
                dump(data.get("relevance_evidence") or []), dump(data.get("sample_videos") or []),
                data["source_type"], data["source_name"], data.get("fetched_at") or now(),
                int(data.get("in_local_db", 0)), data.get("local_account_id"),
            ),
        )

    def get_job(self, job_id: int) -> dict:
        with self.db_factory(True) as db:
            row = db.execute("SELECT * FROM discovery_jobs WHERE id=?", (job_id,)).fetchone()
            if not row:
                raise KeyError("发现任务不存在")
            job = dict(row)
            job["keywords"] = load(job["keywords"])
            cands = db.execute(
                "SELECT * FROM discovery_candidates WHERE job=? ORDER BY relevance_score DESC, COALESCE(long_avg_views, recent_avg_views, 0) DESC",
                (job_id,),
            ).fetchall()
            items = []
            for c in cands:
                d = dict(c)
                for col in ("verticals", "relevance_evidence", "sample_videos"):
                    d[col] = load(d[col])
                items.append(d)
            job["candidates"] = items
            return job

    def commit_candidates(self, job_id: int, candidate_ids: list[int], project_id: int | None, source_name: str, permission: str, operator: str, confirmed: bool) -> dict:
        if not confirmed:
            raise ValueError("请先确认候选来源合规")
        if not candidate_ids:
            raise ValueError("请至少选择一位候选达人")
        today = date.today()
        grant = prepare_policy(
            ImportPolicy(
                source_name=source_name or "V1.4 智能发现",
                permission=permission or "内部选号与匹配",
                effective_on=today,
                acquired_on=today,
                expires_on=today + timedelta(days=365),
                deletion_owner=operator or "ops",
                allowed_fields=["platform", "account_id", "url", "display_name", "followers", "views", "recent_average", "recent_median"],
                purposes=["view", "tag", "match", "export"],
            ),
            today,
        )
        added, updated = 0, 0
        with self.db_factory(True) as db:
            if not project_id:
                job_row = db.execute("SELECT project, brief FROM discovery_jobs WHERE id=?", (job_id,)).fetchone()
                if job_row and job_row["project"]:
                    project_id = job_row["project"]
                elif job_row:
                    proj_name = f"智能发现-{today.isoformat()}-{job_id}"
                    project_id = db.execute(
                        "INSERT INTO projects(workspace_id,name,brief,criteria,created_at) VALUES(1,?,?,?,?)",
                        (proj_name, job_row["brief"], dump({}), now()),
                    ).lastrowid
                    db.execute("UPDATE discovery_jobs SET project=? WHERE id=?", (project_id, job_id))
            placeholders = ",".join("?" for _ in candidate_ids)
            rows = db.execute(
                f"SELECT * FROM discovery_candidates WHERE job=? AND id IN ({placeholders})",
                (job_id, *candidate_ids),
            ).fetchall()
            for c in rows:
                existing = db.execute(
                    "SELECT id, raw FROM accounts WHERE workspace_id=1 AND platform='YouTube' AND (account_id=? OR url=?)",
                    (c["channel_id"], c["url"]),
                ).fetchone()
                avg_views = c["long_avg_views"] if c["long_avg_views"] is not None else c["recent_avg_views"]
                med_views = c["long_median_views"] if c["long_median_views"] is not None else c["recent_median_views"]
                if existing:
                    account_id = existing["id"]
                    updated += 1
                else:
                    raw_profile = {
                        "platform": "YouTube",
                        "account_id": c["channel_id"],
                        "url": c["url"],
                        "display_name": c["display_name"],
                        "followers": str(c["subscribers"]) if c["subscribers"] is not None else "",
                        "views": str(int(round(avg_views))) if avg_views is not None else "",
                        "recent_average": str(round(avg_views, 2)) if avg_views is not None else "",
                        "recent_median": str(round(med_views, 2)) if med_views is not None else "",
                    }
                    profile = governed_profile(raw_profile, "independent", grant, f"v14:{c['id']}")
                    profile["content"] = load(c["sample_videos"]) if isinstance(c["sample_videos"], str) else (c["sample_videos"] or [])
                    account_id, _ = self.store.save_account(db, profile)
                    freshness.sync_account_states(db, account_id, profile, source_type=c["source_type"], source_name=c["source_name"], timestamp=c["fetched_at"] or now())
                    added += 1
                db.execute("UPDATE discovery_candidates SET review_status='approved', local_account_id=? WHERE id=?", (account_id, c["id"]))
                if project_id:
                    proj = db.execute("SELECT criteria FROM projects WHERE id=?", (project_id,)).fetchone()
                    if proj:
                        criteria = load(proj["criteria"]) if proj["criteria"] else {}
                        db.execute("INSERT OR IGNORE INTO project_intake(project, account, settings) VALUES(?,?,?)", (project_id, account_id, dump({"reading_stat": "unknown", "verified_views": None})))
                        self.store.apply_match(db, project_id, account_id, criteria)
        return {"added": added, "updated": updated, "linked_project_id": project_id}

    def export_job_xlsx(self, job_id: int, only_approved: bool = False) -> bytes:
        job = self.get_job(job_id)
        wb = Workbook()
        ws = wb.active
        ws.title = "智能发现提报"
        headers = [
            "频道名称", "频道ID", "主页链接", "数据来源", "订阅数", "订阅近似标识",
            "长视频均播", "长视频样本数", "Shorts均播", "Shorts样本数",
            "内容垂直度", "需求相关度", "匹配依据", "代表作品", "审核状态",
        ]
        ws.append(headers)
        fill = PatternFill(start_color="E4F0E7", end_color="E4F0E7", fill_type="solid")
        font = Font(bold=True, color="102B24")
        for idx in range(1, len(headers) + 1):
            c = ws.cell(1, idx)
            c.fill = fill
            c.font = font
        for c in job["candidates"]:
            if only_approved and c["review_status"] != "approved":
                continue
            samples = " | ".join(v.get("title", "") for v in (c.get("sample_videos") or [])[:3])
            ws.append([
                c["display_name"],
                c["channel_id"],
                c["url"],
                c["source_name"],
                c["subscribers"] if c["subscribers"] is not None else "未知",
                "约(公开缩写)" if c["subscribers_approx"] else "精确/导入",
                round(c["long_avg_views"]) if c["long_avg_views"] is not None else "未知",
                c["long_count"],
                round(c["shorts_avg_views"]) if c["shorts_avg_views"] is not None else 0,
                c["shorts_count"],
                " / ".join(c.get("verticals") or []) or "待人工判断",
                c["relevance_score"],
                "；".join(c.get("relevance_evidence") or []),
                samples,
                "已入库" if c["review_status"] == "approved" else "待审核",
            ])
        buf = BytesIO()
        wb.save(buf)
        return buf.getvalue()
