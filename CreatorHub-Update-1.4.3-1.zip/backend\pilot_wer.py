"""Windows Error Reporting controls scoped to the current process."""
import ctypes
from ctypes import wintypes
import sys


NOHEAP = 0x00000001  # WER_FAULT_REPORTING_FLAG_NOHEAP in werapi.h


def _apply(get_flags, set_flags):
    if set_flags(NOHEAP) != 0:
        return "WER_SET_FAILED"
    status, effective = get_flags()
    if status != 0:
        return "WER_READ_FAILED"
    return "WER_NOHEAP_VERIFIED" if effective & NOHEAP else "WER_FLAG_MISSING"


def verify_noheap():
    if sys.platform != "win32":
        return "WER_UNAVAILABLE"
    try:
        kernel = ctypes.WinDLL("kernel32.dll")
        current = kernel.GetCurrentProcess
        current.argtypes, current.restype = [], wintypes.HANDLE
        read = kernel.WerGetFlags
        read.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        read.restype = ctypes.c_long
        write = kernel.WerSetFlags
        write.argtypes, write.restype = [wintypes.DWORD], ctypes.c_long

        def get_flags():
            flags = wintypes.DWORD()
            status = read(current(), ctypes.byref(flags))
            return status, flags.value

        return _apply(get_flags, write)
    except (AttributeError, OSError):
        return "WER_UNAVAILABLE"
