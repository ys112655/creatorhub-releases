"""Private HTTP exchange for the budgeted pilot. No CLI or product route."""
from http.client import HTTPConnection, HTTPSConnection, HTTPException
import json
import re
from socket import SHUT_RDWR
import ssl
from threading import Thread
from time import monotonic
from urllib.parse import urlencode

HOST = "www.googleapis.com"
API_PATH = "/youtube/v3/"
CONNECT_TIMEOUT = 3
READ_TIMEOUT = 3
TOTAL_TIMEOUT = 8
MAX_BODY = 2 * 1024 * 1024
PARAMETERS = {
    "search": {"part", "type", "q", "maxResults"},
    "channels": {"part", "id"},
    "playlistItems": {"part", "playlistId", "maxResults"},
    "videos": {"part", "id"},
}


def _valid_key(key):
    return isinstance(key, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,128}", key) is not None


def _exchange(pilot, attempt, endpoint, params):
    """Called only after Pilot has committed a reservation."""
    key, test_port = pilot._claim_http(attempt, endpoint)
    if endpoint not in PARAMETERS or params.keys() != PARAMETERS[endpoint] or not _valid_key(key):
        return 0, "invalid_request"
    if endpoint in {"channels", "videos"} and (
        not isinstance(params["id"], str) or
        not re.fullmatch(r"[A-Za-z0-9_-]{1,128}(?:,[A-Za-z0-9_-]{1,128}){0,9}", params["id"])
    ):
        return 0, "invalid_request"
    destination = API_PATH + endpoint + "?" + urlencode(params)
    connection = (HTTPSConnection(HOST, 443, timeout=CONNECT_TIMEOUT, context=ssl.create_default_context())
                  if test_port is None else HTTPConnection("127.0.0.1", test_port, timeout=CONNECT_TIMEOUT))
    deadline = monotonic() + TOTAL_TIMEOUT
    result = []
    sockets = []

    def exchange():
        try:
            connection.connect()
            sockets.append(connection.sock)
            if monotonic() >= deadline:
                return
            connection.sock.settimeout(min(READ_TIMEOUT, max(0.001, deadline - monotonic())))
            connection.request("GET", destination, headers={"x-goog-api-key": key, "Connection": "close"})
            response = connection.getresponse()
            with response:
                if response.status != 200:
                    result.append((response.status, None))
                    return
                chunks = bytearray()
                while monotonic() < deadline:
                    part = response.read1(65536)
                    if not part:
                        result.append((0, "invalid_response") if response.length else (200, json.loads(chunks)))
                        return
                    chunks.extend(part)
                    if len(chunks) > MAX_BODY:
                        break
                result.append((0, "timeout" if monotonic() >= deadline else "invalid_response"))
        except TimeoutError:
            result.append((0, "timeout"))
        except (UnicodeError, ValueError, HTTPException):
            result.append((0, "invalid_response"))
        except OSError:
            result.append((0, "connection_failed"))
        finally:
            connection.close()

    worker = Thread(target=exchange, daemon=True)
    worker.start()
    worker.join(max(0, deadline - monotonic()))
    if worker.is_alive() or not result:
        sock = sockets[0] if sockets else connection.sock
        if sock is not None:
            try:
                sock.shutdown(SHUT_RDWR)
            except OSError:
                pass
        return 0, "timeout"
    return result[0]
