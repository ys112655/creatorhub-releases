"""Offline-only YouTube pilot. The existing product never opens these databases."""
from contextlib import closing, contextmanager
from datetime import datetime, timedelta, timezone
import json
from hashlib import sha256
import logging
from pathlib import Path
import sqlite3
from urllib.parse import urlsplit

from .pilot_identity import PILOT_DATABASE_IDS
from .pilot_http import _exchange, _valid_key
from .pilot_approval import POLICY_VERSION, authorized_batch
from .pilot_wer import verify_noheap

API_ID, NOTES_ID = PILOT_DATABASE_IDS
LIMITS = {"search": 3, "channels": 1, "playlistItems": 10, "videos": 1}
KEYWORDS = ("ComfyUI workflow", "AI video generation tutorial", "AI VFX workflow")
API_SOURCE = "youtube_api"
BASE_URL = "https://www.googleapis.com/youtube/v3/"
logger = logging.getLogger(__name__)


class PilotError(RuntimeError):
    pass


class FixtureTransport:
    """One supplied response per attempt. No URLs are opened."""

    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = []

    def send(self, endpoint, params):
        self.calls.append((endpoint, params))
        status, payload = next(self.responses, (500, None))
        if isinstance(payload, TimeoutError):
            raise payload
        return status, payload


def utcnow():
    return datetime.now(timezone.utc)


def timestamp(value):
    if value.utcoffset() is None:
        raise PilotError("timezone_required")
    return value.astimezone(timezone.utc).isoformat(timespec="microseconds")


def items(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise PilotError("invalid_response")
    if any(not isinstance(item, dict) for item in payload["items"]):
        raise PilotError("invalid_response")
    return payload["items"]


def fields(value, names):
    if not isinstance(value, dict):
        return {}
    return {key: value[key] for key in names if key in value}


def identifier(value):
    return isinstance(value, str) and value.isascii() and 0 < len(value) <= 128 and all(
        character.isalnum() or character in "_-" for character in value
    )


def project_response(endpoint, payload, params):
    rows = items(payload)
    if endpoint == "search":
        return [item["channelId"] for row in rows[:10]
                if identifier((item := fields(row.get("snippet"), ("channelId",))).get("channelId"))]
    if endpoint == "playlistItems":
        return [item["videoId"] for row in rows[:5]
                if identifier((item := fields(row.get("contentDetails"), ("videoId",))).get("videoId"))]
    allowed = set(params["id"].split(","))
    result = {}
    for row in rows:
        key = row.get("id")
        if not identifier(key) or key not in allowed:
            continue
        snippet = fields(row.get("snippet"), ("title", "description", "publishedAt"))
        if endpoint == "channels":
            snippet.update(fields(row.get("snippet"), ("country", "defaultLanguage")))
            snippet = {name: value for name, value in snippet.items() if isinstance(value, str)}
            statistics = fields(row.get("statistics"), ("hiddenSubscriberCount", "subscriberCount"))
            if type(statistics.get("hiddenSubscriberCount")) is not bool:
                statistics.pop("hiddenSubscriberCount", None)
            if not isinstance(statistics.get("subscriberCount"), str):
                statistics.pop("subscriberCount", None)
            if statistics.get("hiddenSubscriberCount") is True:
                statistics.pop("subscriberCount", None)
            playlists = fields(row.get("contentDetails"), ("relatedPlaylists",))
            uploads = fields(playlists.get("relatedPlaylists"), ("uploads",)).get("uploads")
            result[key] = {"snippet": snippet, "statistics": statistics}
            if identifier(uploads):
                result[key]["uploads"] = uploads
        else:
            snippet = {name: value for name, value in snippet.items() if isinstance(value, str)}
            additional = fields(row.get("snippet"), ("channelId", "tags"))
            if identifier(additional.get("channelId")):
                snippet["channelId"] = additional["channelId"]
            tags = additional.get("tags")
            if isinstance(tags, list) and all(isinstance(tag, str) for tag in tags):
                snippet["tags"] = tags
            count = fields(row.get("statistics"), ("viewCount",)).get("viewCount")
            result[key] = {"snippet": snippet, "statistics": {"viewCount": count} if isinstance(count, str) else {}}
    return result


class Pilot:
    """One fixed brief and one durable ledger per explicit batch directory."""

    def __init__(self, directory, transport=None, *, mode="offline", create=False, clock=utcnow,
                 approval=None, api_key=None, test_port=None, readonly=False, cleanup_only=False):
        directory = Path(directory)
        self._grant = approval
        self._cleanup_only = cleanup_only
        if cleanup_only and (mode != "live" or create or api_key is not None):
            raise PilotError("invalid_cleanup_mode")
        if readonly and (mode != "offline" and not cleanup_only or create):
            raise PilotError("offline_readonly_required")
        self._readonly = readonly
        if mode == "offline" and type(transport) is FixtureTransport and test_port is None:
            pass
        elif mode == "http-test" and transport is None and type(test_port) is int and 0 < test_port < 65536 and _valid_key(api_key):
            pass
        elif mode == "live":
            if (not self._authorized(directory) or (not cleanup_only and not _valid_key(api_key))
                    or transport is not None or test_port is not None):
                raise PilotError("live_pilot_disabled_or_unauthorized")
            if not cleanup_only and verify_noheap() != "WER_NOHEAP_VERIFIED":
                raise PilotError("live_requires_wer")
            approval = sha256(approval).hexdigest()
        else:
            raise PilotError("offline_fixture_required")
        if not directory.is_absolute() or not directory.is_dir():
            raise PilotError("explicit_existing_batch_directory_required")
        self.directory = directory.resolve()
        self.transport, self.clock = transport, clock
        self._mode, self._key, self._test_port = mode, api_key, test_port
        self._cleanup_failed = False
        self.path = self.directory / "pilot-api.sqlite3"
        self.notes = self.directory / "pilot-independent.sqlite3"
        if mode == "live":
            claim = self.directory.parents[1] / f".{self.directory.parent.name}.claim"
            if create:
                with claim.open("x", encoding="ascii") as marker:
                    marker.write(approval)
            elif claim.is_symlink() or claim.read_text(encoding="ascii") != approval:
                raise PilotError("missing_batch_claim")
        if create:
            if any(self.directory.iterdir()):
                raise PilotError("new_batch_directory_must_be_empty")
            self._create(self.path, API_ID, """
                CREATE TABLE batch(id INTEGER PRIMARY KEY CHECK(id=1), expires TEXT NOT NULL,
                                   paused INTEGER NOT NULL DEFAULT 0, stopped INTEGER NOT NULL DEFAULT 0,
                                   mode TEXT NOT NULL, approval TEXT);
                CREATE TABLE attempt(id INTEGER PRIMARY KEY, endpoint TEXT NOT NULL, slot INTEGER NOT NULL,
                                     started TEXT NOT NULL, outcome TEXT NOT NULL, UNIQUE(endpoint,slot));
                CREATE TABLE evidence(attempt INTEGER PRIMARY KEY REFERENCES attempt(id),
                                      acquired TEXT NOT NULL, payload TEXT NOT NULL);
            """)
            with self._db() as db:
                db.execute("INSERT INTO batch VALUES (1,?,0,0,?,?)", (self._expiry(), mode, approval))
            self._create(self.notes, NOTES_ID, """
                CREATE TABLE observation(channel_id TEXT PRIMARY KEY, authorized_url TEXT NOT NULL,
                                         acquired TEXT NOT NULL, note TEXT NOT NULL);
            """)
        with self._db(self.notes, NOTES_ID):
            pass
        with self._db() as db:
            self._check_batch(db, approval)
        self._approval = approval
        if not readonly:
            self.purge()

    def _authorized(self, directory):
        return (directory.name == "data" and len(directory.parents) >= 2
                and directory.absolute() == directory.resolve()
                and authorized_batch(directory.parents[1], directory.parent.name, POLICY_VERSION, self._grant))

    @property
    def simulated(self):
        return self._mode != "live"

    def _check_batch(self, db, approval):
        columns = {row[1] for row in db.execute("PRAGMA table_info(batch)")}
        if "mode" in columns:
            row = db.execute("SELECT mode,approval FROM batch WHERE id=1").fetchone()
        else:
            row = ("offline", None) if db.execute("SELECT 1 FROM batch WHERE id=1").fetchone() else None
        if row != (self._mode, approval if self._mode == "live" else None):
            raise PilotError("wrong_batch_mode_or_approval")

    def _expiry(self):
        return timestamp(self.clock() + timedelta(days=29))

    @staticmethod
    def _create(path, marker, schema):
        with path.open("xb"):
            pass
        with closing(sqlite3.connect(path)) as db:
            db.execute(f"PRAGMA application_id={marker}")
            db.executescript(schema)

    @contextmanager
    def _db(self, path=None, marker=API_ID):
        path = self.path if path is None else path
        if path.is_symlink() or path.resolve().parent != self.directory:
            raise PilotError("invalid_database_path")
        mode = "ro" if self._readonly else "rw"
        with closing(sqlite3.connect(path.as_uri() + "?mode=" + mode, uri=True, isolation_level=None)) as db:
            if db.execute("PRAGMA application_id").fetchone()[0] != marker:
                raise PilotError("wrong_database_mode")
            if not self._readonly:
                db.execute("PRAGMA secure_delete=ON")
            db.execute("PRAGMA foreign_keys=ON")
            journal_mode = "PRAGMA journal_mode" if self._readonly else "PRAGMA journal_mode=DELETE"
            if db.execute(journal_mode).fetchone()[0] != "delete":
                raise PilotError("unexpected_journal_mode")
            db.execute("PRAGMA temp_store=MEMORY")
            yield db

    def pause(self, paused=True):
        with self._db() as db:
            db.execute("UPDATE batch SET paused=? WHERE id=1", (int(paused),))

    def purge(self, *, finish=False):
        try:
            with self._db() as db, db:
                db.execute("BEGIN IMMEDIATE")
                if finish:
                    db.execute("UPDATE batch SET stopped=1 WHERE id=1")
                return db.execute("""DELETE FROM evidence WHERE EXISTS (
                    SELECT 1 FROM batch WHERE ?=1 OR expires<=?)""",
                    (int(finish), timestamp(self.clock()))).rowcount
        except sqlite3.Error:
            if self._mode != "offline":
                self._cleanup_failed = True
                with self._db() as db:
                    db.execute("UPDATE batch SET stopped=1 WHERE id=1")
            raise

    def maintain(self, stop, *, interval=60):
        """Run on a worker owned by the offline host until its stop event is set."""
        while not stop.is_set():
            try:
                self.purge()
            except sqlite3.Error:
                logger.warning("Pilot expiry cleanup failed; expired evidence remains inaccessible")
            stop.wait(interval)

    def evidence(self):
        with self._db() as db:
            rows = db.execute("""SELECT endpoint, acquired, payload FROM evidence
                JOIN attempt ON attempt.id=evidence.attempt
                WHERE (SELECT expires FROM batch WHERE id=1)>? ORDER BY evidence.attempt""",
                (timestamp(self.clock()),)).fetchall()
        return [{"source": API_SOURCE, "source_label": "YouTube Data API",
                 "simulated": self._mode != "live", "origin": BASE_URL + endpoint,
                 "acquired_at": acquired, "raw_fields": json.loads(payload)}
                for endpoint, acquired, payload in rows]

    def record_independent(self, channel_id, url, note, *, source, authorized):
        try:
            parsed = urlsplit(url) if isinstance(url, str) else None
        except ValueError:
            parsed = None
        if (source != "independent" or authorized is not True or not identifier(channel_id)
                or not isinstance(note, str) or parsed is None or parsed.scheme != "https"
                or not parsed.hostname or parsed.username is not None
                or parsed.hostname.rstrip(".").endswith((".googleapis.com", ".googleapis.com.cn"))
                or parsed.hostname.rstrip(".") in {"googleapis.com", "googleapis.com.cn"}):
            raise PilotError("independent_provenance_required")
        with self._db(self.notes, NOTES_ID) as db:
            db.execute("INSERT INTO observation VALUES (?,?,?,?)",
                       (channel_id, url, timestamp(self.clock()), note))

    def ledger(self):
        with self._db() as db:
            return db.execute("SELECT endpoint, started, outcome FROM attempt ORDER BY id").fetchall()

    def independent_evidence(self):
        with self._db(self.notes, NOTES_ID) as db:
            return db.execute("""SELECT channel_id, authorized_url, acquired, note
                FROM observation ORDER BY channel_id""").fetchall()

    def batch_state(self):
        with self._db() as db:
            expires, paused, stopped = db.execute("SELECT expires, paused, stopped FROM batch WHERE id=1").fetchone()
        if stopped or expires <= timestamp(self.clock()):
            return "已结束"
        return "已暂停" if paused else "可预览"

    def _reserve(self, endpoint, slot):
        if self._cleanup_only:
            raise PilotError("cleanup_only")
        if self._cleanup_failed:
            raise PilotError("cleanup_failed")
        with self._db() as db, db:
            db.execute("BEGIN IMMEDIATE")
            self._check_batch(db, self._approval)
            expires, paused, stopped = db.execute(
                "SELECT expires,paused,stopped FROM batch WHERE id=1").fetchone()
            if paused or stopped or expires <= timestamp(self.clock()):
                raise PilotError("batch_unavailable")
            previous = db.execute("""SELECT id,outcome,payload FROM attempt LEFT JOIN evidence
                ON attempt.id=evidence.attempt WHERE endpoint=? AND slot=?""", (endpoint, slot)).fetchone()
            if previous:
                if previous[1] == "ok" and previous[2] is not None:
                    return None, json.loads(previous[2])
                raise PilotError("previous_attempt_not_replayable")
            counts = dict(db.execute("SELECT endpoint,count(*) FROM attempt GROUP BY endpoint"))
            total = sum(counts.values())
            if (total >= 15 or counts.get(endpoint, 0) >= LIMITS[endpoint]
                    or endpoint != "search" and total - counts.get("search", 0) >= 12):
                raise PilotError("budget_exhausted")
            if db.execute("SELECT 1 FROM attempt WHERE outcome IN ('reserved','sending')").fetchone():
                raise PilotError("attempt_in_flight_or_interrupted")
            attempt = db.execute("INSERT INTO attempt(endpoint,slot,started,outcome) VALUES (?,?,?,'reserved')",
                                 (endpoint, slot, timestamp(self.clock()))).lastrowid
            return attempt, None

    def _claim_http(self, attempt, endpoint):
        if not (self._mode == "http-test" or self._mode == "live"
                and not self._cleanup_only and self._authorized(self.directory)
                and verify_noheap() == "WER_NOHEAP_VERIFIED"):
            raise PilotError("http_mode_disabled")
        with self._db() as db, db:
            db.execute("BEGIN IMMEDIATE")
            self._check_batch(db, self._approval)
            claimed = db.execute("""UPDATE attempt SET outcome='sending'
                WHERE id=? AND endpoint=? AND outcome='reserved'
                AND EXISTS (SELECT 1 FROM batch WHERE id=1 AND paused=0 AND stopped=0 AND expires>?)""",
                (attempt, endpoint, timestamp(self.clock()))).rowcount
            if not claimed:
                raise PilotError("http_reservation_required")
        return self._key, self._test_port

    def _request(self, endpoint, slot, **params):
        if endpoint not in LIMITS or set(params) & {"pageToken", "key"}:
            raise PilotError("request_not_allowed")
        if self._mode != "offline" and endpoint == "search" and (
                params.get("q") not in KEYWORDS or params.get("type") != "video" or params.get("maxResults") != 10):
            raise PilotError("request_not_allowed")
        if self._mode != "offline" and endpoint == "playlistItems" and (
                not identifier(params.get("playlistId")) or params.get("maxResults") != 5):
            raise PilotError("request_not_allowed")
        attempt, cached = self._reserve(endpoint, slot)
        if attempt is None:
            return cached
        try:
            if self._mode == "offline":
                status, payload = self.transport.send(endpoint, params)
            else:
                status, payload = _exchange(self, attempt, endpoint, params)
                if status == 0:
                    raise PilotError(payload)
            if status != 200:
                raise PilotError(f"http_{status}" if type(status) is int and 100 <= status <= 599 else "invalid_status")
            result = project_response(endpoint, payload, params)
        except (TimeoutError, PilotError) as error:
            outcome = "timeout" if isinstance(error, TimeoutError) else str(error)
            with self._db() as db, db:
                db.execute("BEGIN IMMEDIATE")
                db.execute("UPDATE attempt SET outcome=? WHERE id=?", (outcome, attempt))
                db.execute("UPDATE batch SET stopped=1 WHERE id=1")
            raise PilotError(outcome) from None
        with self._db() as db, db:
            db.execute("BEGIN IMMEDIATE")
            acquired = timestamp(self.clock())
            if not db.execute("SELECT 1 FROM batch WHERE stopped=0 AND expires>?", (acquired,)).fetchone():
                raise PilotError("batch_unavailable")
            db.execute("INSERT INTO evidence VALUES (?,?,?)", (attempt, acquired, json.dumps(result)))
            db.execute("UPDATE attempt SET outcome='ok' WHERE id=?", (attempt,))
        return result

    def run(self):
        self.purge()
        channels = []
        for slot, keyword in enumerate(KEYWORDS):
            found = self._request("search", slot, part="snippet", type="video", q=keyword, maxResults=10)
            channels = list(dict.fromkeys(channels + found))[:10]
            if len(channels) == 10:
                break
        if not channels:
            return {"channels": 0, "videos": 0}
        profiles = self._request("channels", 0, part="snippet,statistics,contentDetails", id=",".join(channels))
        videos = []
        for slot, channel in enumerate(channels):
            uploads = profiles.get(channel, {}).get("uploads")
            if uploads:
                recent = self._request("playlistItems", slot, part="contentDetails",
                                       playlistId=uploads, maxResults=5)
                videos.extend(recent[:1])
        videos = list(dict.fromkeys(videos))
        details = self._request("videos", 0, part="snippet,statistics", id=",".join(videos)) if videos else {}
        return {"channels": len(profiles), "videos": len(details)}
