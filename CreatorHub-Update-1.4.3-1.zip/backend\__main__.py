import argparse
import os
from pathlib import Path
import socket
from threading import Thread
from time import monotonic, sleep
from urllib.request import urlopen
import webbrowser

import uvicorn

def launch_browser(port):
    url = f"http://127.0.0.1:{port}"
    until = monotonic() + 15
    while monotonic() < until:
        try:
            with urlopen(url + "/api/meta", timeout=1) as response:
                if response.status == 200:
                    webbrowser.open(url)
                    return
        except OSError:
            sleep(0.25)

def main():
    parser = argparse.ArgumentParser(description="Start the local CreatorHub workspace.")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--open", action="store_true")
    parser.add_argument("--port", type=int)
    parser.add_argument("--db", type=Path)
    args = parser.parse_args()
    port = args.port or (44232 if args.demo else 44231)
    os.environ["CREATORHUB_DEMO"] = "1" if args.demo else "0"
    if args.db:
        os.environ["CREATORHUB_DB"] = str(args.db.resolve())
    if args.open:
        with socket.socket() as server:
            if server.connect_ex(("127.0.0.1", port)) == 0:
                with urlopen(f"http://127.0.0.1:{port}/api/meta", timeout=2) as response:
                    import json
                    meta = json.load(response)
                    if meta.get("demo") is not args.demo or "dimensions" not in meta:
                        raise RuntimeError("端口已被其他服务占用")
                webbrowser.open(f"http://127.0.0.1:{port}")
                return
        Thread(target=launch_browser, args=(port,), daemon=True).start()
    uvicorn.run("backend.app:runtime_app", factory=True, host="127.0.0.1", port=port, access_log=False)

if __name__ == "__main__":
    main()
