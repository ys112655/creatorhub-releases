// 智能发现 V1.1：需求 → 站内搜索建议 → 粘贴核验结果 → 去重 → 授权确认 → 一键写入提报
const SAMPLE = "寻找欧美英语市场的 ComfyUI、AI Video Generation、AI VFX 垂直达人";
const state = { keywords: [], custom: [], candidates: [], existing: [], projects: [], parsed: false };

const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = v => (v == null || v === "") ? "未知" : Number(v).toLocaleString("zh-CN");
const has = v => v !== null && v !== undefined && String(v).trim() !== "";

function missingOf(c) {
  const map = [];
  if (!has(c.followers)) map.push("订阅数");
  if (!has(c.language)) map.push("内容语言");
  if (!has(c.creator_location)) map.push("创作者所在地");
  if (!has(c.audience_region)) map.push("受众地区");
  if (!has(c.evidence_url)) map.push("代表作品");
  if (!has(c.vertical)) map.push("垂直度");
  return map;
}

function keywordList() {
  const all = [...state.keywords, ...state.custom];
  if (!all.length) return '<p class="empty">先填写需求并生成建议，或在下面手动添加关键词。</p>';
  return '<div class="chips">' + all.map(k =>
    '<a class="chip good" href="' + esc(k.url) + '" target="_blank" rel="noopener noreferrer">' +
    esc(k.platform) + " · " + esc(k.term) + " ↗</a>").join("") + "</div>";
}

function badges(c) {
  const missing = missingOf(c);
  return missing.length
    ? missing.map(m => '<span class="chip bad">缺 ' + esc(m) + "</span>").join(" ")
    : '<span class="chip good">字段齐全</span>';
}

function candidateRows() {
  if (!state.candidates.length) return '<tr><td colspan="10" class="empty">还没有解析出候选。</td></tr>';
  return state.candidates.map((c, i) => "<tr>" +
    '<td><input type="checkbox" data-pick="' + i + '" checked></td>' +
    "<td>" + esc(c.platform) + "</td>" +
    "<td><strong>" + esc(c.display_name) + "</strong><br><small>" + esc(c.account_id) + "</small></td>" +
    '<td><a href="' + esc(c.url) + '" target="_blank" rel="noopener noreferrer">主页 ↗</a></td>' +
    "<td>" + num(c.followers) + "</td>" +
    '<td><input data-field="language" data-row="' + i + '" value="' + esc(c.language || "") + '" size="6" placeholder="未知"></td>' +
    '<td><input data-field="creator_location" data-row="' + i + '" value="' + esc(c.creator_location || "") + '" size="6" placeholder="未知"></td>' +
    '<td><input data-field="audience_region" data-row="' + i + '" value="' + esc(c.audience_region || "") + '" size="8" placeholder="未知"></td>' +
    "<td>" + (c.evidence_url ? '<a href="' + esc(c.evidence_url) + '" target="_blank" rel="noopener noreferrer">作品 ↗</a>' : "未知") +
    (c.evidence_title ? "<br><small>" + esc(c.evidence_title) + "</small>" : "") + "</td>" +
    '<td><select data-vertical="' + i + '">' +
    ["高", "中", "低", "待定"].map(v => '<option value="' + v + '"' + ((c.vertical || "待定") === v ? " selected" : "") + ">" + v + "</option>").join("") +
    '</select><div class="missing" data-missing="' + i + '">' + badges(c) + "</div></td></tr>").join("");
}

export async function discoveryPage(main, api, toast) {
  const [projects, cfg] = await Promise.all([
    api("/projects").catch(() => []),
    api("/discovery/v14/config").catch(() => ({ experimental_ytdlp_enabled: false, ytdlp_available: false })),
  ]);
  state.projects = Array.isArray(projects) ? projects : [];
  let v14Job = null;
  let v14Timer = null;

  main.innerHTML =
    '<section class="hero"><div><h1>智能发现</h1>' +
    "<p>输入自然语言品牌需求，优先匹配本地达人库并按需补充 YouTube 候选；支持长视频与 Shorts 分离统计、垂直度依据及一键提报。</p></div>" +
    '<div class="hero-summary"><span class="chip">零 API 费用</span><span class="chip">人工审核</span></div></section>' +

    '<section class="panel" id="v14-panel"><h2>1. 智能发现（输入需求 → 搜索 → 审核 → 导出提报）</h2>' +
    '<label class="field">品牌推广需求<textarea id="v14-brief" rows="2">寻找专注 AI video generation、ComfyUI workflow、AI filmmaking、VFX tutorial、AI animation 的 YouTube 创作者</textarea></label>' +
    '<div class="actions">' +
    '<label class="field">搜索规模<select id="v14-scale"><option value="quick">快速（目标 30 位）</option><option value="standard" selected>标准（目标 100 位，默认）</option><option value="deep">深度（目标 300 位）</option></select></label>' +
    '<button class="primary" id="v14-start">开始搜索</button>' +
    '<button id="v14-cancel" disabled>取消</button>' +
    '<button id="v14-retry" disabled>重试</button>' +
    '<span class="hint" id="v14-status">输入需求后点击「开始搜索」，系统将自动生成关键词并匹配达人</span>' +
    '</div>' +
    '<p class="hint">数据来源：本地达人库 · Wikidata（CC0）· 开放数据集线索（Common Pile CC BY 视频元数据、limloop 数据集，仅作发现线索并署名）· YouTube 官方 RSS 实时补全。订阅数无法获取时显示「未知」。</p>' +
    '<details class="hint"><summary>高级设置与数据源合规开关（非官方自动采集默认关闭）</summary>' +
    '<div class="actions">' +
    '<label class="field">关键词（可留空自动生成）<input id="v14-keywords" size="42" placeholder="留空则按需求自动生成"></label>' +
    '<button id="v14-gen-kw">预览关键词</button>' +
    '</div>' +
    '<label class="option"><input type="checkbox" id="v14-exp-toggle"' + (cfg.experimental_ytdlp_enabled ? " checked" : "") + '> 启用非官方实验公开检索（yt-dlp，默认关闭；不使用 Cookie、不下载视频，遇限流自动停止）</label>' +
    '</details>' +
    '<progress id="v14-progress" value="0" max="100" hidden></progress>' +
    '<div id="v14-results" hidden>' +
    '<div class="actions">' +
    '<label class="field">按垂直领域筛选<select id="v14-filter-vertical"><option value="">全部领域</option><option value="AI Video">AI Video</option><option value="ComfyUI">ComfyUI</option><option value="AI Filmmaking">AI Filmmaking</option><option value="VFX & CGI">VFX & CGI</option><option value="AI Animation">AI Animation</option></select></label>' +
    '<span class="hint" id="v14-summary"></span>' +
    '</div>' +
    '<div class="table-scroll"><table><thead><tr><th></th><th>达人 / 频道</th><th>来源</th><th>订阅数</th><th>长视频均播</th><th>Shorts 均播</th><th>垂直度与匹配依据</th></tr></thead>' +
    '<tbody id="v14-rows"></tbody></table></div>' +
    '<div class="table-foot actions">' +
    '<label class="field">关联项目（不选则自动新建）<select id="v14-project"><option value="">自动新建项目</option>' +
    state.projects.map(p => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join("") +
    '</select></label>' +
    '<button class="primary" id="v14-commit">审核入库并导出提报 (XLSX)</button>' +
    '</div></div></section>' +

    '<section class="panel"><p class="hint"><strong>手动补充流程：</strong>站内搜索建议 → 粘贴核验结果 → 去重 → 授权确认 → 一键写入提报。</p></section>' +

    '<section class="panel"><h2>2. 站内搜索建议与手动粘贴</h2>' +
    '<label class="field">品牌需求<textarea id="discovery-brief" rows="3">' + esc(SAMPLE) + "</textarea></label>" +
    '<div class="actions"><button class="primary" id="discovery-suggest">生成搜索建议</button>' +
    '<span class="hint" id="discovery-note">建议只包含站内搜索链接，不会自动抓取任何页面。</span></div>' +
    '<div id="discovery-keywords">' + keywordList() + "</div>" +
    '<div class="actions"><label class="field">补充关键词<input id="discovery-custom" placeholder="例如：手作皮具 / 户外露营"></label>' +
    '<label class="field">平台<select id="discovery-platform"><option>YouTube</option><option>Instagram</option><option>TikTok</option><option>X</option></select></label>' +
    '<button id="discovery-add">添加关键词</button></div></section>' +

    '<section class="panel"><h2>2. 粘贴已核验的候选</h2>' +
    "<p class=\"hint\">支持 Excel / 飞书直接复制（含表头，制表符分隔），也支持竖线格式：<code>主页 | 名称 | 平台 | 订阅 | 语言 | 所在地 | 受众 | 作品链接 | 作品标题 | 垂直度</code>。只有主页必填。</p>" +
    '<textarea id="discovery-raw" rows="8" placeholder="直接粘贴表格，或每行一位达人"></textarea>' +
    '<div class="actions"><button class="primary" id="discovery-parse">解析与去重</button>' +
    '<span class="hint" id="discovery-count">尚未解析</span></div>' +
    '<div id="discovery-existing" class="hint"></div></section>' +

    '<section class="panel table-card" id="discovery-result" hidden>' +
    '<div class="card-head"><h2>3. 核对、确认授权并写入</h2></div>' +
    '<div class="table-scroll"><table><thead><tr><th></th><th>平台</th><th>达人</th><th>主页</th><th>订阅</th>' +
    "<th>内容语言</th><th>创作者所在地</th><th>受众地区</th><th>代表作品</th><th>垂直度</th></tr></thead>" +
    '<tbody id="discovery-rows"></tbody></table></div>' +
    '<div class="panel"><h3>资料来源与授权</h3>' +
    '<div class="actions"><label class="field">来源名称<input id="discovery-source" placeholder="例如：YouTube 站内搜索人工核验"></label>' +
    '<label class="field">授权依据<input id="discovery-permission" placeholder="例如：公开页面人工查阅，仅用于内部选号"></label>' +
    '<label class="field">操作人<input id="discovery-operator" placeholder="你的名字"></label></div>' +
    '<h4>允许的用途</h4><div class="actions">' +
    '<label class="option"><input type="checkbox" data-purpose="view" checked> 查看</label>' +
    '<label class="option"><input type="checkbox" data-purpose="match" checked> 匹配</label>' +
    '<label class="option"><input type="checkbox" data-purpose="export"> 导出与正式提报</label>' +
    '<span class="hint">资料仅限内部查看或匹配时，请不要勾选导出。</span></div>' +
    '<label class="option"><input type="checkbox" id="discovery-confirm"> 我确认以上资料来源合法、已获准用于本次整理，并理解写入后只是进入待审核队列</label></div>' +
    '<div class="table-foot actions"><label class="field">写入项目<select id="discovery-project">' +
    state.projects.map(p => '<option value="' + p.id + '">' + esc(p.name) + "</option>").join("") +
    '</select></label><button class="primary" id="discovery-apply" disabled>一键写入提报</button>' +
    '<span class="hint">写入后进入该项目待审核队列，不会自动入库；审核通过后才进入正式库，正式提报是再下一步。</span></div></section>';

  const $ = s => main.querySelector(s);

  function renderV14Job(job) {
    v14Job = job;
    const prog = $("#v14-progress");
    prog.hidden = false;
    const total = Math.max(1, job.discovered_total || job.target_count || 1);
    prog.max = total;
    prog.value = Math.min(total, job.processed || 0);
    const active = job.status === "running";
    $("#v14-cancel").disabled = !active;
    $("#v14-retry").disabled = active;
    $("#v14-status").textContent = "状态：" + job.status + " · 本地复用 " + job.local_matched + " · 已处理 " + job.processed + "/" + (job.discovered_total || "?") + " · 成功 " + job.succeeded + " · 失败 " + job.failed + (job.error ? "（" + job.error + "）" : "");
    const allCands = job.candidates || [];
    const vf = $("#v14-filter-vertical").value;
    const cands = vf ? allCands.filter(c => (c.verticals || []).includes(vf)) : allCands;
    $("#v14-results").hidden = allCands.length === 0;
    $("#v14-summary").textContent = "共 " + allCands.length + " 位候选（当前显示 " + cands.length + " 位）";
    $("#v14-rows").innerHTML = cands.map(c =>
      "<tr>" +
      '<td><input type="checkbox" data-v14-pick="' + c.id + '" checked></td>' +
      '<td><strong>' + esc(c.display_name) + '</strong><br><a href="' + esc(c.url) + '" target="_blank" rel="noopener noreferrer"><small>' + esc(c.channel_id) + " ↗</small></a></td>" +
      '<td><span class="chip">' + esc(c.source_name) + "</span></td>" +
      "<td>" + (c.subscribers != null ? (c.subscribers_approx ? "约 " : "") + num(c.subscribers) : "未知") + "</td>" +
      "<td>" + (c.long_avg_views != null ? num(Math.round(c.long_avg_views)) + " (" + c.long_count + "条)" : "未知") + "</td>" +
      "<td>" + (c.shorts_avg_views != null ? num(Math.round(c.shorts_avg_views)) + " (" + c.shorts_count + "条)" : "0条") + "</td>" +
      "<td><strong>" + esc((c.verticals || []).join(" / ") || "待人工判断") + "</strong> · 相关度 " + esc(c.relevance_score) + "<br><small>" + esc((c.relevance_evidence || []).join("；")) + "</small></td>" +
      "</tr>"
    ).join("");
  }

  $("#v14-filter-vertical").addEventListener("change", () => { if (v14Job) renderV14Job(v14Job); });

  async function pollV14(jobId) {
    if (v14Timer) clearInterval(v14Timer);
    const tick = async () => {
      try {
        const job = await api("/discovery/v14/jobs/" + jobId);
        renderV14Job(job);
        if (job.status !== "running") {
          clearInterval(v14Timer);
          v14Timer = null;
        }
      } catch (_) {}
    };
    await tick();
    v14Timer = setInterval(tick, 1200);
  }

  $("#v14-exp-toggle").addEventListener("change", async e => {
    try {
      await api("/discovery/v14/config", "PUT", { experimental_ytdlp_enabled: e.target.checked });
      toast(e.target.checked ? "已启用实验性公开检索适配器" : "已关闭非官方实验检索（仅用本地与官方 RSS）");
    } catch (err) { toast(err.message, true); }
  });

  $("#v14-gen-kw").addEventListener("click", async () => {
    try {
      const res = await api("/discovery/v14/keywords", "POST", { brief: $("#v14-brief").value.trim() });
      $("#v14-keywords").value = (res.keywords || []).join(", ");
      toast("已生成 " + (res.keywords || []).length + " 个关键词");
    } catch (err) { toast(err.message, true); }
  });

  $("#v14-start").addEventListener("click", async () => {
    try {
      const kws = $("#v14-keywords").value.split(/[,，]/).map(s => s.trim()).filter(Boolean);
      const job = await api("/discovery/v14/jobs", "POST", {
        brief: $("#v14-brief").value.trim(),
        keywords: kws.length ? kws : null,
        scale: $("#v14-scale").value,
        project_id: Number($("#v14-project").value) || null,
      });
      $("#v14-keywords").value = (job.keywords || []).join(", ");
      await pollV14(job.id);
    } catch (err) { toast(err.message, true); }
  });

  $("#v14-cancel").addEventListener("click", async () => {
    if (!v14Job) return;
    const job = await api("/discovery/v14/jobs/" + v14Job.id + "/control", "POST", { action: "cancel" });
    renderV14Job(job);
  });

  $("#v14-retry").addEventListener("click", async () => {
    if (!v14Job) return;
    const job = await api("/discovery/v14/jobs/" + v14Job.id + "/control", "POST", { action: "retry" });
    await pollV14(job.id);
  });

  $("#v14-commit").addEventListener("click", async () => {
    if (!v14Job) return;
    try {
      const ids = [...main.querySelectorAll("[data-v14-pick]")].filter(b => b.checked).map(b => Number(b.dataset.v14Pick));
      const pid = Number($("#v14-project").value) || null;
      const res = await api("/discovery/v14/jobs/" + v14Job.id + "/commit", "POST", {
        candidate_ids: ids,
        project_id: pid,
        source_name: "V1.4 智能发现",
        permission: "内部审核与品牌匹配",
        operator: "ops",
        confirmed: true,
      });
      toast("已入库 " + res.added + " 位，关联已存在 " + res.updated + " 位，正在导出提报");
      window.open("/api/discovery/v14/jobs/" + v14Job.id + "/export?approved=true", "_blank");
    } catch (err) { toast(err.message, true); }
  });

  $("#discovery-suggest").addEventListener("click", async e => {
    e.target.disabled = true;
    try {
      const data = await api("/discovery/suggest", "POST", { brief: $("#discovery-brief").value.trim() });
      state.keywords = data.keywords || [];
      $("#discovery-keywords").innerHTML = keywordList();
      $("#discovery-note").textContent = data.understood
        ? "已按需求生成 " + state.keywords.length + " 条站内搜索建议。"
        : (data.notes[0] || "没有识别出行业词，请补充需求或手动添加关键词。");
    } catch (error) { toast(error.message, true); }
    finally { e.target.disabled = false; }
  });

  $("#discovery-add").addEventListener("click", () => {
    const term = $("#discovery-custom").value.trim();
    const platform = $("#discovery-platform").value;
    if (!term) return toast("先填写关键词", true);
    const q = encodeURIComponent(term);
    const url = platform === "YouTube" ? "https://www.youtube.com/results?search_query=" + q
      : platform === "Instagram" ? "https://www.instagram.com/explore/tags/" + encodeURIComponent(term.replace(/\s+/g, "")) + "/"
      : platform === "TikTok" ? "https://www.tiktok.com/search?q=" + q
      : "https://x.com/search?q=" + q + "&f=live";
    state.custom.push({ platform, term, url });
    $("#discovery-keywords").innerHTML = keywordList();
    $("#discovery-custom").value = "";
  });

  $("#discovery-parse").addEventListener("click", async e => {
    e.target.disabled = true;
    try {
      const data = await api("/discovery/parse", "POST", { text: $("#discovery-raw").value });
      state.candidates = data.candidates || [];
      state.existing = data.existing || [];
      $("#discovery-rows").innerHTML = candidateRows();
      $("#discovery-count").textContent = "新增 " + data.counts.parsed + " 位 · 库内已有 " + data.counts.existing +
        " 位 · 重复 " + data.counts.duplicates + " 位 · 无效 " + data.counts.invalid + " 行";
      $("#discovery-existing").textContent = state.existing.length
        ? "库内已有：" + state.existing.map(x => x.display_name + "（将直接引用到当前项目，不重复建档）").join("、")
        : "";
      $("#discovery-result").hidden = state.candidates.length === 0 && state.existing.length === 0;
      if (data.invalid.length) toast(data.invalid[0].reason + "（共 " + data.invalid.length + " 行）", true);
    } catch (error) { toast(error.message, true); }
    finally { e.target.disabled = false; }
  });

  main.addEventListener("input", e => {
    const row = e.target.dataset && e.target.dataset.row;
    const field = e.target.dataset && e.target.dataset.field;
    if (row !== undefined && field) {
      state.candidates[row][field] = e.target.value.trim() || null;
      main.querySelector('[data-missing="' + row + '"]').innerHTML = badges(state.candidates[row]);
    }
  });

  main.addEventListener("change", e => {
    const index = e.target.dataset && e.target.dataset.vertical;
    if (index !== undefined && state.candidates[index]) {
      state.candidates[index].vertical = e.target.value === "待定" ? null : e.target.value;
      main.querySelector('[data-missing="' + index + '"]').innerHTML = badges(state.candidates[index]);
    }
    if (e.target.id === "discovery-confirm") $("#discovery-apply").disabled = !e.target.checked;
  });

  $("#discovery-apply").addEventListener("click", async e => {
    e.target.disabled = true;
    try {
      const picks = [...main.querySelectorAll("[data-pick]")].filter(b => b.checked).map(b => Number(b.dataset.pick));
      const chosen = picks.map(i => state.candidates[i]).filter(Boolean);
      if (!chosen.length && !state.existing.length) throw Error("请至少勾选一位达人");
      const project = Number($("#discovery-project").value);
      if (!project) throw Error("请先创建品牌项目");
      const source = $("#discovery-source").value.trim();
      const permission = $("#discovery-permission").value.trim();
      const operator = $("#discovery-operator").value.trim();
      if (!source || !permission || !operator) throw Error("请填写来源、授权依据与操作人");
      if (!$("#discovery-confirm").checked) throw Error("请先勾选确认");
      const purposes = [...main.querySelectorAll("[data-purpose]")].filter(box => box.checked).map(box => box.dataset.purpose);
      if (!purposes.length) throw Error("请至少选择一种允许用途");
      const result = await api("/discovery/apply", "POST", {
        project, candidates: chosen,
        existing_accounts: state.existing.map(x => x.account),
        source_name: source, permission, operator, purposes, confirmed: true,
      });
      sessionStorage.setItem("creatorhub.intake.project", String(project));
      toast("已写入 " + (result.added || 0) + " 位，引用库内 " + (result.existing_linked || 0) + " 位");
      location.hash = "#intake";
    } catch (error) { toast(error.message, true); }
    finally { e.target.disabled = !$("#discovery-confirm").checked; }
  });
}
