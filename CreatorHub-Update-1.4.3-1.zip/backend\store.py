"""SQLite ownership, provenance, and account and project persistence."""
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3

from .domain import evaluate
from . import freshness
from .pilot_identity import PILOT_DATABASE_IDS
from .permissions import CONTACT, IDENTITY, INDEXED, active_fields, project_account

SCHEMA = """
CREATE TABLE IF NOT EXISTS workspaces (
    id INTEGER PRIMARY KEY, scope TEXT NOT NULL, CHECK(scope IN ('private','demo'))
);
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY, workspace_id INTEGER NOT NULL REFERENCES workspaces,
    platform TEXT NOT NULL, account_id TEXT NOT NULL, url TEXT NOT NULL,
    display_name TEXT, country TEXT, language TEXT, followers INTEGER, views INTEGER,
    email_state TEXT, bd TEXT, source TEXT NOT NULL, raw TEXT NOT NULL, updated_at TEXT NOT NULL, expires_at TEXT,
    UNIQUE(workspace_id, platform, account_id), UNIQUE(workspace_id, platform, url)
);
CREATE TABLE IF NOT EXISTS account_aliases (
    alias TEXT NOT NULL, platform TEXT NOT NULL, workspace_id INTEGER NOT NULL REFERENCES workspaces,
    account INTEGER NOT NULL REFERENCES accounts ON DELETE CASCADE,
    PRIMARY KEY(workspace_id, platform, alias)
);
CREATE TABLE IF NOT EXISTS analyses (
    account INTEGER REFERENCES accounts ON DELETE CASCADE, dimension TEXT, label TEXT,
    tier TEXT NOT NULL, model TEXT NOT NULL, evidence TEXT NOT NULL,
    PRIMARY KEY(account,dimension,label,model)
);
CREATE TABLE IF NOT EXISTS contacts (
    account INTEGER PRIMARY KEY REFERENCES accounts ON DELETE CASCADE,
    email TEXT, url TEXT, state TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY, workspace_id INTEGER NOT NULL REFERENCES workspaces,
    name TEXT NOT NULL, brief TEXT NOT NULL, criteria TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS matches (
    project INTEGER REFERENCES projects ON DELETE CASCADE, account INTEGER REFERENCES accounts ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending', basis TEXT NOT NULL, review_note TEXT NOT NULL DEFAULT '',
    submission_date TEXT, PRIMARY KEY(project,account)
);
CREATE TABLE IF NOT EXISTS intake_templates (
    name TEXT PRIMARY KEY, settings TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS project_metrics (
    project INTEGER PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
    stat TEXT NOT NULL CHECK(stat IN ('average','median')),
    minimum INTEGER CHECK(minimum >= 0)
);
CREATE TABLE IF NOT EXISTS project_intake (
    project INTEGER REFERENCES projects ON DELETE CASCADE,
    account INTEGER REFERENCES accounts ON DELETE CASCADE,
    settings TEXT NOT NULL, reviewed TEXT, operator TEXT, submitted_on TEXT,
    PRIMARY KEY(project, account)
);
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY, project INTEGER NOT NULL REFERENCES projects ON DELETE CASCADE,
    fingerprint TEXT NOT NULL, criteria TEXT NOT NULL, options TEXT NOT NULL,
    status TEXT NOT NULL, stage TEXT NOT NULL, found INTEGER NOT NULL DEFAULT 0,
    analyzed INTEGER NOT NULL DEFAULT 0, eligible INTEGER NOT NULL DEFAULT 0,
    duplicates INTEGER NOT NULL DEFAULT 0, added INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0, imported INTEGER NOT NULL DEFAULT 0,
    next_keyword INTEGER NOT NULL DEFAULT 0, error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS active_search ON tasks(fingerprint)
    WHERE status IN ('queued','running','paused','blocked');
CREATE TABLE IF NOT EXISTS task_candidates (
    task INTEGER REFERENCES tasks ON DELETE CASCADE, provider_id TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'pending', PRIMARY KEY(task,provider_id)
);
CREATE TABLE IF NOT EXISTS task_accounts (
    task INTEGER REFERENCES tasks ON DELETE CASCADE, account INTEGER REFERENCES accounts ON DELETE CASCADE,
    PRIMARY KEY(task,account)
);
CREATE TABLE IF NOT EXISTS provider_runs (
    id INTEGER PRIMARY KEY, task INTEGER REFERENCES tasks ON DELETE CASCADE, account INTEGER REFERENCES accounts ON DELETE CASCADE,
    provider TEXT NOT NULL, operation TEXT NOT NULL, result TEXT NOT NULL, message TEXT,
    started_at TEXT NOT NULL, elapsed_ms INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS import_history (
    id INTEGER PRIMARY KEY, policy TEXT NOT NULL, result TEXT NOT NULL, recorded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS review_history (
    id INTEGER PRIMARY KEY, project INTEGER NOT NULL REFERENCES projects ON DELETE CASCADE,
    account INTEGER NOT NULL REFERENCES accounts ON DELETE CASCADE,
    status TEXT NOT NULL, note TEXT NOT NULL, recorded_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS accounts_filters ON accounts(workspace_id,platform,country,language,followers);
CREATE TABLE IF NOT EXISTS retention_audit (
    id INTEGER PRIMARY KEY, event TEXT NOT NULL, field_count INTEGER NOT NULL, recorded_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS freshness_settings (
    field TEXT PRIMARY KEY,
    ttl_hours INTEGER,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS account_field_states (
    account INTEGER NOT NULL REFERENCES accounts ON DELETE CASCADE,
    field TEXT NOT NULL,
    last_succeeded_at TEXT,
    last_attempted_at TEXT,
    source_type TEXT,
    source_name TEXT,
    last_refresh_failed INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    PRIMARY KEY(account, field)
);
CREATE TABLE IF NOT EXISTS refresh_jobs (
    id INTEGER PRIMARY KEY,
    project INTEGER REFERENCES projects ON DELETE CASCADE,
    mode TEXT NOT NULL,
    status TEXT NOT NULL,
    total INTEGER NOT NULL DEFAULT 0,
    completed INTEGER NOT NULL DEFAULT 0,
    succeeded INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    skipped_fresh INTEGER NOT NULL DEFAULT 0,
    budget_limit INTEGER NOT NULL DEFAULT 50,
    calls_used INTEGER NOT NULL DEFAULT 0,
    error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS refresh_items (
    id INTEGER PRIMARY KEY,
    job INTEGER NOT NULL REFERENCES refresh_jobs ON DELETE CASCADE,
    account INTEGER NOT NULL REFERENCES accounts ON DELETE CASCADE,
    status TEXT NOT NULL,
    requested_fields TEXT NOT NULL,
    updated_fields TEXT NOT NULL DEFAULT '[]',
    error TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS active_refresh_account ON refresh_items(account)
    WHERE status IN ('queued','running');
CREATE TABLE IF NOT EXISTS discovery_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS discovery_jobs (
    id INTEGER PRIMARY KEY,
    project INTEGER,
    brief TEXT NOT NULL,
    scale TEXT NOT NULL,
    target_count INTEGER NOT NULL,
    provider TEXT NOT NULL,
    status TEXT NOT NULL,
    keywords TEXT NOT NULL,
    local_matched INTEGER NOT NULL DEFAULT 0,
    discovered_total INTEGER NOT NULL DEFAULT 0,
    processed INTEGER NOT NULL DEFAULT 0,
    succeeded INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS discovery_candidates (
    id INTEGER PRIMARY KEY,
    job INTEGER NOT NULL REFERENCES discovery_jobs ON DELETE CASCADE,
    channel_id TEXT NOT NULL,
    platform TEXT NOT NULL DEFAULT 'YouTube',
    url TEXT NOT NULL,
    display_name TEXT NOT NULL,
    handle TEXT,
    subscribers INTEGER,
    subscribers_approx INTEGER NOT NULL DEFAULT 1,
    recent_avg_views REAL,
    recent_median_views REAL,
    recent_sample_count INTEGER NOT NULL DEFAULT 0,
    long_avg_views REAL,
    long_median_views REAL,
    long_count INTEGER NOT NULL DEFAULT 0,
    shorts_avg_views REAL,
    shorts_count INTEGER NOT NULL DEFAULT 0,
    verticals TEXT NOT NULL DEFAULT '[]',
    relevance_score INTEGER NOT NULL DEFAULT 0,
    relevance_evidence TEXT NOT NULL DEFAULT '[]',
    sample_videos TEXT NOT NULL DEFAULT '[]',
    source_type TEXT NOT NULL,
    source_name TEXT NOT NULL,
    fetched_at TEXT,
    in_local_db INTEGER NOT NULL DEFAULT 0,
    local_account_id INTEGER,
    review_status TEXT NOT NULL DEFAULT 'pending',
    error TEXT,
    UNIQUE(job, channel_id)
);
"""

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def dump(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True)

def load(value):
    return json.loads(value)

class Store:
    def __init__(self, path, demo=False):
        self.path = Path(path)
        self.scope = "demo" if demo else "private"

    @contextmanager
    def connection(self, write=False):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        if db.execute('PRAGMA application_id').fetchone()[0] in PILOT_DATABASE_IDS:
            db.close()
            raise RuntimeError('Pilot database cannot be opened by the product')
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA secure_delete=ON")
        try:
            if write:
                db.execute("BEGIN IMMEDIATE")
            yield db
            if write:
                db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def setup(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.executescript(SCHEMA)
        with self.connection(True) as db:
            db.execute("INSERT OR IGNORE INTO workspaces VALUES (1,?)", (self.scope,))
            if db.execute("SELECT scope FROM workspaces WHERE id=1").fetchone()[0] != self.scope:
                raise RuntimeError("演示库和业务库不能共用数据库文件")
            if db.execute("PRAGMA user_version").fetchone()[0] < 2:
                db.execute("PRAGMA user_version=2")
            cols = {r[1] for r in db.execute("PRAGMA table_info(accounts)").fetchall()}
            if "bd" not in cols:
                db.execute("ALTER TABLE accounts ADD COLUMN bd TEXT")
            db.execute("CREATE INDEX IF NOT EXISTS accounts_bd ON accounts(workspace_id, bd)")
            db.execute("UPDATE tasks SET status='paused', error='服务已重启，可从进度处续跑' WHERE status IN ('queued','running')")
            db.execute("UPDATE refresh_jobs SET status='failed', error='服务已重启，请重新发起刷新' WHERE status IN ('queued','running')")
            db.execute("UPDATE refresh_items SET status='cancelled', error='服务已重启' WHERE status IN ('queued','running')")
            freshness.ensure_default_settings(db)
            self.purge(db)

    @staticmethod
    def purge(db):
        timestamp = now()
        today = timestamp[:10]
        records = db.execute(
            """SELECT id,raw FROM accounts WHERE json_type(raw,'$.provenance.fields')='object'
               AND (expires_at<=? OR EXISTS (
                   SELECT 1 FROM json_each(raw,'$.provenance.fields')
                   WHERE json_extract(value,'$.expires_on')<=?
               ))""", (timestamp, today),
        ).fetchall()
        for record in records:
            account_id, raw = record["id"], load(record["raw"])
            provenance = raw["provenance"]
            fields = active_fields(provenance, today)
            expired = provenance["fields"].keys() - fields.keys()
            if not set(IDENTITY) <= fields.keys():
                event, count = "account_expired", len(provenance["fields"])
                db.execute("DELETE FROM accounts WHERE id=?", (account_id,))
            else:
                event, count = "fields_expired", len(expired)
                for key in expired:
                    raw.pop(key, None)
                provenance["fields"] = fields
                db.execute("UPDATE accounts SET raw=?, " + ", ".join(f"{key}=?" for key in INDEXED)
                           + " WHERE id=?", (dump(raw), *(raw.get(key) for key in INDEXED), account_id))
                if expired.intersection(CONTACT):
                    db.execute("DELETE FROM contacts WHERE account=?", (account_id,))
                if "alias" in expired:
                    db.execute("DELETE FROM account_aliases WHERE account=?", (account_id,))
                db.execute("DELETE FROM analyses WHERE account=?", (account_id,))
                db.execute("UPDATE matches SET basis='{}', review_note='', status='pending', submission_date=NULL "
                           "WHERE account=?", (account_id,))
                db.execute("UPDATE review_history SET note='' WHERE account=?", (account_id,))
            db.execute("INSERT INTO retention_audit(event,field_count,recorded_at) VALUES(?,?,?)",
                       (event, count, timestamp))
        db.execute("DELETE FROM accounts WHERE expires_at IS NOT NULL AND expires_at <= ?", (timestamp,))
        # Discovery IDs are a separate cache and follow the same source lifetime.
        db.execute("DELETE FROM task_candidates WHERE task IN (SELECT id FROM tasks WHERE created_at <= ?)",
                   ((datetime.now(timezone.utc) - timedelta(days=29)).isoformat(timespec="seconds"),))

    def account(self, db, account_id, purpose="view"):
        row = db.execute("SELECT * FROM accounts WHERE id=? AND workspace_id=1 "
                         "AND (expires_at IS NULL OR expires_at>?)", (account_id, now())).fetchone()
        if not row:
            return None
        item = dict(row)
        item["raw"] = load(item["raw"])
        provenance = item["raw"].get("provenance", {})
        governed = isinstance(provenance.get("fields"), dict)
        if not governed and item["source"] != "fixture":
            return None
        contact = db.execute("SELECT * FROM contacts WHERE account=?", (account_id,)).fetchone()
        item["contact"] = dict(contact) if contact else None
        tags = db.execute("SELECT dimension,label,tier,model,evidence FROM analyses WHERE account=? "
                          "ORDER BY (model='manual') DESC, (model='rules-v1'), (tier='core') DESC,label",
                          (account_id,)).fetchall()
        item["tags"] = list({(tag["dimension"], tag["label"]):
                            {**dict(tag), "evidence": load(tag["evidence"])} for tag in reversed(tags)}.values())[::-1]
        item["projects"] = [dict(p) for p in db.execute(
            "SELECT p.id,p.name,m.status FROM matches m JOIN projects p ON p.id=m.project WHERE m.account=?",
            (account_id,))]
        return project_account(item, purpose, now()[:10])

    def find_accounts(self, db, filters):
        clauses, values = ["a.workspace_id=1", "(a.expires_at IS NULL OR a.expires_at>?)"], [now()]
        clauses.append("(a.source='fixture' OR (json_type(a.raw,'$.provenance.fields')='object' AND "
                       "EXISTS(SELECT 1 FROM json_each(a.raw,'$.provenance.fields.platform.purposes') WHERE value='view')))")
        for key in ("platform", "country", "language", "email_state"):
            if filters.get(key):
                clauses.append(f"a.{key}=?")
                values.append(filters[key])
        for key, column in (("followers", "followers"), ("views", "views")):
            if filters.get(key) is not None:
                clauses.append(f"a.{column}>=?")
                values.append(filters[key])
        bd_term = (filters.get("bd") or "").strip()
        if bd_term:
            clauses.append("instr(lower(coalesce(a.bd,'')), lower(?))>0")
            values.append(bd_term)
        term = filters.get("query", "").strip()
        if term:
            clauses.append("(instr(lower(a.display_name), lower(?))>0 OR instr(lower(a.account_id), lower(?))>0 OR instr(lower(a.url), lower(?))>0)")
            values.extend([term] * 3)
        limit, offset = filters.get("limit", 50), filters.get("offset", 0)
        where = " AND ".join(clauses)
        if filters.get("tag"):
            items = [self.account(db, row[0]) for row in
                     db.execute("SELECT id FROM accounts a WHERE " + where + " ORDER BY id DESC", values)]
            term = filters["tag"].casefold()
            matching = [item for item in items if item and any(term in tag["label"].casefold() for tag in item["tags"])]
            return {"items": matching[offset:offset + limit], "total": len(matching)}
        total = db.execute("SELECT count(*) FROM accounts a WHERE " + where, values).fetchone()[0]
        ids = db.execute("SELECT id FROM accounts a WHERE " + where + " ORDER BY id DESC LIMIT ? OFFSET ?",
                         [*values, limit, offset])
        return {"items": [self.account(db, r[0]) for r in ids], "total": total}

    def save_account(self, db, profile, tags=()):
        source = profile["source"]
        if (source == "fixture") != (self.scope == "demo"):
            raise ValueError("演示数据与业务数据必须分库")
        platform, identifier, url = profile["platform"], profile["account_id"], profile["url"]
        alias = profile.get("alias") or identifier
        existing = db.execute(
            "SELECT id,source,account_id,url,raw FROM accounts WHERE workspace_id=1 AND platform=? "
            "AND (account_id IN (?,?) OR url=? OR id IN (SELECT account FROM account_aliases "
            "WHERE workspace_id=1 AND platform=? AND alias IN (?,?)))",
            (platform, identifier, alias, url, platform, identifier, alias)).fetchall()
        if len(existing) > 1:
            raise ValueError("账号 ID 与主页归属不同记录，需要人工核实")
        if existing and platform == "YouTube" and profile.get("alias"):
            old_id = existing[0]["account_id"]
            if old_id not in (identifier, alias):
                raise ValueError("该 YouTube 别名已对应另一个频道 ID，需要人工核实")
        if existing and existing[0]["source"] != source:
            return existing[0]["id"], False
        if existing and profile.get("provenance"):
            prior = load(existing[0]["raw"]).get("provenance", {})
            incoming = profile["provenance"]
            if not isinstance(prior.get("fields"), dict) or any(
                prior.get(key) != incoming[key] for key in
                ("source_name", "permission", "effective_on", "acquired_on", "expires_on",
                 "deletion_owner", "purposes", "allowed_fields", "restricted_fields", "field_expiries", "field_purposes")
            ):
                return existing[0]["id"], False
            # The previous stable identity may be reused only within the same grant.
            if "alias" in prior["fields"] and "alias" not in incoming["fields"]:
                incoming["fields"]["alias"] = prior["fields"]["alias"]
        if existing and platform == "YouTube" and identifier.startswith("@"):
            identifier, url = existing[0]["account_id"], existing[0]["url"]
        if existing:
            prior_raw = load(existing[0]["raw"])
            if prior_raw.get("bd") and not profile.get("bd"):
                profile = {**profile, "bd": prior_raw["bd"]}
                if profile.get("provenance") and "bd" in prior_raw.get("provenance", {}).get("fields", {}):
                    profile["provenance"]["fields"]["bd"] = prior_raw["provenance"]["fields"]["bd"]
        timestamp = now()
        expires = (datetime.now(timezone.utc) + timedelta(days=29)).isoformat(timespec="seconds") if source == "youtube_api" else None
        if profile.get("provenance"):
            expires = min(profile["provenance"]["fields"][key]["expires_on"] for key in IDENTITY) + "T00:00:00+00:00"
        fields = INDEXED
        keys = ", ".join((*fields, "source", "raw", "updated_at", "expires_at"))
        raw = {k: v for k, v in profile.items() if k not in ("email", "email_url", "alias")}
        raw.update(account_id=identifier, url=url)
        params = [*(profile.get(k) for k in fields), source, dump(raw), timestamp, expires]
        if existing:
            account_id = existing[0]["id"]
            db.execute("UPDATE accounts SET account_id=?,url=?," + ", ".join(k + "=?" for k in keys.split(", "))
                       + " WHERE id=?", [identifier, url, *params, account_id])
        else:
            account_id = db.execute(
                f"INSERT INTO accounts(workspace_id,platform,account_id,url,{keys}) VALUES(1,{','.join('?' for _ in range(len(params)+3))})",
                [platform, identifier, url, *params]).lastrowid
        if profile.get("alias"):
            old_alias = db.execute("SELECT account FROM account_aliases WHERE workspace_id=1 AND platform=? AND alias=?",
                                   (platform, profile["alias"])).fetchone()
            if old_alias and old_alias[0] != account_id:
                raise ValueError("账号别名与已收录记录冲突")
            db.execute("INSERT OR IGNORE INTO account_aliases VALUES(?,?,1,?)",
                       (profile["alias"], platform, account_id))
        if source != "youtube_api":
            db.execute("INSERT INTO contacts VALUES(?,?,?,?,?) ON CONFLICT(account) DO UPDATE SET "
                       "email=excluded.email,url=excluded.url,state=excluded.state,updated_at=excluded.updated_at",
                       (account_id, profile.get("email"), profile.get("email_url"), profile.get("email_state") or "unavailable", timestamp))
            self.save_tags(db, account_id, () if profile.get("provenance") else tags, "rules-v1")
        src_name = (profile.get("provenance") or {}).get("source_name") or source
        src_type = "youtube_api" if source == "youtube_api" else "import"
        freshness.sync_account_states(db, account_id, {**profile, "tags": tags}, src_type, src_name, timestamp)
        return account_id, not existing

    def update_account_bd(self, db, account_id, bd_value):
        row = db.execute("SELECT id, raw FROM accounts WHERE id=? AND workspace_id=1", (account_id,)).fetchone()
        if not row:
            raise KeyError("达人不存在或数据已过期")
        clean = (bd_value or "").strip() or None
        raw = load(row["raw"])
        timestamp = now()
        if clean is None:
            raw.pop("bd", None)
        else:
            raw["bd"] = clean
        prov = raw.get("provenance")
        if isinstance(prov, dict) and isinstance(prov.get("fields"), dict):
            base_grant = prov["fields"].get("url") or prov["fields"].get("platform")
            if clean is None:
                prov["fields"].pop("bd", None)
            elif base_grant:
                prov["fields"]["bd"] = {**base_grant, "updated_at": timestamp}
        db.execute("UPDATE accounts SET bd=?, raw=?, updated_at=? WHERE id=?", (clean, dump(raw), timestamp, account_id))
        return clean

    @staticmethod
    def save_tags(db, account, tags, model):
        db.execute("DELETE FROM analyses WHERE account=? AND model=?", (account, model))
        db.executemany("INSERT OR REPLACE INTO analyses VALUES(?,?,?,?,?,?)",
                       [(account, t["dimension"], t["label"], t["tier"], model, dump(t["evidence"])) for t in tags])

    @staticmethod
    def match(db, project, account, basis):
        if basis["state"] == "excluded":
            db.execute("DELETE FROM matches WHERE project=? AND account=? AND status='pending'", (project, account))
            db.execute("UPDATE matches SET basis=? WHERE project=? AND account=?", (dump(basis), project, account))
            return
        db.execute("INSERT INTO matches(project,account,basis) VALUES(?,?,?) "
                   "ON CONFLICT(project,account) DO UPDATE SET basis=excluded.basis",
                   (project, account, dump(basis)))

    def apply_match(self, db, project, account_id, criteria):
        account = self.account(db, account_id, "match")
        if account is None:
            return "excluded"
        basis = evaluate(account, criteria, use_topics=account["source"] != "youtube_api")
        state = freshness.compute_freshness(db, account)
        basis["used_values"] = freshness.match_snapshot(account, state)
        self.match(db, project, account_id, basis)
        return basis["state"]
