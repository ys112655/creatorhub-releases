import { intakePage } from "./intake.js";
import { discoveryPage } from "./discovery.js";
import { batchImportPage } from "./batch_import.js";
import { updatePage } from "./update.js";
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const main=$("#main"), modal=$("#dialog"), modalBody=$("#dialog-body");
const h=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const ch=v=>v?"checked":"", sel=v=>v?"selected":"";
const n=v=>v==null?"—":Number(v).toLocaleString("zh-CN");
const date=v=>v?new Date(v).toLocaleString("zh-CN",{timeZone:"Asia/Shanghai"}):"—";
const chip=(text,style="")=>'<span class="chip '+h(style)+'">'+h(text)+'</span>';
const freshLabels={fresh:"最新",stale:"已过期",missing:"缺失",failed:"刷新失败",manual:"人工维护"};
const freshBadge=s=>chip(freshLabels[s]||"未知",s==="fresh"?"good":s==="failed"?"bad":s==="manual"?"":"warn");
const options=(values,current)=>values.map(([k,v])=>'<option value="'+h(k)+'" '+sel(k===current)+'>'+h(v)+'</option>').join("");
const mail={verified:"已核实",not_found:"未找到",manual:"待人工核实",unavailable:"无法获取"};
const source={fixture:"模拟资料",youtube_api:"YouTube 官方 API · 临时缓存",independent:"独立公开资料",authorized:"授权导入"};
const review={pending:"待审核",accepted:"已通过",submitted:"已提报",rejected:"已拒绝"};
const reviewOrder={accepted:0,submitted:0,pending:1,rejected:2};
const stat={queued:"排队中",running:"运行中",paused:"已暂停",blocked:"待处理",done:"已完成",cancelled:"已取消"};
const stages={library:"库内匹配",discover:"关键词发现",profiles:"频道资料",complete:"已结束"};
const labels={min_followers:"最低粉丝量",max_followers:"最高粉丝量",countries:"国家",languages:"内容语言",email:"已核实邮箱",topics:"相关主题"};
const state={view:"",meta:null,task:0,project:0,draft:{name:"",brief:"",platforms:["YouTube"],limit:30,discover:false},saved:new Map(),filters:{},offset:0};
const SAMPLE="寻找欧美地区的 AI电影、VFX、ComfyUI 和 AI视频生成达人，粉丝量5万以上，英语内容，优先具有公开商务邮箱。";
let toastTimer;
async function api(url,method="GET",data){
  const init={method};
  if(data!==undefined){init.headers={"Content-Type":"application/json"};init.body=JSON.stringify(data);}
  const res=await fetch("/api"+url,init);
  const value=await res.json().catch(()=>({}));
  if(!res.ok)throw Error(typeof value.detail==="string"?value.detail:"请求失败，请核对表单内容");
  return value;
}
function toast(message,error=false){
  const node=$("#toast");node.textContent=message;node.classList.toggle("error",error);node.hidden=false;
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.hidden=true,4500);
}
function on(root,selector,fn,event="click"){
  for(const el of $$(selector,root))el.addEventListener(event,async e=>{
    e.preventDefault();
    const button=e.submitter||(el.tagName==="BUTTON"?el:null);
    if(button)button.disabled=true;
    try{await fn(e,el);}catch(error){toast(error.message,true);}
    finally{if(button)button.disabled=false;}
  });
}
function show(html){modalBody.innerHTML=html;if(!modal.open)modal.showModal();}
function link(value){
  try{const u=new URL(value);if(["https:","http:"].includes(u.protocol))return '<a href="'+h(u.href)+'" target="_blank" rel="noopener noreferrer">查看来源 ↗</a>';}catch{}
  return "—";
}
function hero(title,copy,extra=""){
  return '<section class="hero"><div><h1>'+h(title)+'</h1><p>'+h(copy)+'</p></div><div class="hero-summary">'+extra+'</div></section>';
}
function platformOptions(selected){
  return Object.keys(state.meta.platforms).map(p=>'<label class="option"><input type="checkbox" name="platform" value="'+p+'" '+ch(selected.includes(p))+'> '+p+
    ' <small>'+(p==="YouTube"?h(state.meta.youtube):"新发现未接入")+'</small></label>').join("");
}
function readSearch(){
  const f=new FormData($("#search-form")), d=state.draft;
  Object.assign(d,{name:f.get("name").trim(),brief:f.get("brief").trim(),platforms:f.getAll("platform"),limit:Number(f.get("limit")),discover:f.has("discover")});
  return d;
}
function renderCriteria(){
  const p=state.draft.parsed,node=$("#criteria");
  $("#run-match").hidden=!p;
  $("#parse").hidden=Boolean(p);
  if(!p){node.innerHTML='<p class="empty">解析需求后，可复核硬条件、关键词和偏好。</p>';return;}
  const hard=p.hard,pref=p.preferences;
  const groups=(p.groups||[]).map(g=>'<li>'+h(g.label)+' · 订阅 '+n(g.followers)+' · 中位播放 '+n(g.median_views)+'</li>').join("");
  const pending=(p.pending||[]).map(item=>'<li><strong>'+h(item.label)+'</strong> · '+h(item.text)+'</li>').join("");
  const review=[...(p.model_review||[]),...(p.model_requirements||[]).map(item=>item.quote),...(p.model_platforms?.length?["模型建议平台："+p.model_platforms.join("、")]:[])]
    .map(item=>'<li>'+h(item)+'</li>').join("");
  const needsReview=Boolean(pending||review);
  const values=[...(pref.email?["公开商务邮箱"]:[]),...(pref.countries||[]),...(pref.languages||[]),
    ...(pref.min_followers!=null?["粉丝 ≥ "+n(pref.min_followers)]:[]),...(pref.max_followers!=null?["粉丝 ≤ "+n(pref.max_followers)]:[])];
  node.innerHTML='<h3>可执行条件</h3><div class="preview form-grid">'+
    '<label>最低粉丝量<input id="min" type="number" min="0" value="'+h(hard.min_followers)+'"></label>'+
    '<label>最高粉丝量<input id="max" type="number" min="0" value="'+h(hard.max_followers)+'"></label>'+
    '<label>国家或地区（如日本、韩国）<input id="country-codes" value="'+h((hard.countries||[]).join(","))+'" placeholder="US,GB,CA"></label>'+
    '<label>内容语言（如日语、韩语）<input id="language-codes" value="'+h((hard.languages||[]).join(","))+'" placeholder="en"></label>'+
    '<label class="check span-all"><input id="hard-email" type="checkbox" '+ch(hard.email)+'> 必须有公开商务邮箱</label>'+
    '<label class="span-all">搜索关键词<textarea id="keywords" rows="3">'+h(p.keywords.join("\n"))+'</textarea></label>'+
    '<small class="span-all">每行一条，在线发现使用前 4 条。</small><div class="tags span-all">'+p.topics.map(t=>chip(t.label+(t.preferred?" · 偏好":""))).join("")+
    '</div><p class="muted span-all">偏好条件 · '+h(values.join("、")||"无")+'</p></div>'+
    (groups?'<h3>原文分类门槛</h3><ul>'+groups+'</ul>':'')+
    (needsReview?'<h3>需要人工核验</h3><ul>'+pending+review+'</ul>'+
      '<label><input type="checkbox" id="manual-confirm"> 我已核对原文，仅按可执行条件匹配，剩余条件逐项人工核验</label>':'')+
    (p.note?'<p class="muted">'+h(p.note)+'</p>':'');
}
function readCriteria(){
  const d=state.draft.parsed,hard={};
  for(const [id,key] of [["min","min_followers"],["max","max_followers"]]){
    const el=$("#"+id);
    if(el.validity.badInput)throw Error("粉丝门槛需为非负整数");
    if(el.value==="")continue;
    const value=Number(el.value);
    if(!Number.isSafeInteger(value)||value<0)throw Error("粉丝门槛需为非负整数");
    hard[key]=value;
  }
  if($("#hard-email").checked)hard.email=true;
  for(const [id,key,pattern,transform] of [
    ["country-codes","countries",/^[A-Z]{2}$/,v=>v.toUpperCase()],
    ["language-codes","languages",/^[a-z]{2,3}$/,v=>v.toLowerCase()]
  ]){
    const codes=[...new Set($("#"+id).value.split(/[，,\s]+/).filter(Boolean).map(transform))];
    const aliases=key==="countries"?{"日本":"JP","韩国":"KR","韓國":"KR","美国":"US","英国":"GB","加拿大":"CA"}:
      {"日语":"ja","韩语":"ko","韓語":"ko","中文":"zh","英语":"en"};
    for(let i=0;i<codes.length;i++)codes[i]=aliases[codes[i]]||codes[i];
    if(codes.some(v=>!pattern.test(v)))throw Error("请核对国家或地区及内容语言");
    if(codes.length)hard[key]=codes;
  }
  const keywords=[...new Set($("#keywords").value.split("\n").map(v=>v.trim()).filter(Boolean))];
  return {hard,preferences:d.preferences,topics:d.topics,keywords};
}
async function parseInput(){
  const d=readSearch(),brief=d.brief;
  if(!brief)throw Error("请填写品牌需求");
  const result=await api("/parse","POST",{brief,allow_model:$("#allow-brief-model")?.checked ?? false});
  if(state.view!=="search"||readSearch().brief!==brief)return;
  d.parsed=result;
  if(result.platforms.length)for(const el of $$("input[name=platform]",main))el.checked=result.platforms.includes(el.value);
  readSearch();renderCriteria();toast("已解析，请复核筛选条件");
}
function searchPage(){
  const d=state.draft;
  main.innerHTML=hero("匹配已有达人","粘贴品牌需求，核对筛选条件后查看已有候选。",
    "")+
    '<div class="search-grid"><div class="stack"><section class="card"><div class="card-head"><h2>品牌需求</h2><button id="sample" class="quiet" type="button">查看示例</button></div>'+
    '<form class="stack" id="search-form">'+
    '<label>粘贴品牌需求<textarea name="brief" required maxlength="3000" rows="5" placeholder="'+h(SAMPLE)+'">'+h(d.brief)+'</textarea></label>'+
    '<details><summary>项目名称和匹配设置</summary><label>项目名称（可选）<input name="name" maxlength="100" value="'+h(d.name)+'"></label>'+
    '<div><h3>目标平台</h3><div class="options">'+platformOptions(d.platforms)+'</div></div>'+
    '<div class="form-grid"><label>候选数量上限<input name="limit" type="number" min="1" max="50" required value="'+d.limit+'"></label>'+
    (state.meta.demo?'<label><input name="discover" type="checkbox">使用合成发现数据</label>':"")+'</div></details>'+
    (state.meta.structured_model?'<label><input type="checkbox" id="allow-brief-model"> 我授权将本次品牌需求发送给已配置的模型供应商</label>':"")+
    '<div class="actions"><button id="parse" class="primary" type="button" '+(d.parsed?'hidden':"")+'>解析需求</button><button class="primary" id="run-match" type="submit" hidden>确认并匹配已有达人</button></div></form></section>'+
    '<section id="recent-task" class="card"><h2>搜索进度</h2><p class="empty">开始搜索后在这里查看进度。</p></section></div>'+
    '<div class="stack"><section class="card"><div class="card-head"><h2>筛选条件</h2>'+chip("规则解析")+'</div><div id="criteria"></div></section>'+
    '<section class="card stack"><h2>资料来源</h2><p class="callout">优先检索已有达人库。YouTube 结果可能缺少国家、语言和联系信息，需人工核实。</p>'+
    (state.meta.demo?'<p class="callout warn">当前是独立演示库。账号和项目仅用于功能验证。</p>':'')+'</section></div></div>';
  renderCriteria();
  on(main,"#sample",()=>{
    $("#search-form [name=name]").value=(state.meta.demo?"演示 · ":"")+"AI 视频创作者";
    $("#search-form [name=brief]").value=SAMPLE;
    readSearch();d.parsed=null;renderCriteria();
  });
  $("#search-form").addEventListener("input",e=>{readSearch();if(e.target.name==="brief"&&d.parsed){d.parsed=null;renderCriteria();}});
  on(main,"#parse",parseInput);
  on(main,"#search-form",async()=>{
    readSearch();
    if(!d.platforms.length)throw Error("至少选择一个目标平台");
    if(d.discover&&!d.platforms.includes("YouTube"))throw Error("在线发现需要选择 YouTube");
    if(!d.parsed){await parseInput();return;}
    if($("#manual-confirm")&&!$("#manual-confirm").checked)throw Error("请先确认待人工核验条件");
    if(!d.name)d.name=d.brief.split(/[，。；\n]/)[0].slice(0,50);
    const criteria=readCriteria(),signature=JSON.stringify([d.name,d.brief,criteria]);
    let project=state.saved.get(signature);
    if(!project){project=(await api("/projects","POST",{name:d.name,brief:d.brief,criteria})).id;state.saved.set(signature,project);}
    const task=await api("/tasks","POST",{project,platforms:d.platforms,limit:d.limit,discover:d.discover,manual_confirmation:$("#manual-confirm")?.checked||false,keywords:criteria.keywords.slice(0,4)});
    state.project=project;state.task=task.id;
    location.hash="#projects/"+project;
    toast(task.reused?"已打开相同的进行中任务":"正在匹配已有达人");
  },"submit");
  if(state.task)refreshTask().catch(e=>toast(e.message,true));
}
function taskHtml(t,withLink=false){
  const running=["queued","running"].includes(t.status), final=["done","cancelled"].includes(t.status);
  const calls=(t.calls||[]).map(c=>c.operation+" "+c.total+" 次"+(c.result==="failed"?"失败":"")).join(" · ");
  return '<div class="card-head"><h2>搜索任务 #'+t.id+'</h2>'+chip(stat[t.status],t.status==="blocked"?"warn":t.status==="done"?"good":"")+'</div>'+
    '<div class="stack"><small>'+h(stages[t.stage])+' · 库内候选 '+t.imported+' · 新增 '+t.added+' · 已有账号 '+t.duplicates+
    (calls?" · "+h(calls):"")+'</small>'+
    (running?'<progress aria-label="搜索进度" '+(t.stage==="profiles"&&t.found?'value="'+(t.analyzed+t.failed)+'" max="'+t.found+'"':'')+'></progress>':'')+
    '<div class="stats">'+[["在线发现",t.found],["资料成功",t.analyzed],["在线合格",t.eligible],["资料失败",t.failed]]
      .map(([k,v])=>'<div class="stat"><b>'+v+'</b><span>'+k+'</span></div>').join("")+'</div>'+
    (t.error?'<p class="callout warn">'+h(t.error)+'</p>':'')+'<div class="actions">'+
    (running?'<button data-action="pause">暂停</button>':'')+
    (["paused","blocked"].includes(t.status)?'<button data-action="resume">续跑</button>':'')+
    (!final?'<button data-action="cancel" class="danger">取消任务</button>':'')+
    (withLink?'<a class="btn" href="#projects/'+t.project+'">查看项目候选</a>':'')+'</div></div>';
}
function bindTask(root,t,refresh){
  on(root,"[data-action]",async(e,b)=>{await api("/tasks/"+t.id,"PATCH",{action:b.dataset.action});await refresh();});
}
async function refreshTask(){
  const root=$("#recent-task"),id=state.task;
  if(!root||!id)return;
  const result=await api("/tasks/"+id);
  if(root!==$("#recent-task")||id!==state.task)return;
  const version=JSON.stringify(result);
  if(root.dataset.version===version)return;
  root.dataset.version=version;root.innerHTML=taskHtml(result,true);bindTask(root,result,refreshTask);
}
function table(title,headers,rows,foot=""){
  return '<section class="card table-card"><div class="card-head"><h2>'+h(title)+'</h2></div>'+
    (rows?'<div class="table-scroll"><table><thead><tr>'+headers.map(t=>'<th scope="col">'+h(t)+'</th>').join("")+
    '</tr></thead><tbody>'+rows+'</tbody></table></div>':'<p class="empty">暂无符合条件的记录。</p>')+foot+'</section>';
}
function account(a){return '<button class="account-name" data-account="'+a.id+'">'+h(a.display_name)+'</button><span class="cell-detail">'+h(a.account_id)+'</span>';}
function bindAccounts(root){on(root,"[data-account]",(e,b)=>showAccount(b.dataset.account));}
async function libraryPage(){
  const f=state.filters;
  function field(k,t,p){return '<label>'+t+'<input name="'+k+'" placeholder="'+p+'" value="'+h(f[k])+'"></label>';}
  main.innerHTML=hero("达人总库","筛选已收录账号，查看公开资料、字段时效、标签证据和历史项目。",
    (state.meta.demo?chip("模拟数据","warn"):'<button class="primary" id="import">导入表格</button><a class="btn primary" href="#batch-import" id="go-batch-import">Excel / CSV 批量导入</a>')+' <button id="ttl-settings-btn">时效设置</button>')+
    '<div class="stack"><form class="card stack" id="filters"><div class="form-grid triple">'+
    field("query","搜索账号","名称、ID 或链接")+'<label>平台<select name="platform">'+
    options([["","全部平台"],...Object.keys(state.meta.platforms).map(p=>[p,p])],f.platform)+'</select></label>'+
    field("country","国家","如 US")+field("language","语言","如 en")+field("followers","最低粉丝量","如 50K")+
    field("views","最低均播","如 5K")+field("tag","标签","如 ComfyUI")+field("bd","BD","负责人姓名")+
    '<label>商务邮箱<select name="email_state">'+options([["","全部状态"],...Object.entries(mail)],f.email_state)+'</select></label>'+
    '</div><div class="actions"><button class="primary" type="submit">筛选</button><button id="clear" type="button">清除</button></div></form>'+
    '<div id="account-table" aria-live="polite"></div></div>';
  on(main,"#filters",async e=>{state.filters=Object.fromEntries(new FormData(e.target));state.offset=0;await refreshAccounts();},"submit");
  on(main,"#clear",()=>{state.filters={};state.offset=0;return libraryPage();});
  on(main,"#import",importDialog);
  on(main,"#ttl-settings-btn",showTtlSettings);
  await refreshAccounts();
}
async function showTtlSettings(){
  const data=await api("/freshness/settings");
  const rows=Object.entries(data.ttls).map(([k,v])=>{
    const label=data.labels[k]||k;
    if(v===null)return '<label>'+h(label)+'<input value="人工维护（不自动刷新）" disabled></label>';
    return '<label>'+h(label)+'（小时）<input type="number" min="1" max="8760" name="'+h(k)+'" value="'+h(v)+'" required></label>';
  }).join("");
  show('<form id="ttl-form" class="stack"><h2>字段数据时效设置</h2><p class="muted">超过有效期后，字段将标记为「已过期」，并在按需刷新时优先更新。报价与合作记录固定人工维护。</p><div class="form-grid">'+rows+'</div><div class="actions"><button class="primary" type="submit">保存设置</button></div></form>');
  on(modalBody,"#ttl-form",async e=>{
    const payload={};
    for(const [k,v] of new FormData(e.target).entries())payload[k]=Number(v);
    await api("/freshness/settings","PUT",{ttls:payload});
    modal.close();toast("数据时效设置已更新");
    if(state.view==="library")await refreshAccounts();
    if(state.view==="projects"&&state.project)await refreshProject();
  },"submit");
}
async function refreshAccounts(){
  const root=$("#account-table"),offset=state.offset;
  if(!root)return;
  const data=await api("/accounts?"+new URLSearchParams({...state.filters,limit:20,offset}));
  if(root!==$("#account-table")||offset!==state.offset)return;
  const rows=data.items.map(a=>'<tr><td>'+account(a)+'</td><td>'+h(a.platform)+'</td><td>'+
    h([a.country,a.language].filter(Boolean).join(" / ")||"—")+'</td><td>'+n(a.followers)+'</td><td>'+n(a.views)+'</td><td>'+
    h(a.bd||"—")+'</td><td>'+h(mail[a.email_state])+'</td><td>'+freshBadge(a.freshness?.overall_status)+'</td><td>'+a.tags.slice(0,3).map(t=>chip(t.label,t.tier==="core"?"good":"")).join(" ")+'</td><td>'+h(source[a.source])+'</td></tr>').join("");
  const pager='<div class="table-foot toolbar"><small>'+n(data.total)+' 条</small><div class="actions"><button id="prev" '+
    (offset?"":"disabled")+'>上一页</button><button id="next" '+(offset+20<data.total?"":"disabled")+'>下一页</button></div></div>';
  root.innerHTML=table("达人账号",["账号","平台","国家 / 语言","粉丝量","均播","BD","商务邮箱","时效状态","标签","来源"],rows,pager);
  bindAccounts(root);
  on(root,"#prev",()=>{state.offset-=20;return refreshAccounts();});
  on(root,"#next",()=>{state.offset+=20;return refreshAccounts();});
}
function importDialog(){
  show('<form id="import-form" class="stack"><h2>导入授权表格</h2><p class="muted">粘贴含表头的 Excel、飞书或 CSV 数据。至少包含平台与账号ID或主页链接，每次最多 200 行。</p>'+
    '<label>数据来源<select name="source"><option value="independent">独立公开资料</option><option value="authorized">获准导入的资料</option></select></label>'+
    '<label>来源名称<input name="source_name" required maxlength="120"></label>'+
    '<label>授权依据<input name="permission" required maxlength="500" placeholder="记录授权文件或可核查依据"></label>'+
    '<label>删除责任人<input name="deletion_owner" required maxlength="120"></label>'+
    '<label>授权生效日期（UTC）<input name="effective_on" required type="date"></label>'+
    '<label>获取日期（UTC）<input name="acquired_on" required type="date"></label>'+
    '<label>到期日期（UTC 零点）<input name="expires_on" required type="date"></label>'+
    '<label>获准列（逗号分隔）<input name="allowed_fields" required placeholder="平台,账号ID,主页链接,国家"></label>'+
    '<fieldset><legend>获准用途</legend>'+[["view","查看"],["tag","生成标签"],["match","匹配"],["export","提报"]]
      .map(([value,label])=>'<label><input type="checkbox" name="purposes" value="'+value+'"> '+label+'</label>').join("")+'</fieldset>'+
    '<label>限制列（逗号分隔，整列排除）<input name="restricted_fields" placeholder="例如：邮箱,报价"></label>'+
    '<label>字段单独截止日（JSON，可选）<input name="field_expiries" placeholder=\'{"报价":"2026-12-01"}\'></label>'+
    '<label>字段单独用途（JSON，可选）<input name="field_purposes" placeholder=\'{"报价":["view"]}\'></label>'+
    '<label>表格数据<textarea name="text" rows="8" required placeholder="平台&#9;账号ID&#9;国家&#9;粉丝量(K)"></textarea></label>'+
    '<label class="option"><input name="confirmed" type="checkbox" required> 我已核验剩余字段可保存、用于匹配及提报，且不含未获准的内部资料</label>'+
    '<div id="import-result" aria-live="polite"></div><div class="actions"><button class="primary" type="submit">导入并去重</button></div></form>');
  on(modalBody,"#import-form",async e=>{
    const data=new FormData(e.target);
    const columns=name=>data.get(name).split(/[,，]/).map(value=>value.trim()).filter(Boolean);
    const policy={source_name:data.get("source_name"),permission:data.get("permission"),
      deletion_owner:data.get("deletion_owner"),effective_on:data.get("effective_on"),
      acquired_on:data.get("acquired_on"),expires_on:data.get("expires_on"),
      allowed_fields:columns("allowed_fields"),restricted_fields:columns("restricted_fields"),
      purposes:data.getAll("purposes"),field_expiries:JSON.parse(data.get("field_expiries")||"{}"),
      field_purposes:JSON.parse(data.get("field_purposes")||"{}")};
    const r=await api("/accounts/import","POST",{text:data.get("text"),source:data.get("source"),confirmed:data.has("confirmed"),policy});
    $("#import-result").innerHTML='<p class="callout">新增 '+r.added+' 条 · 重复 '+r.duplicates+' 条 · 失败 '+r.rejected.length+' 条</p>'+
      (r.receipt_id?'<p class="muted">导入回执 #'+h(r.receipt_id)+'。重复记录保留原资料和授权。</p>':'')+
      (r.preserved_provider?'<p class="callout warn">'+r.preserved_provider+' 条仍使用原 YouTube 缓存，资料来源未合并。</p>':'')+
      (r.rejected.length?'<ul class="evidence-list">'+r.rejected.map(row=>'<li>第 '+row.line+' 行 · '+h(row.reason)+'</li>').join("")+'</ul>':'');
    await refreshAccounts();
  },"submit");
}
function evidence(items){return '<ul class="evidence-list">'+items.map(i=>'<li>'+h(i.title)+' · '+link(i.url)+'</li>').join("")+'</ul>';}
async function showAccount(id){
  const a=await api("/accounts/"+id),c=a.contact,p=a.raw.provenance;
  const rows=[["账号",a.account_id],["平台",a.platform],["国家",a.country],["语言",a.language],
    ["粉丝量",n(a.followers)],["均播",n(a.views)],["BD",a.bd],["邮箱状态",mail[a.email_state]],["资料时间",date(a.updated_at)],["来源",source[a.source]]];
  if(p) rows.push(["导入来源",p.source_name],["授权依据",p.permission],["获取日期（UTC）",p.acquired_on],
    ["到期日期（UTC）",p.expires_on],["排除字段",p.restricted_fields.join("、")||"无"]);
  const tags=a.tags.map(t=>'<li><details><summary>'+h(t.dimension+" / "+t.label)+' '+chip(t.tier==="core"?"核心":"次要")+
    ' <small>'+h(t.model)+'</small></summary>'+evidence(t.evidence)+(p?'':'<div class="actions"><button data-remove="'+h(t.label)+
    '" data-dimension="'+h(t.dimension)+'" data-model="'+h(t.model)+'">删除标签</button></div>')+'</details></li>').join("");
  const history=a.projects.map(p=>'<a class="btn" data-history href="#projects/'+p.id+'">'+h(p.name+" · "+review[p.status])+'</a>').join("");
  const fMap=a.freshness?.fields||{};
  const fRows=Object.values(fMap).map(f=>'<tr><td>'+h(f.label)+'</td><td>'+freshBadge(f.status)+'</td><td>'+h(f.source_name||"—")+
    '</td><td>'+h(f.last_succeeded_at?date(f.last_succeeded_at):"—")+'</td><td>'+h(f.last_attempted_at?date(f.last_attempted_at):"—")+
    '</td><td>'+(f.ttl_hours==null?"人工":f.ttl_hours+"h")+'</td><td>'+h(f.last_error||"")+'</td></tr>').join("");
  show('<div class="dialog-content stack"><h2>'+h(a.display_name)+' '+freshBadge(a.freshness?.overall_status)+'</h2><p>'+link(a.url)+'</p>'+
    '<div class="actions"><button class="primary" id="refresh-one">按需刷新公开数据</button>'+
    '<a class="btn" href="#batch-import" id="refresh-manual-link">批量导入更新</a><span class="hint" id="refresh-one-status"></span></div>'+
    (state.meta.demo?'':'<form class="actions" id="bd-form"><label>BD <input name="bd" maxlength="120" value="'+h(a.bd||"")+'" placeholder="自由填写 BD 负责人（留空不分配）"></label><button type="submit">保存 BD</button></form>')+
    '<div class="kv">'+rows.map(([k,v])=>'<div><small>'+k+'</small><b>'+h(v||"—")+'</b></div>').join("")+'</div>'+
    (fRows?'<details open><summary>字段级时效与来源</summary><div class="table-scroll"><table><thead><tr><th>字段</th><th>状态</th><th>来源</th><th>最近成功</th><th>最近尝试</th><th>有效期</th><th>说明</th></tr></thead><tbody>'+fRows+'</tbody></table></div></details>':'')+
    (c?.email?'<p class="callout">'+h(c.email)+' · '+link(c.url)+' · '+h(date(c.updated_at))+'</p>':'')+
    (a.raw.bio?'<details><summary>原始简介</summary><p class="bio">'+h(a.raw.bio)+'</p></details>':'')+
    (a.raw.content?.length?'<details><summary>近期内容</summary>'+evidence(a.raw.content)+'</details>':'')+
    (a.raw.audience?'<p>粉丝画像 · '+h(a.raw.audience)+' · '+link(a.raw.audience_url)+'</p>':'')+
    (a.raw.collaboration?'<p>合作记录 · '+h(a.raw.collaboration)+'</p>':'')+
    '<h3>标签与证据</h3>'+(tags?'<ul class="tag-list">'+tags+'</ul>':'<p class="muted">暂无标签。</p>')+
    (p?'':'<details><summary>填写或修改人工标签</summary><form class="form-grid line" id="tag-form">'+
    '<label>维度<select name="dimension">'+options(state.meta.dimensions.map(t=>[t,t]))+'</select></label>'+
    '<label>层级<select name="tier"><option value="secondary">次要</option><option value="core">核心</option></select></label>'+
    '<label>标签<input name="label" maxlength="60" required></label><label>依据链接<input type="url" name="url" required value="'+h(a.url)+'"></label>'+
    '<label class="span-all">判断依据<input name="basis" maxlength="500" required></label><div class="actions"><button type="submit">保存标签</button></div></form></details>')+
    (a.source==="independent"&&!p&&state.meta.model.startsWith("MiniMax/")?'<div><button id="analyze">用 MiniMax 分析</button></div>':'')+
    '<h3>历史项目</h3><div class="actions">'+(history||'<span class="muted">暂无项目记录</span>')+'</div></div>');
  on(modalBody,"#bd-form",async e=>{
    const val=new FormData(e.target).get("bd");
    await api("/accounts/"+id+"/bd","PUT",{bd:val});
    await showAccount(id);await refreshAccounts();toast("BD 已保存");
  },"submit");
  on(modalBody,"#tag-form",async e=>{
    await api("/accounts/"+id+"/tags","PUT",Object.fromEntries(new FormData(e.target)));
    await showAccount(id);await refreshAccounts();toast("已保存人工标签");
  },"submit");
  on(modalBody,"[data-remove]",async(e,b)=>{
    if(!window.confirm("删除此标签？"))return;
    await api("/accounts/"+id+"/tags?"+new URLSearchParams({dimension:b.dataset.dimension,label:b.dataset.remove,model_name:b.dataset.model}),"DELETE");
    await showAccount(id);await refreshAccounts();toast("已删除标签");
  });
  on(modalBody,"#analyze",async()=>{
    await api("/accounts/"+id+"/analyze","POST");await showAccount(id);await refreshAccounts();toast("MiniMax 分析完成");
  });
  on(modalBody,"#refresh-one",async()=>{
    const st=$("#refresh-one-status");
    st.textContent="正在发起刷新…";
    const job=await api("/refresh/jobs","POST",{account_ids:[Number(id)],mode:state.meta.demo?"mock":"public_feed",force:true,budget_limit:1});
    for(let i=0;i<40;i++){
      const cur=await api("/refresh/jobs/"+job.job_id);
      if(["done","cancelled","failed"].includes(cur.status)){
        const item=cur.items[0];
        if(item&&item.status==="failed"){toast("刷新失败，已保留原有效数据："+item.error,true);}
        else{toast("刷新完成");}
        await showAccount(id);
        if(state.view==="library")await refreshAccounts();
        if(state.view==="projects"&&state.project)await refreshProject();
        return;
      }
      await new Promise(r=>setTimeout(r,250));
    }
  });
  on(modalBody,"#refresh-manual-link",()=>modal.close());
  for(const a of $$("[data-history]",modalBody))a.addEventListener("click",()=>modal.close());
}
function reason(b){
  return [...(b.topics||[]).map(t=>t.label+" · "+(t.tier==="core"?"核心":"次要")),...(b.preferences||[]),
    ...(b.unknown||[]).map(k=>"待核实 "+(labels[k]||k)),...(b.failed||[]).map(k=>"不符合 "+(labels[k]||k))].join(" · ")||"符合可核实的筛选条件";
}
async function projectsPage(){
  const route=location.hash,list=await api("/projects");
  if(state.view!=="projects"||route!==location.hash)return;
  if(!list.some(p=>p.id===state.project))state.project=list[0]?.id||0;
  main.innerHTML=hero("品牌项目","在项目内审核候选、记录提报进度，导出可粘贴到飞书的表格。",'<button class="primary" id="new-project">新建项目</button>')+
    '<div class="stack">'+(list.length?'<div class="project-grid">'+list.map(p=>'<a class="btn project-choice" aria-pressed="'+
      (p.id===state.project)+'" href="#projects/'+p.id+'"><b>'+h(p.name)+'</b><span class="project-metrics">'+
      p.total+' 位候选 · '+p.accepted+' 位通过</span></a>').join("")+'</div>':'<div class="card empty">暂无项目，可先保存品牌需求。</div>')+
    '<div id="project-detail" class="stack"></div></div>';
  on(main,"#new-project",()=>projectForm());
  if(state.project)await refreshProject();
}
async function projectForm(p){
  show('<form id="project-form" class="stack"><h2>'+(p?"编辑项目":"新建项目")+'</h2>'+
    '<label>项目名称<input name="name" maxlength="100" required value="'+h(p?.name)+'"></label>'+
    '<label>品牌画像<textarea name="brief" maxlength="3000" required>'+h(p?.brief)+'</textarea></label>'+
    '<small>修改品牌画像会重新解析筛选条件，保留已有的人工审核状态。</small>'+
    '<div class="actions"><button type="submit" class="primary">保存项目</button></div></form>');
  on(modalBody,"#project-form",async e=>{
    const payload=Object.fromEntries(new FormData(e.target));
    if(p&&payload.brief.trim()===p.brief)payload.criteria=p.criteria;
    const saved=await api("/projects"+(p?"/"+p.id:""),p?"PUT":"POST",payload);
    modal.close();
    const hash="#projects/"+saved.id;
    if(location.hash===hash)await projectsPage();else location.hash=hash;
    toast("项目已保存");
  },"submit");
}
function searchAgain(p){
  if(p.criteria.pending?.length){
    state.draft={...state.draft,name:p.name,brief:p.brief,parsed:null,discover:false};
    location.hash="#search";
    return;
  }
  const last=p.tasks[0]?.options;
  show('<form class="stack" id="again-form"><h2>补充项目候选</h2><p class="muted">使用此项目已保存的筛选条件。</p>'+
    '<div class="options">'+platformOptions(last?.platforms||["YouTube"])+'</div>'+
    '<label>候选数量<input name="limit" type="number" min="1" max="50" value="'+(last?.limit||30)+'" required></label>'+
    '<label class="option"><input name="discover" type="checkbox" '+ch(last?.discover)+'> 补充 YouTube 新达人</label>'+
    '<label>搜索关键词<textarea name="keywords" rows="3">'+h((last?.keywords?.length?last.keywords:p.criteria.keywords).slice(0,4).join("\n"))+
    '</textarea></label><div class="actions"><button class="primary" type="submit">启动搜索</button></div></form>');
  on(modalBody,"#again-form",async e=>{
    const f=new FormData(e.target), platforms=f.getAll("platform");
    if(!platforms.length)throw Error("至少选择一个目标平台");
    await api("/tasks","POST",{project:p.id,platforms,limit:Number(f.get("limit")),discover:f.has("discover"),
      keywords:f.get("keywords").split("\n").map(k=>k.trim()).filter(Boolean).slice(0,4)});
    modal.close();await refreshProject();toast("已启动搜索");
  },"submit");
}
function reviewMatch(p,id){
  const match=p.matches.find(m=>m.account.id===Number(id));
  show('<form id="review-form" class="stack"><h2>审核 · '+h(match.account.display_name)+'</h2><p class="callout">'+h(reason(match.basis))+
    '</p><label>提报状态<select name="status">'+options(Object.entries(review),match.status)+'</select></label>'+
    '<label>审核备注<textarea name="note" maxlength="1000">'+h(match.note.replace(/^【证据已人工核验】/,""))+'</textarea></label>'+
    (p.criteria.pending?.length?'<label><input type="checkbox" name="evidence_verified"> 已核对作品证据及全部待核验条件（通过时必选）</label>':"")+
    '<div class="actions"><button class="primary" type="submit">保存审核</button></div></form>');
  on(modalBody,"#review-form",async e=>{
    const data=new FormData(e.target);
    await api("/projects/"+p.id+"/matches/"+id,"PATCH",{
      status:data.get("status"),note:data.get("note"),evidence_verified:data.has("evidence_verified")});
    modal.close();await projectsPage();toast("审核已保存");
  },"submit");
}
async function previewExport(project,fmt){
  const approved=$("#approved").checked;
  const data=await api("/projects/"+project+"/export?"+new URLSearchParams({fmt,approved,preview:true}));
  show('<div class="stack"><h2>飞书提报预览</h2><p>共 '+n(data.count)+' 条'+(approved?" · 仅审核通过或已提报":" · 包含未通过项")+'</p>'+
    '<ul>'+data.columns.map((col,i)=>'<li>'+h(col)+' · '+n(data.missing[i])+' 条缺失</li>').join("")+'</ul>'+
    '<small>表格使用固定列顺序。逐视频统计及原始证据请在原工作簿核验。</small>'+
    (data.count?'<button id="confirm-export" class="primary">确认输出</button>':'<p>没有符合导出条件的记录。</p>')+'</div>');
  on(modalBody,"#confirm-export",async()=>{modal.close();await exportFile(project,fmt,approved);});
}
async function exportFile(project,fmt,approved){
  const response=await fetch("/api/projects/"+project+"/export?"+new URLSearchParams({fmt,approved}));
  if(!response.ok)throw Error("提报表导出失败");
  if(response.headers.get("X-CreatorHub-Rows")==="0"){toast("当前没有符合导出条件的记录");return;}
  if(fmt==="tsv"){
    const text=await response.text();
    try{await navigator.clipboard.writeText(text);toast("已复制，可粘贴到飞书");}
    catch{show('<div class="stack"><h2>复制提报表格</h2><textarea id="copy-fallback" readonly rows="10">'+h(text)+'</textarea></div>');$("#copy-fallback").select();}
    return;
  }
  const url=URL.createObjectURL(await response.blob()), a=document.createElement("a");
  a.href=url;a.download=(state.meta.demo?"demo-":"")+"creatorhub-project-"+project+"."+fmt;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1500);toast("提报文件已生成");
}
function usedSummary(b){
  const u=b.used_values;
  if(!u)return "";
  return "依据数据：粉丝 "+n(u.followers)+" · 均播 "+n(u.views)+" · "+(u.country||"—")+" · "+(freshLabels[u.freshness_status]||"");
}
async function refreshProject(poll=false){
  const root=$("#project-detail"),id=state.project;
  if(!root||!id)return;
  const p=await api("/projects/"+id);
  if(root!==$("#project-detail")||id!==state.project)return;
  const version=JSON.stringify(p);
  if(poll&&(version===root.dataset.version||root.contains(document.activeElement)))return;
  const approve=$("#approved")?.checked??true;
  root.dataset.version=version;
  const matches=[...p.matches].sort((a,b)=>reviewOrder[a.status]-reviewOrder[b.status]);
  const rows=matches.map(m=>'<tr><td>'+account(m.account)+(m.account.projects.length>1?'<small class="cell-detail">关联 '+m.account.projects.length+' 个项目</small>':'')+
    '</td><td>'+h(m.account.platform)+'</td><td>'+n(m.account.followers)+'</td><td>'+h(mail[m.account.email_state])+'</td><td>'+freshBadge(m.account.freshness?.overall_status)+
    (m.basis.near_threshold?' '+chip("临界复核","warn"):'')+'</td><td>'+h(reason(m.basis))+
    (usedSummary(m.basis)?'<small class="cell-detail">'+h(usedSummary(m.basis))+'</small>':'')+
    (m.note?'<small class="cell-detail">'+h(m.note)+'</small>':'')+'</td><td>'+chip(review[m.status],["accepted","submitted"].includes(m.status)?"good":m.status==="rejected"?"bad":"")+
    '</td><td><button data-review="'+m.account.id+'">审核详情</button>'+(m.status==="pending"&&m.basis.state==="eligible"?' <button data-accept="'+m.account.id+'">通过</button>':"")+'</td></tr>').join("");
  root.innerHTML='<section class="card stack"><div class="project-title"><div><h2>'+h(p.name)+'</h2><p class="subtitle">'+h(p.brief)+
    '</p></div><div class="actions"><button id="prefilter-btn">本地初筛与时效检查</button><button id="refresh-stale-btn" class="primary">按需刷新过期候选</button><button id="manual-refresh-xlsx">导出待人工补全表</button><button id="ttl-project-btn">时效设置</button><button id="edit-project">编辑项目</button><button id="again">补充搜索</button></div></div>'+
    '<div id="project-refresh-status"></div>'+
    '<div class="actions line"><label class="option"><input id="approved" type="checkbox" '+ch(approve||p.criteria.pending?.length)+(p.criteria.pending?.length?' disabled':'')+'> 仅人工审核通过</label>'+
    '<button data-export="xlsx">导出 Excel</button><button data-export="csv">导出 CSV</button><button data-export="tsv">复制表格</button></div>'+
    '<small>导出使用授权录入资料。YouTube 临时缓存支持浏览和审核。</small></section>'+
    table("项目候选 · "+p.matches.length+" 位",["账号","平台","粉丝量","邮箱","数据时效","匹配依据与实际数据","状态","操作"],rows)+
    (p.tasks.length?'<section class="card stack"><h2>搜索记录</h2>'+p.tasks.map((t,i)=>'<details '+(i===0?"open":"")+
      '><summary>#'+t.id+' · '+h(stat[t.status])+' · '+h(date(t.created_at))+'</summary><div class="line" data-task="'+t.id+'">'+taskHtml(t)+'</div></details>').join("")+'</section>':'');
  bindAccounts(root);
  on(root,"#ttl-project-btn",showTtlSettings);
  on(root,"#prefilter-btn",async()=>{
    const res=await api("/projects/"+id+"/prefilter","POST");
    await refreshProject();
    toast("初筛完成：合格 "+res.eligible_count+" 位 · 临界复核 "+res.near_threshold_count+" 位 · 需刷新 "+res.needs_refresh_ids.length+" 位");
  });
  on(root,"#refresh-stale-btn",async()=>{
    const targetIds=matches.filter(m=>m.account.freshness?.needs_refresh).map(m=>m.account.id);
    if(!targetIds.length){toast("当前候选关键字段均为最新");return;}
    const job=await api("/refresh/jobs","POST",{account_ids:targetIds,project_id:id,mode:state.meta.demo?"mock":"public_feed",budget_limit:50});
    const box=$("#project-refresh-status");
    const renderJob=async()=>{
      const cur=await api("/refresh/jobs/"+job.job_id);
      box.innerHTML='<p class="callout">按需刷新任务 #'+cur.id+' · 状态 '+h(cur.status)+' · 进度 '+cur.completed+'/'+cur.total+'（成功 '+cur.succeeded+' · 失败 '+cur.failed+' · 跳过最新 '+cur.skipped_fresh+'）'+
        (cur.status==="running"||cur.status==="queued"?' <button id="cancel-refresh" class="danger">取消</button>':cur.failed?' <button id="retry-refresh">重试失败项</button>':'')+'</p>';
      on(box,"#cancel-refresh",async()=>{await api("/refresh/jobs/"+cur.id+"/control","POST",{action:"cancel"});await renderJob();});
      on(box,"#retry-refresh",async()=>{await api("/refresh/jobs/"+cur.id+"/control","POST",{action:"retry"});pollRefresh();});
      return cur;
    };
    const pollRefresh=()=>{
      const timer=setInterval(async()=>{
        if(state.view!=="projects"||state.project!==id){clearInterval(timer);return;}
        const cur=await renderJob();
        if(["done","cancelled","failed"].includes(cur.status)){clearInterval(timer);await refreshProject();toast("按需刷新结束：成功 "+cur.succeeded+"，失败 "+cur.failed);}
      },400);
    };
    const first=await renderJob();
    if(["done","cancelled","failed"].includes(first.status)){await refreshProject();toast("无需外部调用，候选均为最新");}
    else{pollRefresh();}
  });
  on(root,"#manual-refresh-xlsx",async()=>{
    const targetIds=matches.filter(m=>m.account.freshness?.needs_refresh).map(m=>m.account.id);
    const ids=targetIds.length?targetIds:matches.map(m=>m.account.id);
    if(!ids.length){toast("暂无可导出的候选");return;}
    const res=await fetch("/api/refresh/manual-template",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({account_ids:ids})});
    if(!res.ok)throw Error("导出待补全模板失败");
    const url=URL.createObjectURL(await res.blob()),a=document.createElement("a");
    a.href=url;a.download="CreatorHub-Manual-Refresh-V1.3.xlsx";a.click();
    setTimeout(()=>URL.revokeObjectURL(url),1500);
    toast("已导出待人工补全表格，填好后可在「批量导入」直接上传更新");
  });
  on(root,"#edit-project",()=>projectForm(p));
  on(root,"#again",()=>searchAgain(p));
  on(root,"[data-review]",(e,b)=>reviewMatch(p,b.dataset.review));
  on(root,"[data-accept]",async(e,b)=>{
    const match=p.matches.find(m=>String(m.account.id)===b.dataset.accept);
    await api("/projects/"+id+"/matches/"+match.account.id,"PATCH",{status:"accepted",note:match.note});
    await refreshProject();
  });
  on(root,"[data-export]",(e,b)=>previewExport(id,b.dataset.export));
  for(const t of p.tasks)bindTask($('[data-task="'+t.id+'"]',root),t,()=>refreshProject());
}
async function route(){
  if(modal.open)modal.close();
  const [view,id]=location.hash.slice(1).split("/");
  state.view=["discover","intake","batch-import","search","library","projects","settings"].includes(view)?view:(state.meta.demo?"search":"intake");
  if(state.view==="projects"&&Number(id))state.project=Number(id);
  $("#breadcrumb").textContent={discover:"智能发现",intake:"整理达人提报","batch-import":"批量导入","settings":"设置",search:"匹配已有达人",library:"达人总库",projects:"品牌项目"}[state.view];
  for(const el of $$("[data-nav]"))if(el.dataset.nav===state.view)el.setAttribute("aria-current","page");else el.removeAttribute("aria-current");
  if(state.view==="discover")await discoveryPage(main,api,toast);
  else if(state.view==="batch-import")await batchImportPage(main,api,toast);
  else if(state.view==="settings")await updatePage(main,api,toast);
  else if(state.view==="intake")await intakePage(main,api,toast,()=>state.view==="intake",state.meta.structured_model);
  else if(state.view==="search")searchPage();
  else if(state.view==="library")await libraryPage();
  else await projectsPage();
}
async function boot(){
  state.meta=await api("/meta");
  $("#mode").textContent=state.meta.demo?"演示库 · 模拟数据":"业务库 · 本机访问";
  $("#mode").classList.toggle("demo",state.meta.demo);
  $("#rail-mode").textContent=state.meta.demo?"独立演示环境":"本地工作区";
  await route();
  addEventListener("hashchange",()=>route().catch(e=>toast(e.message,true)));
  setInterval(()=>{
    if(document.visibilityState!=="visible"||modal.open)return;
    if(state.view==="search"&&state.task)refreshTask().catch(()=>{});
    if(state.view==="projects"&&state.project)refreshProject(true).catch(()=>{});
  },1500);
}
boot().catch(e=>{main.textContent=e.message;});
