"""Project intake, human review, and Feishu submission."""
import csv
from io import StringIO
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal
from uuid import uuid4

from pydantic import BaseModel, Field

from . import freshness
from .domain import evaluate, identity
from .imports import FIELDS, parse_table
from .permissions import ImportPolicy, governed_profile, prepare_policy
from .store import dump, load, now

HEADERS = ("campagin", "达人昵称", "主页链接", "平台", "Follower", "最近10条阅读",
           "一轮报价", "CPM", "国家", "语种", "重复", "提报人", "提报日期")
MAPPING = dict(zip(HEADERS[1:], ("display_name", "url", "platform", "followers", "views", "quote",
                                None, "country", "language", None, None, None)))

class Settings(BaseModel):
    reading_stat: Literal["average", "median", "unknown"] = "unknown"
    reading_unit: Literal["raw", "K"] = "raw"
    currency: str = Field(pattern=r"^[A-Z]{3}$")
    formula_columns: list[str] = Field(default_factory=list, max_length=13)
    mapping: dict[str, str] = Field(default_factory=dict, max_length=40)

class ProjectMetrics(BaseModel):
    stat: Literal["average", "median"]
    minimum: int | None = Field(default=None, ge=0, le=10**15)


def metric_config(db, project):
    return db.execute("SELECT stat,minimum FROM project_metrics WHERE project=?", (project,)).fetchone()


class Intake(BaseModel):
    text: str = Field(min_length=1, max_length=650000)
    source: Literal["independent", "authorized"]
    policy: ImportPolicy | None = None
    confirmed: bool = False
    links_platform: Literal["YouTube", "Instagram", "TikTok", "X"] | None = None
    settings: Settings
    template: str = Field(default="", max_length=80)

class Output(BaseModel):
    accounts: list[int] = Field(max_length=500)
    formula_columns: list[str] = Field(default_factory=list, max_length=13)
    preliminary: bool = False


class Decision(BaseModel):
    accounts: list[int] = Field(min_length=1, max_length=500)
    action: Literal["accepted", "rejected", "submitted"]
    operator: str = Field(min_length=1, max_length=100)
    submitted_on: date | None = None


def validate_settings(settings):
    if set(settings.formula_columns) - set(HEADERS):
        raise ValueError("公式列须使用飞书提报列名")
    if set(settings.mapping.values()) - set(FIELDS.values()):
        raise ValueError("导入映射含未知字段")


def import_rows(db, store, project, body):
    validate_settings(body.settings)
    if body.settings.reading_unit == "raw" and "views_k" in body.settings.mapping.values():
        raise ValueError("The column mapping conflicts with the selected reading unit")
    settings = body.settings.model_dump()
    mapping = {**MAPPING, **body.settings.mapping}
    if body.settings.reading_unit == "K":
        mapping["最近10条阅读"] = "views_k"
        mapping = {key: "views_k" if value == "views" else value for key, value in mapping.items()}
    if body.links_platform:
        rows = [(i, {"url": line.strip(), "platform": body.links_platform})
                for i, line in enumerate(body.text.splitlines(), 1) if line.strip()]
        if not rows or len(rows) > 500:
            raise ValueError("每批请输入 1 至 500 个主页链接")
    else:
        if not body.confirmed or body.policy is None:
            raise ValueError("请先确认来源授权")
        grant = prepare_policy(body.policy, datetime.now(timezone.utc).date())
        rows = parse_table(body.text, mapping=mapping, limit=500)
    if body.template.strip():
        db.execute("INSERT INTO intake_templates VALUES(?,?) ON CONFLICT(name) DO UPDATE SET settings=excluded.settings",
                   (body.template.strip(), dump(settings)))
    # Existing single-stat import clients can initialize the project once.
    if not body.links_platform and body.settings.reading_stat != "unknown":
        db.execute("INSERT OR IGNORE INTO project_metrics(project,stat) VALUES(?,?)",
                   (project["id"], body.settings.reading_stat))
    batch = uuid4().hex
    result = {"added": 0, "duplicates": 0, "rejected": []}
    for line, row in rows:
        db.execute("SAVEPOINT intake_row")
        try:
            if body.links_platform:
                identifier, url = identity(row["platform"], "", row["url"])
                hit = db.execute("SELECT id FROM accounts WHERE workspace_id=1 AND platform=? "
                                 "AND (url=? OR account_id=? OR id IN "
                                 "(SELECT account FROM account_aliases WHERE workspace_id=1 AND platform=? AND alias=?))",
                                 (row["platform"], url, identifier, row["platform"], identifier)).fetchone()
                if not hit:
                    raise ValueError("获准库中无此主页，请导入有授权的资料")
                account_id = hit["id"]
            else:
                if row.get("views") and not row["views"].replace(",", "").isdigit():
                    raise ValueError("Raw reading must be an integer without a K suffix")
                if row.get("quote") and row["quote"].strip().replace(".", "", 1).isdigit():
                    row["quote"] = body.settings.currency + " " + row["quote"]
                profile = governed_profile(row, body.source, grant, f"{batch}:{line}")
                account_id, _ = store.save_account(db, profile)
            account = store.account(db, account_id, "view")
            if not account or account["source"] not in ("authorized", "independent", "fixture"):
                raise ValueError("资料不允许用于项目整理")
            basis = evaluate(store.account(db, account_id, "view+match") or {}, project["criteria"])
            row_settings = {**settings, "reading_stat": "unknown", "verified_views": None}
            if not body.links_platform:
                current_grant = account["raw"].get("provenance", {}).get("fields", {}).get("views", {})
                if current_grant.get("original_record_id") == f"{batch}:{line}":
                    row_settings.update(reading_stat=settings["reading_stat"], verified_views=account["views"])
            changed = db.execute("INSERT OR IGNORE INTO project_intake(project,account,settings) VALUES(?,?,?)",
                                 (project["id"], account_id, dump(row_settings))).rowcount
            if not changed and row_settings["verified_views"] is not None:
                db.execute("UPDATE project_intake SET settings=? WHERE project=? AND account=?",
                           (dump(row_settings), project["id"], account_id))
            db.execute("INSERT INTO matches(project,account,basis) VALUES(?,?,?) "
                       "ON CONFLICT(project,account) DO UPDATE SET basis=excluded.basis",
                       (project["id"], account_id, dump(basis)))
            result["added" if changed else "duplicates"] += 1
        except (ValueError, OverflowError) as exc:
            db.execute("ROLLBACK TO intake_row")
            result["rejected"].append({"line": line, "reason": str(exc)})
        finally:
            db.execute("RELEASE intake_row")
    return result


def information(store, db, project, record, purpose):
    account = store.account(db, record["account"], purpose)
    if not account or account["source"] not in ("authorized", "independent", "fixture"):
        return None
    settings = load(record["settings"])
    raw = account["raw"]
    quote = raw.get("quote")
    configured = metric_config(db, project["id"])
    stat = configured["stat"] if configured else "unknown"
    minimum = configured["minimum"] if configured else None

    def metric_value(profile):
        if not profile or stat == "unknown":
            return None
        metric = profile["raw"].get(f"recent_{stat}")
        if metric is not None:
            return metric["value"]
        actual = profile["views"]
        if stat == settings.get("reading_stat", "unknown") and actual == settings.get("verified_views"):
            return actual
        return None

    views = metric_value(account)
    missing = []
    name = account["display_name"] if account["display_name"] != account["account_id"] else None
    for value, label in ((name, "达人昵称"), (account["followers"], "Follower"),
                         (account["country"], "国家"), (account["language"], "语种")):
        if value is None:
            missing.append(label)
    if not quote:
        missing.append("一轮报价")
    elif quote["currency"] != settings.get("currency", "USD") or quote["max"] is not None:
        missing.append("报价币种或区间待确认")
    if not views or stat == "unknown":
        missing.append("最近10条阅读或统计口径待确认")
    cpm = None
    if quote and quote["currency"] == settings.get("currency", "USD") and quote["max"] is None and views and stat != "unknown":
        cpm = str((Decimal(str(quote["min"])) * 1000 / Decimal(str(views))).quantize(Decimal(".01"), rounding=ROUND_HALF_UP))
    matchable = store.account(db, record["account"], "view+match")
    basis = evaluate(matchable, project["criteria"]) if matchable else {"unknown": ["匹配用途未授权"], "failed": []}
    if minimum is not None:
        eligible_views = metric_value(matchable)
        if eligible_views is None:
            missing.append("项目播放量筛选证据")
        elif eligible_views < minimum:
            basis["failed"].append("项目播放量低于门槛")
    missing.extend(basis["unknown"])
    if not any(entry.get("url") != account["url"] for entry in raw.get("content", [])):
        missing.append("作品来源证据")
    history = [item for item in account["projects"] if item["id"] != project["id"]]
    for entry in history:
        entry["events"] = [dict(event) for event in db.execute(
            "SELECT status,recorded_at FROM review_history WHERE project=? AND account=? ORDER BY id",
            (entry["id"], record["account"]))]

    price = "" if not quote else f"{quote['currency']} {quote['min']:g}"
    if quote and quote["max"] is not None:
        price += f"–{quote['max']:g}"
    values = [project["name"], name, account["url"], account["platform"], account["followers"],
              views, price, cpm, account["country"], account["language"],
              "历史复用" if history else "", record["operator"], record["submitted_on"]]
    grants = raw.get("provenance", {}).get("fields", {})
    metrics = {kind: {**raw[key], "source": grants[key]["source_name"],
                      "updated_at": account["updated_at"]}
               for kind in ("average", "median")
               if (key := f"recent_{kind}") in raw and key in grants}
    checked = {"values": values[:10], "basis": basis, "reading_stat": stat, "content": raw.get("content", [])}
    f_state = freshness.compute_freshness(db, account)
    return {"account": record["account"], "values": values, "basis": basis, "missing": missing,
            "suggestion": "pass" if basis["failed"] else "hold" if missing else "submit",
            "status": record["status"], "history": history,
            "collaboration": raw.get("collaboration"), "content": raw.get("content", []),
            "formula_columns": settings.get("formula_columns", []), "checked": checked,
            "reading_stat": stat, "estimated_quote": raw.get("estimated_quote"),
            "metrics": metrics,
            "freshness": f_state,
            "used_values": freshness.match_snapshot(account, f_state),
            "current_confirmation": bool(record["reviewed"] and load(record["reviewed"]) == checked)}


def records(db, project):
    return db.execute("SELECT i.*,m.status FROM project_intake i JOIN matches m "
                      "ON m.project=i.project AND m.account=i.account WHERE i.project=? ORDER BY i.account",
                      (project,)).fetchall()


def decide(store, db, project, decision):
    operator = decision.operator.strip()
    if not operator or (decision.action == "submitted" and not decision.submitted_on):
        raise ValueError("请填写提报人及记录级提报日期")
    wanted = set(decision.accounts)
    updated, rejected = 0, []
    for record in records(db, project["id"]):
        account = record["account"]
        if account not in wanted:
            continue
        wanted.remove(account)
        item = information(store, db, project, record, "view+export")
        if decision.action != "rejected" and (not item or item["suggestion"] != "submit" or
                (decision.action == "submitted" and not item["current_confirmation"])):
            rejected.append(account)
            continue
        reviewed = dump(item["checked"]) if decision.action != "rejected" else None
        submitted = decision.submitted_on.isoformat() if decision.action == "submitted" else None
        db.execute("UPDATE project_intake SET reviewed=?,operator=?,submitted_on=? WHERE project=? AND account=?",
                   (reviewed, operator, submitted, project["id"], account))
        db.execute("UPDATE matches SET status=?,submission_date=? WHERE project=? AND account=?",
                   (decision.action, submitted, project["id"], account))
        db.execute("INSERT INTO review_history(project,account,status,note,recorded_at) VALUES(?,?,?,?,?)",
                   (project["id"], account, decision.action, "", now()))
        updated += 1
    return {"updated": updated, "blocked": rejected + sorted(wanted)}



def output(rows, formulas, safe_cell, preliminary):
    if formulas - set(HEADERS):
        raise ValueError("公式列须使用飞书提报列名")
    blocks = []
    start = 0
    for end in range(len(HEADERS) + 1):
        if end < len(HEADERS) and HEADERS[end] not in formulas:
            continue
        if start < end:
            stream = StringIO()
            writer = csv.writer(stream, delimiter="\t", lineterminator="\r\n")
            for row in rows:
                writer.writerow([safe_cell(str(cell).replace("\r", " ").replace("\n", " ").replace("\t", " "))
                                 if cell is not None else "" for cell in row[start:end]])
            blocks.append({"start_column": start + 1, "columns": HEADERS[start:end], "tsv": stream.getvalue()})
        start = end + 1
    return {"columns": HEADERS, "rows": rows, "count": len(rows), "blocks": blocks, "preliminary": preliminary,
            "missing": [sum(row[i] in (None, "") for row in rows) for i in range(len(HEADERS))]}
