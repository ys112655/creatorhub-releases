"""Native discovery helpers: keyword suggestions, pasted candidates, staging.

No network code lives here. The operator performs the platform search in a
normal browser, then pastes what they verified; this module normalises it,
keeps every field separate, and stores a staging record with provenance.
"""
from __future__ import annotations

import csv
import io
import json
import re
from datetime import date
from decimal import Decimal
from urllib.parse import urlsplit

from .domain import PLATFORMS
from .imports import identity

VERTICAL_RULES = (
    ("ComfyUI", ("comfyui", "comfy"), ("ComfyUI workflow", "ComfyUI video generation")),
    ("AI Video", ("ai video", "ai视频", "视频生成", "video generation", "text-to-video"),
     ("AI video generation tutorial", "AI video workflow")),
    ("AI VFX", ("vfx", "特效"), ("AI VFX workflow", "AI VFX breakdown")),
    ("AI Filmmaking", ("filmmaking", "ai film", "ai电影", "电影"), ("AI filmmaking", "AI short film workflow")),
    ("Wan", ("wan",), ("Wan video workflow",)),
    ("LTX", ("ltx",), ("LTX Video workflow",)),
    ("Image", ("image", "图像", "设计", "flux", "midjourney"), ("AI image workflow",)),
)

PLATFORM_HOSTS = {
    "YouTube": ("youtube.com", "youtu.be"),
    "Instagram": ("instagram.com",),
    "TikTok": ("tiktok.com",),
    "X": ("x.com", "twitter.com"),
}

CSV_FIELDS = ("platform,account_id,url,display_name,followers,country,language,recent_samples,"
              "recent_average,recent_count,recent_scope,estimated_quote,quote,content_titles,content_urls")

MISSING_LABELS = {"followers": "订阅数", "language": "内容语言", "creator_location": "创作者所在地",
                  "audience_region": "受众地区", "evidence_url": "代表作品", "vertical": "垂直度"}

HEADER_ALIASES = {
    "platform": ("平台", "platform"),
    "account": ("账号", "account", "handle"),
    "name": ("昵称", "名称", "达人", "name", "display"),
    "url": ("主页", "链接", "url", "profile"),
    "followers": ("粉丝", "订阅", "followers", "subs"),
    "language": ("语言", "language", "lang"),
    "location": ("所在地", "国家", "location", "country"),
    "audience": ("受众", "audience"),
    "evidence_url": ("作品链接", "作品", "evidence"),
    "evidence_title": ("作品标题", "标题", "title"),
    "vertical": ("垂直", "vertical"),
}


def parse_count(value):
    """Parse 1.15K / 5.95K / 1.2M / 1,234 / 0. Unknown stays None; junk raises."""
    if value is None:
        return None
    text = str(value).strip().replace(",", "").replace("，", "")
    if not text or text in ("未知", "-", "—", "N/A", "n/a", "null"):
        return None
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([kKmM万]?)", text)
    if not match:
        raise ValueError(f"无法识别的数量：{value}")
    number = Decimal(match.group(1))
    unit = match.group(2).lower()
    if unit == "k":
        number *= 1_000
    elif unit == "m":
        number *= 1_000_000
    elif unit == "万":
        number *= 10_000
    if number < 0:
        raise ValueError(f"数量不能为负：{value}")
    if number != number.to_integral_value():
        raise ValueError(f"数量不是整数：{value}")
    return int(number)


def platform_of(url: str):
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    if parts.scheme != "https":
        return None
    host = (parts.hostname or "").lower()
    for name, suffixes in PLATFORM_HOSTS.items():
        if any(host == s or host.endswith("." + s) for s in suffixes):
            return name
    return None


def is_profile_url(platform: str, url: str) -> bool:
    parts = urlsplit(url)
    path = (parts.path or "/").strip("/")
    if not path:
        return False
    first = path.split("/")[0]
    if platform == "YouTube":
        return first.startswith("@") or first in ("c", "channel", "user")
    if platform == "Instagram":
        return first not in ("p", "reel", "reels", "tv", "explore", "accounts", "stories")
    if platform == "TikTok":
        return first.startswith("@")
    if platform == "X":
        return first not in ("i", "home", "search", "hashtag", "intent", "compose")
    return False


def suggest_keywords(brief: str, platforms=None):
    text = (brief or "").casefold()
    matched, keywords = [], []
    for label, needles, terms in VERTICAL_RULES:
        if any(n in text for n in needles):
            matched.append(label)
            for term in terms:
                keywords.append({"term": term, "vertical": label})
    understood = bool(keywords)
    chosen = [p for p in (platforms or []) if p in PLATFORMS] or ["YouTube"]
    links = [{"platform": p, "term": k["term"], "vertical": k["vertical"], "url": search_url(p, k["term"])}
             for k in keywords for p in chosen]
    notes = []
    if not understood:
        notes.append("没有识别出明确的行业或技术词，请补充需求，或在下方手动添加关键词。")
    if "英语" in text or "english" in text:
        notes.append("需求提到英语内容：导入时语言默认 en，仍需人工确认。")
    if any(t in text for t in ("欧美", "欧洲", "美国", "europe")):
        notes.append("需求提到欧美市场：受众地区不会自动推断，需人工标注。")
    return {"understood": understood, "verticals": matched, "keywords": links,
            "platforms": chosen, "notes": notes, "recorded_at": date.today().isoformat()}


def search_url(platform: str, term: str) -> str:
    from urllib.parse import quote_plus
    q = quote_plus(term)
    return {"YouTube": f"https://www.youtube.com/results?search_query={q}",
            "Instagram": f"https://www.instagram.com/explore/tags/{quote_plus(term.replace(' ', ''))}/",
            "TikTok": f"https://www.tiktok.com/search?q={q}",
            "X": f"https://x.com/search?q={q}&f=live"}[platform]


def _header_map(cells):
    mapping = {}
    for index, cell in enumerate(cells):
        text = (cell or "").strip().casefold()
        if not text:
            continue
        for field, aliases in HEADER_ALIASES.items():
            if field not in mapping and any(text == alias or text.startswith(alias) or text.endswith(alias) for alias in aliases):
                mapping[field] = index
                break
    return mapping if ("url" in mapping or "account" in mapping) else {}


def _rows_from_table(text):
    lines = [line for line in text.splitlines() if line.strip()]
    if len(lines) < 2:
        return None
    mapping = _header_map(lines[0].split("\t"))
    if not mapping:
        return None
    rows = []
    for line in lines[1:]:
        cells = line.split("\t")
        rows.append({field: (cells[i].strip() if i < len(cells) else "") for field, i in mapping.items()})
    return rows


def _rows_from_pipe(text):
    rows = []
    for line in text.splitlines():
        if not line.strip() or line.strip().startswith("#"):
            continue
        parts = [p.strip() for p in (line.split("|") if "|" in line else line.split("\t"))]
        rows.append({"url": parts[0],
                     "name": parts[1] if len(parts) > 1 else "",
                     "platform": parts[2] if len(parts) > 2 else "",
                     "followers": parts[3] if len(parts) > 3 else "",
                     "language": parts[4] if len(parts) > 4 else "",
                     "location": parts[5] if len(parts) > 5 else "",
                     "audience": parts[6] if len(parts) > 6 else "",
                     "evidence_url": parts[7] if len(parts) > 7 else "",
                     "evidence_title": parts[8] if len(parts) > 8 else "",
                     "vertical": parts[9] if len(parts) > 9 else ""})
    return rows


def parse_candidates(text: str, known=None):
    known = known or {}
    rows = _rows_from_table(text) or _rows_from_pipe(text)
    candidates, duplicates, invalid, existing = [], [], [], []
    seen, existing_seen = set(), set()
    today = date.today().isoformat()
    for row in rows:
        url = (row.get("url") or "").strip()
        platform = (row.get("platform") or "").strip() or platform_of(url) or ""
        if platform not in PLATFORMS or not url.startswith("https://"):
            invalid.append({"input": url or json.dumps(row, ensure_ascii=False)[:80],
                            "reason": "仅接受 https 平台主页链接"})
            continue
        if platform_of(url) != platform:
            invalid.append({"input": url, "reason": "链接域名与所选平台不一致"})
            continue
        if not is_profile_url(platform, url):
            invalid.append({"input": url, "reason": "这是作品或帖子链接，不是达人主页"})
            continue
        try:
            identifier, normalised = identity(platform, row.get("account") or "", url)
            followers = parse_count(row.get("followers"))
        except ValueError as error:
            invalid.append({"input": url, "reason": str(error)})
            continue
        key = (platform, identifier.casefold())
        if key in seen:
            duplicates.append({"url": normalised, "reason": "输入内重复"})
            continue
        if key in known:
            account = known[key]
            if account not in existing_seen:
                existing_seen.add(account)
                existing.append({"account": account, "platform": platform, "url": normalised,
                                 "display_name": row.get("name") or identifier})
            continue
        seen.add(key)
        candidate = {
            "platform": platform, "account_id": identifier, "url": normalised,
            "display_name": (row.get("name") or "").strip() or identifier,
            "followers": followers,
            "language": (row.get("language") or "").strip() or None,
            "creator_location": (row.get("location") or "").strip() or None,
            "audience_region": (row.get("audience") or "").strip() or None,
            "evidence_url": (row.get("evidence_url") or "").strip() or None,
            "evidence_title": (row.get("evidence_title") or "").strip() or None,
            "vertical": (row.get("vertical") or "").strip() or None,
            "status": "pending", "discovered_at": today, "source": "operator_paste",
            "confirmed": False,
        }
        missing = [f for f in ("followers", "language", "creator_location", "audience_region",
                               "evidence_url", "vertical") if is_missing(candidate[f])]
        candidate["missing"] = missing
        candidate["missing_labels"] = [MISSING_LABELS[m] for m in missing]
        candidates.append(candidate)
    return {"candidates": candidates, "existing": existing, "duplicates": duplicates,
            "invalid": invalid,
            "counts": {"parsed": len(candidates), "existing": len(existing),
                       "duplicates": len(duplicates), "invalid": len(invalid)}}


def is_missing(value):
    """0 is a real count, not a missing value."""
    return value is None or (isinstance(value, str) and not value.strip())


def country_code(value):
    text = (value or "").strip().upper()
    return text if len(text) == 2 and text.isalpha() and text.isascii() else ""


def language_code(value):
    text = (value or "").strip().lower()
    return text if 2 <= len(text) <= 5 and text.isalpha() and text.isascii() else ""


def build_csv(candidates):
    """Only the creator's own location becomes a country; audience never does."""
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(CSV_FIELDS.split(","))
    for item in candidates:
        writer.writerow([
            item["platform"], item["account_id"], item["url"], item["display_name"],
            item.get("followers") if item.get("followers") is not None else "",
            country_code(item.get("creator_location")), language_code(item.get("language")),
            "", "", "", "", "", "",
            item.get("evidence_title") or "", item.get("evidence_url") or "",
        ])
    return buffer.getvalue()


SCHEMA = """
CREATE TABLE IF NOT EXISTS discovery_candidates (
    id INTEGER PRIMARY KEY, project INTEGER NOT NULL, account INTEGER,
    platform TEXT NOT NULL, account_id TEXT NOT NULL, url TEXT NOT NULL,
    display_name TEXT, followers INTEGER, language TEXT,
    creator_location TEXT, audience_region TEXT,
    evidence_url TEXT, evidence_title TEXT, vertical TEXT,
    status TEXT NOT NULL, source TEXT NOT NULL, discovered_at TEXT NOT NULL,
    confirmed INTEGER NOT NULL, saved_at TEXT NOT NULL,
    UNIQUE(project, platform, account_id)
);
"""


def ensure_schema(db):
    db.executescript(SCHEMA)


def save_candidates(db, project, candidates, account_ids=None):
    ensure_schema(db)
    account_ids = account_ids or {}
    for item in candidates:
        account = account_ids.get((item["platform"], item["account_id"].casefold()))
        db.execute(
            "INSERT INTO discovery_candidates (project, account, platform, account_id, url, display_name, "
            "followers, language, creator_location, audience_region, evidence_url, evidence_title, vertical, "
            "status, source, discovered_at, confirmed, saved_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(project, platform, account_id) DO UPDATE SET "
            "vertical=excluded.vertical, evidence_url=excluded.evidence_url, "
            "evidence_title=excluded.evidence_title, audience_region=excluded.audience_region, "
            "creator_location=excluded.creator_location, followers=excluded.followers, "
            "confirmed=excluded.confirmed, saved_at=excluded.saved_at, account=excluded.account",
            (project, account, item["platform"], item["account_id"], item["url"], item["display_name"],
             item.get("followers"), item.get("language"), item.get("creator_location"),
             item.get("audience_region"), item.get("evidence_url"), item.get("evidence_title"),
             item.get("vertical"), item.get("status") or "pending", item.get("source") or "operator_paste",
             item.get("discovered_at") or date.today().isoformat(), 1 if item.get("confirmed") else 0,
             date.today().isoformat()))
    return len(candidates)

def purge(db, today=None):
    """Keep staging in step with the library: drop orphans and expired copies."""
    ensure_schema(db)
    today = today or date.today().isoformat()
    removed = 0
    removed += db.execute("DELETE FROM discovery_candidates WHERE account IS NOT NULL "
                          "AND account NOT IN (SELECT id FROM accounts)").rowcount
    removed += db.execute("DELETE FROM discovery_candidates WHERE project NOT IN "
                          "(SELECT id FROM projects)").rowcount
    removed += db.execute("DELETE FROM discovery_candidates WHERE account IN "
                          "(SELECT id FROM accounts WHERE expires_at IS NOT NULL AND expires_at <= ?)",
                          (today,)).rowcount
    removed += db.execute(
        "DELETE FROM discovery_candidates WHERE account IN (SELECT a.id FROM accounts a, "
        "json_each(a.raw,'$.provenance.fields') f WHERE json_extract(f.value,'$.expires_on') <= ?)",
        (today,)).rowcount
    # Unlinked rows are only staging leftovers; keep them a week for troubleshooting.
    removed += db.execute("DELETE FROM discovery_candidates WHERE account IS NULL "
                          "AND saved_at < date(?, '-7 day')", (today,)).rowcount
    return removed


def list_candidates(db, project):
    ensure_schema(db)
    rows = db.execute(
        "SELECT d.platform, d.account_id, d.url, d.display_name, d.followers, d.language, "
        "d.creator_location, d.audience_region, d.evidence_url, d.evidence_title, d.vertical, "
        "COALESCE(m.status, d.status) AS status, d.source, d.discovered_at, d.confirmed "
        "FROM discovery_candidates d "
        "LEFT JOIN matches m ON m.project=d.project AND m.account=d.account "
        "WHERE d.project=? ORDER BY d.id", (project,)).fetchall()
    keys = ("platform", "account_id", "url", "display_name", "followers", "language",
            "creator_location", "audience_region", "evidence_url", "evidence_title", "vertical",
            "status", "source", "discovered_at", "confirmed")
    return [dict(zip(keys, row)) for row in rows]

