"""Field-level data freshness tracking, TTL settings, and non-clobbering state updates."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

DEFAULT_TTLS: dict[str, int | None] = {
    "followers": 24,
    "views": 24,
    "recent_average": 24,
    "recent_median": 24,
    "bio": 168,
    "content": 168,
    "tags": 168,
    "country": 720,
    "email": 720,
    "quote": None,
    "collaboration": None,
}

TRACKED_FIELDS = tuple(DEFAULT_TTLS.keys())
MANUAL_FIELDS = frozenset({"quote", "collaboration"})
FIELD_LABELS = {
    "followers": "粉丝量",
    "views": "近期均播",
    "recent_average": "近10条均播",
    "recent_median": "近10条中位播放",
    "bio": "简介",
    "content": "近期内容",
    "tags": "内容分析标签",
    "country": "所在地/国家",
    "email": "商务邮箱",
    "quote": "商务报价(人工)",
    "collaboration": "合作记录(人工)",
}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def ensure_default_settings(db) -> None:
    timestamp = utc_now_iso()
    db.executemany(
        "INSERT OR IGNORE INTO freshness_settings(field, ttl_hours, updated_at) VALUES(?,?,?)",
        [(field, ttl, timestamp) for field, ttl in DEFAULT_TTLS.items()],
    )


def get_ttl_settings(db) -> dict[str, int | None]:
    ensure_default_settings(db)
    rows = {r["field"]: r["ttl_hours"] for r in db.execute("SELECT field, ttl_hours FROM freshness_settings")}
    return {field: rows.get(field, DEFAULT_TTLS[field]) for field in TRACKED_FIELDS}


def update_ttl_settings(db, updates: dict[str, int | None]) -> dict[str, int | None]:
    ensure_default_settings(db)
    timestamp = utc_now_iso()
    for field, ttl in updates.items():
        if field not in DEFAULT_TTLS:
            raise ValueError(f"不支持时效配置的字段：{field}")
        if field in MANUAL_FIELDS:
            if ttl is not None:
                raise ValueError(f"「{FIELD_LABELS[field]}」为人工维护字段，不支持自动刷新周期")
            continue
        if ttl is None or type(ttl) is not int or not (1 <= ttl <= 8760):
            raise ValueError(f"「{FIELD_LABELS[field]}」有效期须为 1 至 8760 小时之间的整数")
        db.execute(
            "INSERT INTO freshness_settings(field, ttl_hours, updated_at) VALUES(?,?,?) "
            "ON CONFLICT(field) DO UPDATE SET ttl_hours=excluded.ttl_hours, updated_at=excluded.updated_at",
            (field, ttl, timestamp),
        )
    return get_ttl_settings(db)


def record_field_success(
    db,
    account_id: int,
    fields,
    source_type: str,
    source_name: str,
    timestamp: str | None = None,
) -> None:
    ts = timestamp or utc_now_iso()
    for field in fields:
        if field not in DEFAULT_TTLS:
            continue
        db.execute(
            "INSERT INTO account_field_states(account, field, last_succeeded_at, last_attempted_at, "
            "source_type, source_name, last_refresh_failed, last_error) VALUES(?,?,?,?,?,?,0,NULL) "
            "ON CONFLICT(account, field) DO UPDATE SET "
            "last_succeeded_at=excluded.last_succeeded_at, "
            "last_attempted_at=excluded.last_attempted_at, "
            "source_type=excluded.source_type, "
            "source_name=excluded.source_name, "
            "last_refresh_failed=0, "
            "last_error=NULL",
            (account_id, field, ts, ts, source_type, source_name),
        )


def record_field_failure(
    db,
    account_id: int,
    fields,
    error: str,
    timestamp: str | None = None,
) -> None:
    """Record a failed refresh attempt WITHOUT overwriting last_succeeded_at or field values."""
    ts = timestamp or utc_now_iso()
    clean_err = str(error or "刷新失败")[:300]
    for field in fields:
        if field not in DEFAULT_TTLS:
            continue
        db.execute(
            "INSERT INTO account_field_states(account, field, last_succeeded_at, last_attempted_at, "
            "source_type, source_name, last_refresh_failed, last_error) VALUES(?,?,NULL,?,NULL,NULL,1,?) "
            "ON CONFLICT(account, field) DO UPDATE SET "
            "last_attempted_at=excluded.last_attempted_at, "
            "last_refresh_failed=1, "
            "last_error=excluded.last_error",
            (account_id, field, ts, clean_err),
        )


def _field_has_value(account: dict, field: str) -> bool:
    raw = account.get("raw") if isinstance(account.get("raw"), dict) else {}
    if field in ("followers", "views", "country"):
        return account.get(field) not in (None, "")
    if field in ("recent_average", "recent_median"):
        return raw.get(field) is not None
    if field == "bio":
        return bool((raw.get("bio") or "").strip())
    if field == "content":
        return bool(raw.get("content"))
    if field == "tags":
        return bool(account.get("tags"))
    if field == "email":
        contact = account.get("contact") if isinstance(account.get("contact"), dict) else {}
        return bool(contact.get("email") or raw.get("email")) or account.get("email_state") in ("not_found", "unavailable")
    if field == "quote":
        return bool(raw.get("quote"))
    if field == "collaboration":
        return bool((raw.get("collaboration") or "").strip())
    return False


def sync_account_states(
    db,
    account_id: int,
    profile: dict,
    source_type: str,
    source_name: str,
    timestamp: str | None = None,
    only_fields=None,
) -> None:
    ts = timestamp or utc_now_iso()
    prov_fields = (profile.get("provenance") or {}).get("fields") or {}
    targets = only_fields if only_fields is not None else TRACKED_FIELDS
    for field in targets:
        if field not in DEFAULT_TTLS:
            continue
        present = False
        if field in ("followers", "views", "country", "bio", "content", "recent_average", "recent_median", "quote", "collaboration"):
            present = profile.get(field) not in (None, "", [])
        elif field == "email":
            present = bool(profile.get("email")) or profile.get("email_state") in ("verified", "not_found", "unavailable")
        elif field == "tags":
            present = bool(profile.get("tags") or profile.get("bio") or profile.get("content"))
        if not present:
            continue
        f_source_name = prov_fields.get(field, {}).get("source_name") or source_name
        f_source_type = "manual" if field in MANUAL_FIELDS else source_type
        record_field_success(db, account_id, (field,), f_source_type, f_source_name, ts)


def compute_freshness(
    db,
    account: dict,
    ttls: dict[str, int | None] | None = None,
    now_dt: datetime | None = None,
) -> dict:
    ttls = ttls or get_ttl_settings(db)
    now_dt = now_dt or datetime.now(timezone.utc)
    rows = {
        r["field"]: dict(r)
        for r in db.execute("SELECT * FROM account_field_states WHERE account=?", (account["id"],))
    }
    raw = account.get("raw") if isinstance(account.get("raw"), dict) else {}
    prov = raw.get("provenance") if isinstance(raw.get("provenance"), dict) else {}
    prov_fields = prov.get("fields") if isinstance(prov.get("fields"), dict) else {}

    fields_info: dict[str, dict] = {}
    stale_fields: list[str] = []
    missing_fields: list[str] = []
    failed_fields: list[str] = []
    fresh_count = 0
    manual_count = 0

    for field in TRACKED_FIELDS:
        has_val = _field_has_value(account, field)
        ttl_hours = ttls.get(field)
        rec = rows.get(field)

        last_succeeded = rec["last_succeeded_at"] if rec else None
        last_attempted = rec["last_attempted_at"] if rec else None
        src_type = rec["source_type"] if rec else None
        src_name = rec["source_name"] if rec else None
        failed = bool(rec["last_refresh_failed"]) if rec else False
        last_error = rec["last_error"] if rec else None

        # Backfill display metadata for pre-V1.3 accounts that have data but no state rows yet.
        if not rec and has_val:
            last_succeeded = prov_fields.get(field, {}).get("updated_at") or account.get("updated_at")
            last_attempted = last_succeeded
            src_name = prov_fields.get(field, {}).get("source_name") or prov.get("source_name") or account.get("source")
            src_type = "manual" if field in MANUAL_FIELDS else ("youtube_api" if account.get("source") == "youtube_api" else "import")

        succeeded_dt = parse_iso(last_succeeded)
        is_expired = bool(
            has_val and ttl_hours is not None and succeeded_dt is not None
            and now_dt > succeeded_dt + timedelta(hours=ttl_hours)
        )

        if field in MANUAL_FIELDS:
            status = "manual" if has_val else "missing"
            if has_val:
                manual_count += 1
            else:
                missing_fields.append(field)
        elif failed:
            status = "failed"
            failed_fields.append(field)
            if is_expired:
                stale_fields.append(field)
        elif not has_val:
            status = "missing"
            missing_fields.append(field)
        elif is_expired:
            status = "stale"
            stale_fields.append(field)
        else:
            status = "fresh"
            fresh_count += 1

        fields_info[field] = {
            "field": field,
            "label": FIELD_LABELS[field],
            "status": status,
            "has_value": has_val,
            "is_fresh": status == "fresh",
            "is_stale": is_expired,
            "is_missing": not has_val,
            "last_refresh_failed": failed,
            "last_error": last_error,
            "last_succeeded_at": last_succeeded,
            "last_attempted_at": last_attempted,
            "source_type": src_type,
            "source_name": src_name,
            "ttl_hours": ttl_hours,
        }

    overall = (
        "failed" if failed_fields else
        "stale" if stale_fields else
        "missing" if missing_fields else
        "fresh"
    )
    return {
        "overall_status": overall,
        "fresh_count": fresh_count,
        "stale_count": len(stale_fields),
        "missing_count": len(missing_fields),
        "failed_count": len(failed_fields),
        "manual_count": manual_count,
        "stale_fields": stale_fields,
        "missing_fields": missing_fields,
        "failed_fields": failed_fields,
        "needs_refresh": bool(stale_fields or failed_fields or "followers" in missing_fields or "views" in missing_fields),
        "fields": fields_info,
    }


def match_snapshot(account: dict, freshness: dict) -> dict:
    """Capture the exact values and freshness used when evaluating a candidate."""
    raw = account.get("raw") if isinstance(account.get("raw"), dict) else {}
    return {
        "followers": account.get("followers"),
        "views": account.get("views"),
        "recent_average": (raw.get("recent_average") or {}).get("value") if isinstance(raw.get("recent_average"), dict) else raw.get("recent_average"),
        "recent_median": (raw.get("recent_median") or {}).get("value") if isinstance(raw.get("recent_median"), dict) else raw.get("recent_median"),
        "country": account.get("country"),
        "language": account.get("language"),
        "email_state": account.get("email_state"),
        "evaluated_at": utc_now_iso(),
        "freshness_status": freshness["overall_status"],
        "stale_fields": freshness["stale_fields"],
        "failed_fields": freshness["failed_fields"],
    }
