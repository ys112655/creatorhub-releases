"""Import grants and purpose-specific projections for governed accounts."""
from datetime import date
from typing import Literal

from pydantic import BaseModel, Field

from .imports import FIELDS, normalize
from .domain import rules

Purpose = Literal["view", "tag", "match", "export", "model"]

class ImportPolicy(BaseModel):
    source_name: str = Field(min_length=1, max_length=120)
    permission: str = Field(min_length=1, max_length=500)
    effective_on: date
    acquired_on: date
    expires_on: date
    deletion_owner: str = Field(min_length=1, max_length=120)
    allowed_fields: list[str] = Field(min_length=1, max_length=60)
    purposes: list[Purpose] = Field(min_length=1, max_length=5)
    restricted_fields: list[str] = Field(default_factory=list, max_length=60)
    field_expiries: dict[str, date] = Field(default_factory=dict, max_length=60)
    field_purposes: dict[str, list[Purpose]] = Field(default_factory=dict, max_length=60)


# Values normalized together share the shortest lifetime of their inputs.
DEPENDENCIES = {
    "account_id": {"account_id", "url"}, "url": {"account_id", "url"},
    "alias": {"alias", "account_id", "url"}, "display_name": {"display_name", "account_id", "url"},
    "followers": {"followers", "followers_k"}, "views": {"views", "views_k"},
    "content": {"content_titles", "content_urls", "content_descriptions", "content_tags", "url"},
    "email_state": {"email", "email_url", "email_state"},
    "email": {"email", "email_url", "email_state"},
    "email_url": {"email", "email_url", "email_state"},
    "audience": {"audience", "audience_url"},
    "recent_average": {"recent_average", "recent_samples", "recent_count", "recent_scope"},
    "recent_median": {"recent_median", "recent_samples", "recent_count", "recent_scope"},
}
INDEXED = ("display_name", "country", "language", "followers", "views", "email_state", "bd")
IDENTITY = ("platform", "account_id", "url")
CONTACT = ("email", "email_url", "email_state")


def prepare_policy(policy, today):
    basis = policy.model_dump(mode="json")
    for key in ("source_name", "permission", "deletion_owner"):
        basis[key] = basis[key].strip()
        if not basis[key]:
            raise ValueError("来源、授权依据和删除责任人不能为空")
    if not (policy.acquired_on <= today and policy.effective_on <= today < policy.expires_on
            and policy.acquired_on < policy.expires_on):
        raise ValueError("获取日期、授权生效日期或保存期限无效")
    allowed = {FIELDS.get(key.strip(), key.strip()) for key in policy.allowed_fields}
    restricted = {FIELDS.get(key.strip(), key.strip()) for key in policy.restricted_fields}
    for aliases in (DEPENDENCIES["followers"], DEPENDENCIES["views"]):
        if aliases & restricted:
            restricted.update(aliases)
    known = set(FIELDS.values()) | set(IDENTITY)
    expiries = {FIELDS.get(key.strip(), key.strip()): value for key, value in policy.field_expiries.items()}
    purposes = {FIELDS.get(key.strip(), key.strip()): set(value) for key, value in policy.field_purposes.items()}
    if (allowed | restricted | expiries.keys() | purposes.keys()) - known or not set(IDENTITY) <= allowed - restricted:
        raise ValueError("字段授权无效，平台、账号 ID 和主页链接均需授权")
    if any(not today < value <= policy.expires_on for value in expiries.values()):
        raise ValueError("字段截止日须晚于今天且不超过批次截止日")
    if any(not value or not value <= set(policy.purposes) for value in purposes.values()):
        raise ValueError("字段用途须属于批次授权范围")
    basis.update(allowed_fields=sorted(allowed), restricted_fields=sorted(restricted),
                 purposes=sorted(set(policy.purposes)),
                 field_expiries={key: value.isoformat() for key, value in expiries.items()},
                 field_purposes={key: sorted(value) for key, value in purposes.items()})
    return basis, allowed - restricted


def governed_profile(row, source, grant, record_id, *, lenient=False):
    basis, allowed = grant
    permitted = {key: value for key, value in row.items() if key in allowed and value}
    if not {"email", "email_url", "email_state"} <= allowed:
        for key in CONTACT:
            permitted.pop(key, None)
        permitted.pop("bio", None)
    if "audience_url" not in allowed:
        permitted.pop("audience", None)
    clean = normalize(permitted, source, extract_email=False, lenient=lenient)
    metadata = {}
    for key, value in list(clean.items()):
        if key == "source":
            continue
        if key in basis["restricted_fields"]:
            clean.pop(key)
            continue
        dependencies = DEPENDENCIES.get(key, {key})
        if (value in (None, "", []) or (key not in allowed and not dependencies & permitted.keys())):
            clean.pop(key)
            continue
        inputs = dependencies & (permitted.keys() | set(IDENTITY))
        until = min((basis["field_expiries"].get(name, basis["expires_on"]) for name in inputs),
                    default=basis["expires_on"])
        purposes = set(basis["purposes"])
        for name in inputs:
            purposes.intersection_update(basis["field_purposes"].get(name, basis["purposes"]))
        metadata[key] = {**{name: basis[name] for name in
                           ("source_name", "permission", "effective_on", "acquired_on", "deletion_owner")},
                         "original_record_id": record_id, "expires_on": until, "purposes": sorted(purposes)}
    clean["provenance"] = {**basis, "fields": metadata}
    return clean


def active_fields(provenance, today, purpose=None):
    return {key: grant for key, grant in provenance["fields"].items()
            if today < grant["expires_on"] and (purpose is None or set(purpose.split("+")) <= set(grant["purposes"]))}


def project_account(account, purpose, today):
    provenance = account["raw"].get("provenance")
    if not provenance or not isinstance(provenance.get("fields"), dict):
        return account
    fields = active_fields(provenance, today, purpose)
    if not all(key in fields for key in IDENTITY):
        return None
    raw = {key: value for key, value in account["raw"].items() if key in fields}
    raw["provenance"] = {**provenance, "fields": fields}
    result = {**account, **{key: account[key] if key in fields else None for key in INDEXED}, "raw": raw}
    result["contact"] = {key: value for key, value in (account["contact"] or {}).items()
                         if {"url": "email_url", "state": "email_state"}.get(key, key) in fields}
    result["tags"] = []
    if purpose in ("view", "match", "view+match"):
        tag_fields = active_fields(provenance, today, "tag").keys() & fields.keys()
        if "url" in tag_fields:
            result["tags"] = rules({key: value for key, value in raw.items() if key in tag_fields})
    return result
