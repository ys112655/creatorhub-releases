"""P1 on-demand creator refresh: pre-filter, TTL check, coalescing, real public feeds & mock provider."""
from __future__ import annotations

from decimal import Decimal
import html
from io import BytesIO
import json
import re
from statistics import median
from threading import Condition, Thread
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import freshness
from .domain import evaluate, rules
from .imports import FIELD_KEYS, FIELD_LABELS
from .permissions import IDENTITY
from .store import dump, load, now

REFRESHABLE_FIELDS = ("followers", "views", "recent_average", "recent_median", "bio", "content", "tags", "country", "email")


class RefreshError(Exception):
    pass


def _http_get(url: str, timeout: int = 12) -> str:
    req = Request(url, headers={"User-Agent": "CreatorHub/1.3 (+on-demand-refresh)"})
    try:
        with urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except HTTPError as exc:
        raise RefreshError(f"HTTP {exc.code}（{url.split('/')[2]}）") from None
    except (URLError, TimeoutError, OSError) as exc:
        raise RefreshError(f"网络请求失败：{exc}") from None


def _parse_compact_count(raw: str) -> int | None:
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([KMBkmb]?)", raw.strip().replace(",", ""))
    if not match:
        return None
    mult = {"": 1, "k": 1_000, "m": 1_000_000, "b": 1_000_000_000}[match.group(2).lower()]
    return int(Decimal(match.group(1)) * mult)


class PublicFeedRefreshProvider:
    """Zero-cost public metadata refresh using official RSS/oEmbed and public meta tags."""

    source_type = "public_feed"
    source_name = "公开主页与官方 RSS/oEmbed"

    def fetch(self, account: dict) -> dict:
        platform = account["platform"]
        if platform == "YouTube":
            return self._fetch_youtube(account)
        if platform == "TikTok":
            return self._fetch_tiktok(account)
        if platform == "Instagram":
            return self._fetch_instagram(account)
        raise RefreshError(f"{platform} 平台暂无免费免登录公开刷新接口，请使用批量导入或人工核验")

    def _fetch_youtube(self, account: dict) -> dict:
        identifier = account["account_id"]
        url = account["url"]
        updates: dict = {}
        channel_id = identifier if re.fullmatch(r"UC[A-Za-z0-9_-]{22}", identifier) else None

        if not channel_id:
            page_html = _http_get(url)
            rss_match = re.search(
                r"https://www\.youtube\.com/feeds/videos\.xml\?channel_id=(UC[A-Za-z0-9_-]{22})",
                page_html,
            ) or re.search(r'"channelId"\s*:\s*"(UC[A-Za-z0-9_-]{22})"', page_html)
            if not rss_match:
                raise RefreshError("未能从 YouTube 公开主页解析频道 ID（UC...）")
            channel_id = rss_match.group(1)
            meta_desc = re.search(r'<meta\s+name="description"\s+content="([^"]*)"', page_html, re.I)
            if meta_desc and meta_desc.group(1).strip():
                updates["bio"] = html.unescape(meta_desc.group(1).strip())[:1500]

        xml_text = _http_get(f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}")
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as exc:
            raise RefreshError("YouTube RSS 返回格式异常") from exc

        ns = {
            "atom": "http://www.w3.org/2005/Atom",
            "media": "http://search.yahoo.com/mrss/",
        }
        title = (root.findtext("atom:title", default="", namespaces=ns) or "").strip()
        if title:
            updates["display_name"] = title[:200]

        content_items = []
        sample_views = []
        for entry in root.findall("atom:entry", ns)[:10]:
            v_title = (entry.findtext("atom:title", default="", namespaces=ns) or "").strip()
            link_el = entry.find("atom:link", ns)
            v_url = link_el.attrib.get("href", "") if link_el is not None else ""
            desc = (entry.findtext("media:group/media:description", default="", namespaces=ns) or "").strip()
            stats = entry.find("media:group/media:community/media:statistics", ns)
            if stats is not None and stats.attrib.get("views", "").isdigit():
                sample_views.append(int(stats.attrib["views"]))
            if v_title:
                content_items.append({"title": v_title[:700], "url": v_url or url, "description": desc[:1200], "tags": ""})

        if content_items:
            updates["content"] = content_items
        if sample_views:
            avg_val = round(sum(sample_views) / len(sample_views), 4)
            med_val = round(float(median(sample_views)), 4)
            scope = f"YouTube RSS 最近{len(sample_views)}条公开视频"
            updates["recent_samples"] = sample_views
            updates["recent_average"] = {"value": avg_val, "sample_count": len(sample_views), "scope": scope, "derived": True}
            updates["recent_median"] = {"value": med_val, "sample_count": len(sample_views), "scope": scope, "derived": True}
            updates["views"] = int(round(avg_val))

        if not updates:
            raise RefreshError("YouTube RSS 未返回可更新字段")
        return {
            "updates": updates,
            "channel_id": channel_id,
            "unsupported": ["followers", "country", "language", "email"],
        }

    def _fetch_tiktok(self, account: dict) -> dict:
        raw_json = _http_get("https://www.tiktok.com/oembed?url=" + quote(account["url"], safe=":/@"))
        try:
            data = json.loads(raw_json)
        except ValueError:
            raise RefreshError("TikTok oEmbed 返回无法解析") from None
        updates = {}
        if data.get("author_name"):
            updates["display_name"] = str(data["author_name"]).strip()[:200]
        if not updates:
            raise RefreshError("TikTok oEmbed 未返回有效资料")
        return {
            "updates": updates,
            "unsupported": ["followers", "views", "recent_average", "recent_median", "country", "email"],
        }

    def _fetch_instagram(self, account: dict) -> dict:
        page_html = _http_get(account["url"])
        match = re.search(
            r'<meta\s+property="og:description"\s+content="([^"]*?)"',
            page_html,
            re.I,
        )
        if not match:
            raise RefreshError("Instagram 未登录页未返回公开粉丝数，请使用批量导入或人工核验")
        desc = html.unescape(match.group(1))
        f_match = re.search(r"([0-9]+(?:\.[0-9]+)?\s*[KMBkmb]?)\s+Followers", desc)
        if not f_match:
            raise RefreshError("Instagram 未登录页未包含公开粉丝数，请使用批量导入或人工核验")
        followers = _parse_compact_count(f_match.group(1))
        if followers is None:
            raise RefreshError("Instagram 粉丝数解析失败")
        return {
            "updates": {"followers": followers},
            "unsupported": ["views", "recent_average", "recent_median", "country", "email"],
        }


class MockRefreshProvider:
    """Deterministic offline provider for demo mode and automated tests."""

    source_type = "mock"
    source_name = "模拟按需刷新"

    def __init__(self, fail_accounts: set[str] | None = None):
        self.fail_accounts = fail_accounts or set()

    def fetch(self, account: dict) -> dict:
        if account["account_id"] in self.fail_accounts:
            raise RefreshError("模拟数据源返回超时或限流")
        base_followers = account.get("followers")
        new_followers = (base_followers + 1200) if base_followers is not None else 55000
        base_views = account.get("views")
        new_views = (base_views + 450) if base_views is not None else 12400
        samples = [new_views - 800, new_views, new_views + 800]
        avg_val = round(sum(samples) / len(samples), 4)
        med_val = round(float(median(samples)), 4)
        return {
            "updates": {
                "followers": new_followers,
                "views": new_views,
                "recent_samples": samples,
                "recent_average": {"value": avg_val, "sample_count": 3, "scope": "模拟最近3条", "derived": True},
                "recent_median": {"value": med_val, "sample_count": 3, "scope": "模拟最近3条", "derived": True},
                "bio": account["raw"].get("bio") or "ComfyUI & AI video creator (mock refreshed)",
                "content": account["raw"].get("content") or [
                    {"title": "ComfyUI Workflow Breakdown", "url": account["url"], "description": "AI video", "tags": "ComfyUI"}
                ],
            },
            "unsupported": [],
        }


def prefilter_project(db, store, project_id: int, near_threshold_ratio: float = 0.8) -> dict:
    """Local pre-filter retaining stale near-threshold candidates + checking freshness."""
    row = db.execute("SELECT * FROM projects WHERE id=? AND workspace_id=1", (project_id,)).fetchone()
    if not row:
        raise KeyError("项目不存在")
    criteria = load(row["criteria"])
    hard = criteria.get("hard") or {}
    min_followers = hard.get("min_followers")
    ttls = freshness.get_ttl_settings(db)

    ids = [r["id"] for r in db.execute("SELECT id FROM accounts WHERE workspace_id=1 ORDER BY id DESC")]
    candidates = []
    needs_refresh_ids = []
    eligible_count = 0
    near_threshold_count = 0
    stale_count = 0
    missing_count = 0
    failed_count = 0

    for acc_id in ids:
        account = store.account(db, acc_id, "view+match")
        if not account or account["source"] not in ("authorized", "independent", "fixture"):
            continue
        basis = evaluate(account, criteria)
        state = freshness.compute_freshness(db, account, ttls)
        near = False
        if basis["state"] == "excluded":
            if (
                min_followers is not None
                and basis["failed"] == ["min_followers"]
                and account.get("followers") is not None
                and account["followers"] >= int(min_followers * near_threshold_ratio)
                and (state["fields"]["followers"]["is_stale"] or state["fields"]["followers"]["is_missing"])
            ):
                near = True
                basis["near_threshold"] = True
                basis["state"] = "review"
                basis["unknown"] = list(dict.fromkeys([*basis["unknown"], "临界粉丝量待刷新复核"]))
            else:
                continue

        if near:
            near_threshold_count += 1
        else:
            eligible_count += 1

        basis["used_values"] = freshness.match_snapshot(account, state)
        store.match(db, project_id, acc_id, basis)

        if state["stale_count"]:
            stale_count += 1
        if state["missing_count"]:
            missing_count += 1
        if state["failed_count"]:
            failed_count += 1
        if state["needs_refresh"]:
            needs_refresh_ids.append(acc_id)

        candidates.append({
            "account_id": acc_id,
            "display_name": account["display_name"],
            "platform": account["platform"],
            "followers": account["followers"],
            "views": account["views"],
            "near_threshold": near,
            "match_state": basis["state"],
            "freshness": {
                "overall_status": state["overall_status"],
                "stale_fields": state["stale_fields"],
                "missing_fields": state["missing_fields"],
                "failed_fields": state["failed_fields"],
                "needs_refresh": state["needs_refresh"],
            },
        })

    return {
        "project_id": project_id,
        "total_scanned": len(ids),
        "eligible_count": eligible_count,
        "near_threshold_count": near_threshold_count,
        "stale_accounts": stale_count,
        "missing_accounts": missing_count,
        "failed_accounts": failed_count,
        "needs_refresh_ids": needs_refresh_ids,
        "candidates": candidates,
    }


def export_manual_refresh_xlsx(db, store, account_ids: list[int]) -> bytes:
    """Export a pre-filled V1.3 XLSX sheet for creators needing manual data updates."""
    wb = Workbook()
    ws = wb.active
    ws.title = "达人导入模板"
    headers = [FIELD_LABELS[key] for key in FIELD_KEYS]
    ws.append(headers)
    fill = PatternFill(start_color="E4F0E7", end_color="E4F0E7", fill_type="solid")
    font = Font(bold=True, color="102B24")
    for idx, key in enumerate(FIELD_KEYS, start=1):
        c = ws.cell(1, idx)
        c.fill = fill
        c.font = font
        c.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = 30 if key == "url" else 18
    ws.freeze_panes = "A2"

    for acc_id in account_ids[:500]:
        acc = store.account(db, acc_id, "view")
        if not acc:
            continue
        state = freshness.compute_freshness(db, acc)
        stale_or_missing = set(state["stale_fields"]) | set(state["missing_fields"]) | set(state["failed_fields"])
        row_map = {
            "platform": acc["platform"],
            "account_id": acc["account_id"],
            "url": acc["url"],
            "display_name": acc["display_name"],
            "country": "" if "country" in stale_or_missing else (acc.get("country") or ""),
            "language": acc.get("language") or "",
            "followers": "" if "followers" in stale_or_missing else (acc.get("followers") if acc.get("followers") is not None else ""),
            "views": "" if "views" in stale_or_missing else (acc.get("views") if acc.get("views") is not None else ""),
        }
        ws.append([row_map.get(key, "") for key in FIELD_KEYS])

    stream = BytesIO()
    wb.save(stream)
    return stream.getvalue()


class RefreshService:
    """Background on-demand refresh worker with single-flight coalescing, cancel, retry & budget."""

    def __init__(self, store, public_provider=None, mock_provider=None):
        self.store = store
        self.public_provider = public_provider or PublicFeedRefreshProvider()
        self.mock_provider = mock_provider or MockRefreshProvider()
        self.wake = Condition()
        self.stopping = False
        self.thread: Thread | None = None

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.stopping = False
        self.thread = Thread(target=self._loop, daemon=True)
        self.thread.start()

    def close(self) -> None:
        with self.wake:
            self.stopping = True
            self.wake.notify_all()
        if self.thread:
            self.thread.join(timeout=5)
            self.thread = None

    def enqueue(
        self,
        account_ids: list[int],
        *,
        project_id: int | None = None,
        mode: str = "public_feed",
        fields: list[str] | None = None,
        force: bool = False,
        budget_limit: int = 50,
    ) -> dict:
        if mode not in ("public_feed", "mock"):
            raise ValueError("刷新模式须为 public_feed 或 mock")
        if not account_ids:
            raise ValueError("请至少选择一位需要刷新的达人")
        if not (1 <= budget_limit <= 200):
            raise ValueError("单次调用上限须在 1 至 200 之间")

        req_fields = [f for f in (fields or REFRESHABLE_FIELDS) if f in REFRESHABLE_FIELDS]
        if not req_fields:
            req_fields = list(REFRESHABLE_FIELDS)

        ts = now()
        dedup_ids = list(dict.fromkeys(int(aid) for aid in account_ids))
        coalesced: list[int] = []
        skipped_fresh: list[int] = []
        queued_ids: list[int] = []

        with self.store.connection(True) as db:
            ttls = freshness.get_ttl_settings(db)
            active_rows = db.execute(
                "SELECT account FROM refresh_items WHERE status IN ('queued','running')"
            ).fetchall()
            active_accounts = {r["account"] for r in active_rows}

            for acc_id in dedup_ids:
                acc = self.store.account(db, acc_id, "view")
                if not acc:
                    continue
                if acc_id in active_accounts:
                    coalesced.append(acc_id)
                    continue
                state = freshness.compute_freshness(db, acc, ttls)
                check_fields = fields if fields is not None else ("followers", "views")
                needs = any(
                    state["fields"][f]["is_stale"] or state["fields"][f]["last_refresh_failed"]
                    or (f in ("followers", "views") and state["fields"][f]["is_missing"])
                    for f in check_fields if f in state["fields"]
                )
                if not force and not needs:
                    skipped_fresh.append(acc_id)
                    continue
                if len(queued_ids) >= budget_limit:
                    break
                queued_ids.append(acc_id)

            total = len(queued_ids) + len(skipped_fresh)
            initial_status = "done" if not queued_ids else "queued"
            job_id = db.execute(
                "INSERT INTO refresh_jobs(project, mode, status, total, completed, succeeded, failed, "
                "skipped_fresh, budget_limit, calls_used, created_at, updated_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,0,?,?)",
                (project_id, mode, initial_status, total, len(skipped_fresh), 0, 0,
                 len(skipped_fresh), budget_limit, ts, ts),
            ).lastrowid

            for acc_id in skipped_fresh:
                db.execute(
                    "INSERT INTO refresh_items(job, account, status, requested_fields, updated_at) VALUES(?,?,?,?,?)",
                    (job_id, acc_id, "skipped_fresh", dump(req_fields), ts),
                )
            for acc_id in queued_ids:
                db.execute(
                    "INSERT INTO refresh_items(job, account, status, requested_fields, updated_at) VALUES(?,?,?,?,?)",
                    (job_id, acc_id, "queued", dump(req_fields), ts),
                )

        if queued_ids:
            with self.wake:
                self.wake.notify_all()

        return {
            "job_id": job_id,
            "status": initial_status,
            "queued": len(queued_ids),
            "skipped_fresh": len(skipped_fresh),
            "coalesced": coalesced,
            "budget_limit": budget_limit,
        }

    def get_job(self, job_id: int) -> dict:
        with self.store.connection() as db:
            job = db.execute("SELECT * FROM refresh_jobs WHERE id=?", (job_id,)).fetchone()
            if not job:
                raise KeyError("刷新任务不存在")
            items = [
                {
                    **dict(r),
                    "requested_fields": load(r["requested_fields"]),
                    "updated_fields": load(r["updated_fields"]),
                }
                for r in db.execute(
                    "SELECT ri.*, a.display_name, a.platform, a.account_id AS handle "
                    "FROM refresh_items ri JOIN accounts a ON a.id=ri.account "
                    "WHERE ri.job=? ORDER BY ri.id",
                    (job_id,),
                )
            ]
            return {**dict(job), "items": items}

    def control(self, job_id: int, action: str) -> dict:
        if action not in ("cancel", "retry"):
            raise ValueError("不支持的刷新控制动作")
        ts = now()
        with self.store.connection(True) as db:
            job = db.execute("SELECT * FROM refresh_jobs WHERE id=?", (job_id,)).fetchone()
            if not job:
                raise KeyError("刷新任务不存在")
            if action == "cancel":
                db.execute(
                    "UPDATE refresh_items SET status='cancelled', updated_at=? WHERE job=? AND status='queued'",
                    (ts, job_id),
                )
                db.execute(
                    "UPDATE refresh_jobs SET status='cancelled', updated_at=? WHERE id=? AND status IN ('queued','running')",
                    (ts, job_id),
                )
            else:
                failed_rows = db.execute(
                    "SELECT account FROM refresh_items WHERE job=? AND status='failed'",
                    (job_id,),
                ).fetchall()
                if not failed_rows:
                    return self.get_job(job_id)
                active_accounts = {
                    r["account"] for r in db.execute("SELECT account FROM refresh_items WHERE status IN ('queued','running')")
                }
                requeued = 0
                for row in failed_rows:
                    if row["account"] in active_accounts:
                        continue
                    db.execute(
                        "UPDATE refresh_items SET status='queued', error=NULL, updated_at=? WHERE job=? AND account=?",
                        (ts, job_id, row["account"]),
                    )
                    requeued += 1
                if requeued:
                    db.execute(
                        "UPDATE refresh_jobs SET status='queued', completed=completed-?, failed=failed-?, updated_at=? WHERE id=?",
                        (requeued, requeued, ts, job_id),
                    )
        if action == "retry":
            with self.wake:
                self.wake.notify_all()
        return self.get_job(job_id)

    def _loop(self) -> None:
        while not self.stopping:
            item = self._next_item()
            if not item:
                with self.wake:
                    if not self.stopping:
                        self.wake.wait(0.25)
                continue
            self._process_item(item)

    def _next_item(self) -> dict | None:
        with self.store.connection(True) as db:
            row = db.execute(
                "SELECT ri.id, ri.job, ri.account, ri.requested_fields, rj.mode, rj.project, rj.budget_limit, rj.calls_used "
                "FROM refresh_items ri JOIN refresh_jobs rj ON rj.id=ri.job "
                "WHERE ri.status='queued' AND rj.status IN ('queued','running') "
                "ORDER BY ri.id LIMIT 1"
            ).fetchone()
            if not row:
                return None
            if row["calls_used"] >= row["budget_limit"]:
                ts = now()
                db.execute(
                    "UPDATE refresh_items SET status='cancelled', error='已达单批调用上限', updated_at=? WHERE job=? AND status='queued'",
                    (ts, row["job"]),
                )
                db.execute(
                    "UPDATE refresh_jobs SET status='done', error='已达单批调用上限', updated_at=? WHERE id=?",
                    (ts, row["job"]),
                )
                return None
            ts = now()
            db.execute("UPDATE refresh_items SET status='running', attempts=attempts+1, updated_at=? WHERE id=?", (ts, row["id"]))
            db.execute("UPDATE refresh_jobs SET status='running', calls_used=calls_used+1, updated_at=? WHERE id=?", (ts, row["job"]))
            return dict(row)

    def _process_item(self, item: dict) -> None:
        with self.store.connection() as db:
            account = self.store.account(db, item["account"], "view")
            job_row = db.execute("SELECT status FROM refresh_jobs WHERE id=?", (item["job"],)).fetchone()
        if not account or not job_row or job_row["status"] == "cancelled":
            self._finish_item(item["job"], item["id"], "cancelled", [], "任务已取消")
            return

        provider = self.mock_provider if item["mode"] == "mock" else self.public_provider
        requested = load(item["requested_fields"])
        ts = now()
        try:
            res = provider.fetch(account)
            updates = res.get("updates") or {}
            self._apply_updates(item["account"], item["project"], updates, provider.source_type, provider.source_name, ts)
            updated_keys = [k for k in updates.keys() if k in freshness.DEFAULT_TTLS or k == "recent_samples"]
            self._finish_item(item["job"], item["id"], "succeeded", updated_keys, None)
        except Exception as exc:
            err_msg = str(exc) or "刷新失败"
            with self.store.connection(True) as db:
                freshness.record_field_failure(db, item["account"], requested, err_msg, ts)
            self._finish_item(item["job"], item["id"], "failed", [], err_msg)

    def _apply_updates(self, account_id: int, project_id: int | None, updates: dict, source_type: str, source_name: str, ts: str) -> None:
        with self.store.connection(True) as db:
            row = db.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
            if not row:
                return
            raw = load(row["raw"])
            changed = []
            for key in ("display_name", "followers", "views", "recent_average", "recent_median", "recent_samples", "bio", "content", "country"):
                if key in updates and updates[key] not in (None, "", []):
                    raw[key] = updates[key]
                    changed.append(key)

            prov = dict(raw.get("provenance") or {})
            prov_fields = dict(prov.get("fields") or {})
            for key in changed:
                if key in prov_fields:
                    prov_fields[key] = {**prov_fields[key], "source_name": source_name, "updated_at": ts}
            if prov:
                prov["fields"] = prov_fields
                raw["provenance"] = prov

            db.execute(
                "UPDATE accounts SET display_name=?, country=?, followers=?, views=?, raw=?, updated_at=? WHERE id=?",
                (raw.get("display_name"), raw.get("country"), raw.get("followers"), raw.get("views"), dump(raw), ts, account_id),
            )
            if "bio" in changed or "content" in changed:
                new_tags = rules({**raw, "url": row["url"]})
                self.store.save_tags(db, account_id, new_tags, "rules-v1")
                changed.append("tags")

            freshness.record_field_success(
                db, account_id, [k for k in changed if k in freshness.DEFAULT_TTLS],
                source_type, source_name, ts,
            )
            if project_id is not None:
                proj = db.execute("SELECT criteria FROM projects WHERE id=?", (project_id,)).fetchone()
                if proj:
                    self.store.apply_match(db, project_id, account_id, load(proj["criteria"]))

    def _finish_item(self, job_id: int, item_id: int, status: str, updated_fields: list[str], error: str | None) -> None:
        ts = now()
        with self.store.connection(True) as db:
            db.execute(
                "UPDATE refresh_items SET status=?, updated_fields=?, error=?, updated_at=? WHERE id=?",
                (status, dump(updated_fields), error, ts, item_id),
            )
            col = "succeeded" if status == "succeeded" else ("failed" if status == "failed" else None)
            if col:
                db.execute(
                    f"UPDATE refresh_jobs SET completed=completed+1, {col}={col}+1, updated_at=? WHERE id=?",
                    (ts, job_id),
                )
            else:
                db.execute("UPDATE refresh_jobs SET completed=completed+1, updated_at=? WHERE id=?", (ts, job_id))
            remaining = db.execute(
                "SELECT COUNT(*) FROM refresh_items WHERE job=? AND status IN ('queued','running')",
                (job_id,),
            ).fetchone()[0]
            if remaining == 0:
                db.execute(
                    "UPDATE refresh_jobs SET status=CASE WHEN status='cancelled' THEN 'cancelled' ELSE 'done' END, updated_at=? WHERE id=?",
                    (ts, job_id),
                )
