const escape = value => String(value ?? "").replace(/[&<>"']/g, char =>
  ({"&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"})[char]);

export async function intakePage(root, api, toast, active, modelEnabled) {
  const [projects, templates] = await Promise.all([api("/projects"), api("/intake/templates")]);
  if (!active()) return;
  root.innerHTML = `<section class="hero"><h1>整理达人提报</h1></section>
    <section class="panel"><h2>选择品牌项目</h2>
      <select id="intake-project"><option value="">请选择</option>${projects.map(p =>
        `<option value="${p.id}">${escape(p.name)}</option>`).join("")}</select>
      <a href="#projects">创建品牌项目</a>
    </section>
    <form id="intake-form" class="panel" hidden>
      <h2>粘贴达人资料</h2>
      <label>导入方式 <select name="mode"><option value="">CSV 或 TSV 表格</option>
        ${["YouTube","Instagram","TikTok","X"].map(p=>`<option>${p}</option>`).join("")}
      </select></label>
      <label>映射模板 <select name="preset"><option value="">默认飞书列名</option>
        ${Object.keys(templates).map(t=>`<option>${escape(t)}</option>`).join("")}</select></label>
      <label>表格文件 <input name="file" type="file" accept=".tsv,.csv,.txt"></label>
      <label>达人资料 <textarea name="text" rows="6" required placeholder="粘贴带表头的表格，或选择平台后每行粘贴一个主页链接"></textarea></label>
      <details id="intake-policy"><summary>资料来源与授权</summary>
        <label>来源名称 <input name="source_name"></label>
        <label>授权依据 <input name="permission"></label>
        <label>获取日期 <input name="acquired_on" type="date"></label>
        <label>授权生效 <input name="effective_on" type="date"></label>
        <label>保存截止 <input name="expires_on" type="date"></label>
        <label>删除责任人 <input name="deletion_owner"></label>
        <label><input name="confirmed" type="checkbox"> 我确认本批所提供字段获准用于查看、整理、匹配和提报</label>
      </details>
      ${modelEnabled ? '<label><input name="model_grant" type="checkbox"> 此批作品标题获准发送给模型供应商</label>' : ''}
      <label>旧表单列播放量口径 <select name="reading_stat"><option value="unknown">口径未确认</option>
        <option value="average">平均</option><option value="median">中位数</option></select></label>
      <label>阅读输入单位 <select name="reading_unit"><option value="raw">原始阅读数</option><option value="K">K（千）</option></select></label>
      <p>可直接导入「最近10条平均播放量」「最近10条中位播放量」「逐条播放量」「统计样本数」「统计范围」「工具预估报价」。逐条值用 | 分隔，新指标按原始播放数填写。</p>
      <label>报价币种 <input name="currency" placeholder="例如 USD" required pattern="[A-Z]{3}"></label>
      <details><summary>字段映射及公式保护</summary>
        <label>保存模板名称 <input name="template" maxlength="80"></label>
        <label>飞书公式列（逗号分隔） <input name="formulas"></label>
        <fieldset><legend>自定义源表头</legend>
          ${Object.entries({display_name:"达人昵称",url:"主页链接",platform:"平台",followers:"Follower",
            views:"最近10条阅读",quote:"一轮报价",country:"国家",language:"语种",content_titles:"近期内容",
            content_urls:"近期内容链接",collaboration:"合作记录"}).map(([key,label])=>
              `<label>${label} <input name="map_${key}" placeholder="留空沿用默认表头"></label>`).join("")}
        </fieldset>
      </details>
      <p class="hint" id="go-batch-import-banner">需要标准 Excel 模板或 5,000+ 行批量上传来更新已有达人？<a href="#batch-import">前往「批量导入」 →</a></p>
<button class="primary" type="submit">开始智能整理</button>
      <div id="intake-receipt" role="status"></div>
    </form><form id="project-metrics" class="panel" hidden>
      <h2>项目统一播放量口径</h2>
      <label>用于筛选、CPM 和提报 <select name="stat" required>
        <option value="">待配置</option><option value="average">平均播放量</option>
        <option value="median">中位播放量</option></select></label>
      <label>最低播放量（可选，原始播放数） <input type="number" name="minimum" min="0" max="1000000000000000"></label>
      <button type="submit">保存项目口径</button>
    </form><section id="intake-results"></section>`;
  const pick = root.querySelector("#intake-project");
  const form = root.querySelector("#intake-form");
  const metrics = root.querySelector("#project-metrics");
  const results = root.querySelector("#intake-results");
  const receipt = root.querySelector("#intake-receipt");
  const {elements} = form;
  let records = [];
  const remembered = Number(sessionStorage.getItem('creatorhub.intake.project') || 0);
  if (remembered && [...pick.options].some(o => Number(o.value) === remembered)) { pick.value = String(remembered); setTimeout(() => pick.dispatchEvent(new Event('change')), 0); }
  sessionStorage.removeItem('creatorhub.intake.project');
  elements.file.addEventListener("change", async () => {
    const file = elements.file.files[0];
    if (!file) return;
    if (file.size > 650000) return toast("文件过大，请拆批", true);
    elements.text.value = await file.text();
  });
  elements.mode.addEventListener("change", () => {
    root.querySelector("#intake-policy").hidden = Boolean(elements.mode.value);
  });
  elements.preset.addEventListener("change", () => {
    const template = templates[elements.preset.value];
    if (!template) return;
    for (const key of ["reading_stat","reading_unit","currency"]) elements[key].value = template[key];
    elements.formulas.value = template.formula_columns.join(",");
    for (const input of form.querySelectorAll('[name^="map_"]')) input.value = "";
    for (const [header, key] of Object.entries(template.mapping)) {
      if (elements["map_"+key]) elements["map_"+key].value = header;
    }
  });
  const formulaColumns = () => elements.formulas.value.split(/[,，]/).map(x=>x.trim()).filter(Boolean);
  const run = fn => async event => {
    event.preventDefault();
    try { await fn(); } catch (error) { toast(error.message, true); }
  };
  pick.addEventListener("change", run(async () => {
    form.hidden = metrics.hidden = !pick.value;
    if (pick.value) {
      const project = pick.value;
      const config = await api("/intake/"+project+"/metrics");
      if (project !== pick.value) return;
      metrics.elements.stat.value = config.stat ?? "";
      metrics.elements.minimum.value = config.minimum ?? "";
    }
    receipt.textContent = "";
    await refresh();
  }));
  metrics.addEventListener("submit", run(async () => {
    const project = pick.value;
    const minimum = metrics.elements.minimum.value;
    await api("/intake/"+project+"/metrics","PUT",{
      stat:metrics.elements.stat.value, minimum:minimum === "" ? null : Number(minimum)});
    if (project === pick.value) await refresh();
    toast("项目口径已保存");
  }));
  form.addEventListener("submit", run(async () => {
    const project = pick.value;
    const mapping = Object.fromEntries([...form.querySelectorAll('[name^="map_"]')]
      .filter(input=>input.value.trim()).map(input=>[input.value.trim(),input.name.slice(4)]));
    const settings = {mapping, formula_columns:formulaColumns()};
    for (const key of ["reading_stat","reading_unit","currency"]) settings[key] = elements[key].value;
    if (!elements.mode.value && !elements.confirmed.checked) {
      root.querySelector("#intake-policy").open = true;
      throw Error("请填写来源与授权信息并确认");
    }
    const policy = {};
    for (const key of ["source_name","permission","acquired_on","effective_on","expires_on","deletion_owner"])
      policy[key] = elements[key].value;
    policy.allowed_fields = ["platform","account_id","url","display_name","followers","followers_k","views","views_k",
      "quote","country","language","content_titles","content_urls","collaboration",
      "recent_average","recent_median","recent_samples","recent_count","recent_scope","estimated_quote"];
    policy.purposes = ["view","tag","match","export"];
    if (elements.model_grant?.checked) {
      policy.purposes.push("model");
      policy.field_purposes = Object.fromEntries(policy.allowed_fields
        .filter(key=>!["content_titles","content_urls","url"].includes(key))
        .map(key=>[key,["view","tag","match","export"]]));
    }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      const answer = await api("/intake/"+project,"POST",{
        text:elements.text.value, source:"authorized", policy:elements.mode.value ? null : policy,
        confirmed:elements.confirmed.checked, settings, template:elements.template.value,
        links_platform:elements.mode.value || null});
      if (elements.template.value.trim()) {
        const name = elements.template.value.trim();
        if (!Object.hasOwn(templates,name)) elements.preset.add(new Option(name,name));
        Object.defineProperty(templates,name,{value:settings,configurable:true,enumerable:true});
      }
      if (project !== pick.value) return;
      receipt.innerHTML = `<p>新增 ${answer.added} · 项目内重复 ${answer.duplicates} · 失败 ${answer.rejected.length}</p>
        <ul>${answer.rejected.map(r=>`<li>第 ${r.line} 行：${escape(r.reason)}</li>`).join("")}</ul>`;
      await refresh();
    } finally { button.disabled = false; }
  }));

  const selected = () => [...results.querySelectorAll('[name="candidate"]:checked')].map(input=>Number(input.value));
  async function refresh() {
    const project = pick.value;
    records = project ? await api("/intake/"+project) : [];
    if (!active() || project !== pick.value) return;
    if (project) {
      const config = await api("/intake/"+project+"/metrics");
      if (!active() || project !== pick.value) return;
      metrics.elements.stat.value = config.stat ?? "";
      metrics.elements.minimum.value = config.minimum ?? "";
    }
    results.innerHTML = !records.length ? "" : `<section class="panel">
      <h2>审核达人</h2><label><input id="intake-all" type="checkbox"> 全选</label>
      <label>提报人 <input id="intake-operator"></label>
      <label>提报日期 <input id="intake-date" type="date"></label>
      <button data-decision="accepted">确认选中合格达人</button>
      <button data-decision="rejected">拒绝选中</button>
      <button data-decision="submitted">标记已提报</button>
      <button data-output="formal">正式提报预览</button>
      <button data-output="preview">待核实预审</button>
      <div id="intake-review-receipt" role="status"></div>
      <div id="intake-output"></div>
      <ul class="evidence-list">${records.map(r=>`<li><label>
        <input name="candidate" type="checkbox" value="${r.account}">
        ${escape(r.values[1] || r.values[2])}</label>
        <strong>${({submit:"建议提报",pass:"建议 pass",hold:"建议 hold"})[r.suggestion]}</strong> ·
        ${({pending:"待审核",accepted:"已确认",submitted:"已提报",rejected:"已拒绝"})[r.status]}
        ${r.missing.length ? " · 待核实：" + escape(r.missing.join("、")) : ""}
        ${r.basis.failed.length ? " · 未满足：" + escape(r.basis.failed.join("、")) : ""}
        ${r.values[7] != null ? " · CPM " + escape(r.values[7]) : ""}
        ${r.freshness ? " · 时效：" + escape(({fresh:"最新",stale:"已过期",missing:"缺失",failed:"刷新失败",manual:"人工"})[r.freshness.overall_status] || r.freshness.overall_status) : ""}
        ${modelEnabled ? `<label><input type="checkbox" data-model-consent="${r.account}">
          我确认本次发送品牌需求与已授权的作品标题</label>
          <button data-portrait="${r.account}">分析达人画像</button>
          <div data-portrait-result="${r.account}" role="status"></div>` : ""}
        <details><summary>播放统计与报价</summary>
          <p>项目口径：${({average:"平均",median:"中位",unknown:"待配置"})[r.reading_stat]}</p>
          ${["average","median"].map(kind => {
            const m = r.metrics[kind], label = kind === "average" ? "平均" : "中位";
            return m ? `<p>${label} ${escape(m.value)} · 样本 ${escape(m.sample_count ?? "未知")} ·
              ${escape(m.scope ?? "范围未知")} · ${escape(m.source)} · ${escape(m.updated_at)}</p>`
              : `<p>${label}：未知</p>`;
          }).join("")}
          <p>工具预估：${r.estimated_quote ? escape(r.estimated_quote.currency + " " + r.estimated_quote.min
            + (r.estimated_quote.max != null ? "–"+r.estimated_quote.max : "")) : "未知"}</p>
          <p>实际商务一轮：${escape(r.values[6] || "未知")}</p>
        </details>
        <details><summary>作品证据与历史</summary>
          ${r.content.map(c=>`<p><a href="${escape(c.url)}" target="_blank" rel="noopener noreferrer">${escape(c.title)}</a></p>`).join("") || "<p>暂无作品证据</p>"}
          ${r.history.map(h=>`<p>${escape(h.name)} · ${escape(({pending:"待审核",accepted:"已确认",submitted:"已提报",rejected:"已拒绝"})[h.status])}</p>`).join("")}
          ${r.history.flatMap(h=>h.events.map(event=>`<p>${escape(h.name)} · ${escape(event.status)} · ${escape(event.recorded_at)}</p>`)).join("")}
          ${r.collaboration ? "<p>合作记录：" + escape(r.collaboration) + "</p>" : ""}
        </details></li>`).join("")}</ul>
    </section>`;
    if (!records.length) return;
    results.querySelector("#intake-all").onchange = event => {
      results.querySelectorAll('[name="candidate"]').forEach(input=>input.checked=event.target.checked);
    };
    results.querySelectorAll("[data-portrait]").forEach(button => button.onclick = run(async () => {
      const id = button.dataset.portrait;
      const target = results.querySelector(`[data-portrait-result="${id}"]`);
      const consent = results.querySelector(`[data-model-consent="${id}"]`);
      if (!consent.checked) throw Error("请先确认本次发送授权");
      button.disabled = true;
      try {
        const result = await api(`/intake/${project}/portrait/${id}`,"POST",{allow_model:true});
        target.innerHTML = `<strong>${escape(result.source)} · ${escape(result.suggestion)}</strong>
          <p>${escape(result.reasons.join(" / "))}</p><p>${escape(result.mismatches.join(" / "))}</p>
          <p>${escape(result.missing.join(" / "))}</p>${result.evidence.map(item =>
            `<a href="${escape(item.url)}" target="_blank" rel="noopener noreferrer">${escape(item.title)}</a>`).join(" ")}`;
      } finally { button.disabled = false; }
    }));
    results.querySelectorAll("[data-decision]").forEach(button => button.onclick = run(async () => {
      const accounts = selected();
      const operator = results.querySelector("#intake-operator").value.trim();
      if (!accounts.length || !operator) throw Error("请选择达人并填写提报人");
      const submitted_on = results.querySelector("#intake-date").value || null;
      const answer = await api("/intake/"+project+"/review","POST",{
        accounts, operator, submitted_on, action:button.dataset.decision});
      if (project !== pick.value) return;
      await refresh();
      results.querySelector("#intake-operator").value = operator;
      results.querySelector("#intake-date").value = submitted_on ?? "";
      results.querySelector("#intake-review-receipt").textContent =
        `已处理 ${answer.updated} 条，${answer.blocked.length} 条未满足条件`;
    }));
    results.querySelectorAll("[data-output]").forEach(button => button.onclick = run(async () => {
      const accounts = selected();
      if (!accounts.length) throw Error("请选择要预览的达人");
      const data = await api("/intake/"+project+"/output","POST",{
        accounts, preliminary:button.dataset.output==="preview", formula_columns:formulaColumns()});
      const target = results.querySelector("#intake-output");
      target.innerHTML = `<h3>${data.preliminary ? "待核实预审" : "正式提报"} · ${data.count} 条</h3>
        <div class="table-wrap"><table><thead><tr>${data.columns.map((c,i)=>
          `<th>${escape(c)} · 缺 ${data.missing[i]}</th>`).join("")}</tr></thead><tbody>
        ${data.rows.map(row=>"<tr>"+row.map(c=>"<td>"+escape(c)+"</td>").join("")+"</tr>").join("")}
        </tbody></table></div>
        ${data.count ? data.blocks.map((b,i)=>`<button data-copy="${i}">复制 · 从第 ${b.start_column} 列粘贴（${escape(b.columns[0])}）</button>`).join("") : ""}`;
      target.querySelectorAll("[data-copy]").forEach(b=>b.onclick=run(async()=>{
        await navigator.clipboard.writeText(data.blocks[Number(b.dataset.copy)].tsv);
        toast("已复制选定列，请粘贴到独立飞书测试表");
      }));
    }));
  }
}


