"""Reviewable CSV/TSV ingestion and conservative public contact extraction."""
import csv
from io import StringIO
import re
from statistics import median
from decimal import Decimal
from urllib.parse import urlsplit

from .domain import COUNTRIES, LANGUAGES, code, count, identity

FIELDS = {
    "最近10条平均播放量": "recent_average", "最近10条中位播放量": "recent_median",
    "逐条播放量": "recent_samples", "统计样本数": "recent_count", "统计范围": "recent_scope",
    "工具预估报价": "estimated_quote", "实际商务一轮报价": "quote",

    "账号ID": "account_id", "账号id": "account_id", "主页链接": "url", "国家": "country",
    "联系方式": "email", "邮箱": "email", "邮箱来源": "email_url", "邮箱状态": "email_state",
    "账号类型": "account_type", "粉丝量(K)": "followers_k", "均播(K)": "views_k",
    "粉丝量": "followers", "均播": "views", "平台": "platform", "报价": "quote",
    "语言": "language", "名称": "display_name", "简介": "bio",
    "近期内容": "content_titles", "近期内容链接": "content_urls", "近期文案": "content_descriptions",
    "平台Tag": "content_tags", "日期": "submission_date", "粉丝画像": "audience",
    "画像来源": "audience_url", "合作记录": "collaboration", "账号别名": "alias",
    "BD": "bd", "bd": "bd", "BD负责人": "bd", "负责人": "bd",
}
EMAIL = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_~-]{1,64}@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")
BUSINESS = re.compile(r"\b(?:business (?:inquiries|enquiries|email|contact)|sponsorships?|partnerships?)\b|商务合作|商务邮箱", re.I)
STATES = {"verified", "not_found", "manual", "unavailable"}

def public_url(value):
    parts = urlsplit(value)
    if parts.scheme not in ("https", "http") or not parts.hostname or parts.username or parts.password:
        raise ValueError("证据来源需为完整的公开网页链接")
    return value

def recent_metrics(raw):
    samples = raw.get("recent_samples", "").split("|") if raw.get("recent_samples") else []
    if len(samples) > 10 or any(not re.fullmatch(r"[0-9]{1,15}", item.strip()) for item in samples):
        raise ValueError("逐条播放量须为 1 至 10 个非负整数，以 | 分隔")
    values = [int(item) for item in samples]
    supplied = raw.get("recent_count")
    if supplied and (not re.fullmatch(r"[1-9]|10", supplied) or values and int(supplied) != len(values)):
        raise ValueError("统计样本数须在 1 至 10，且与逐条数据一致")
    scope = raw.get("recent_scope")
    if scope and len(scope) > 160:
        raise ValueError("统计范围最多 160 字")
    result = {}
    for kind, derived in (("average", sum(values) / len(values) if values else None),
                          ("median", median(values) if values else None)):
        supplied_value = raw.get(f"recent_{kind}")
        if supplied_value and not re.fullmatch(r"[0-9]{1,15}(?:\.[0-9]{1,4})?", supplied_value):
            raise ValueError("平均及中位播放量须使用非负原始播放数")
        if values or supplied_value:
            result[f"recent_{kind}"] = {"value": round(derived, 4) if values else float(Decimal(supplied_value)),
                                       "sample_count": len(values) if values else int(supplied) if supplied else None,
                                       "scope": scope or None, "derived": bool(values)}
    return result


def normalize(raw, source, *, extract_email=True, lenient=False):
    platform_raw = raw.get("platform", "")
    platform = {"youtube": "YouTube", "yt": "YouTube", "instagram": "Instagram", "ins": "Instagram",
                "tiktok": "TikTok", "x": "X", "twitter": "X"}.get(platform_raw.casefold(), platform_raw)
    if not platform and raw.get("url"):
        from .domain import detect_platform_from_url
        platform = detect_platform_from_url(raw.get("url", "")) or ""
    identifier, url = identity(platform, raw.get("account_id", ""), raw.get("url", ""))
    email, email_url = raw.get("email", ""), raw.get("email_url", "")
    state = raw.get("email_state") or "manual"
    if state not in STATES:
        if lenient:
            state = "manual"
        else:
            raise ValueError("邮箱状态需为 verified / not_found / manual / unavailable")
    if email and not EMAIL.fullmatch(email):
        if lenient:
            email = ""
        else:
            raise ValueError("联系方式目前仅接受单个邮箱地址")
    if email_url:
        try:
            public_url(email_url)
        except ValueError:
            if lenient:
                email_url = ""
            else:
                raise
    if state == "verified" and not (email and email_url):
        if lenient:
            state = "manual"
        else:
            raise ValueError("已核实邮箱需同时提供公开来源链接")
    if email and state in ("not_found", "unavailable"):
        if lenient:
            state = "manual"
        else:
            raise ValueError("邮箱与状态冲突")
    bio = raw.get("bio", "")
    if not email and extract_email:
        candidates = set()
        for line in bio.splitlines():
            if BUSINESS.search(line):
                candidates.update(EMAIL.findall(line))
        if len(candidates) == 1:
            email, email_url, state = candidates.pop(), url, "manual"
    evidence = []
    columns = [raw.get(k, "").split("|") for k in ("content_titles", "content_urls", "content_descriptions", "content_tags")]
    for i, title in enumerate(columns[0][:15]):
        if not title.strip():
            continue
        extra = [col[i].strip() if i < len(col) else "" for col in columns[1:]]
        item_url = url
        if extra[0]:
            try:
                item_url = public_url(extra[0])
            except ValueError:
                if not lenient:
                    raise
        evidence.append({"title": title.strip()[:700], "url": item_url,
                         "description": extra[1][:1200], "tags": extra[2][:300]})
    views = count_metric(raw, "views", lenient=lenient)
    followers = count_metric(raw, "followers", lenient=lenient)
    audience = raw.get("audience") or None
    audience_url = raw.get("audience_url") or None
    if audience_url:
        try:
            public_url(audience_url)
        except ValueError:
            if lenient:
                audience_url = None
            else:
                raise
    if audience and not audience_url and not lenient:
        raise ValueError("粉丝画像需要来源")
    alias = raw.get("alias", "")
    if alias:
        if platform != "YouTube" or not identifier.startswith("UC") or not alias.startswith("@"):
            if lenient:
                alias = ""
            else:
                raise ValueError("别名仅适用于已确认频道 ID 的 YouTube @账号")
        else:
            alias = identity("YouTube", alias, "")[0]
    try:
        quote_val = parse_quote(raw.get("quote", ""))
    except ValueError:
        if lenient:
            quote_val = None
        else:
            raise
    try:
        est_quote_val = parse_quote(raw.get("estimated_quote", ""))
    except ValueError:
        if lenient:
            est_quote_val = None
        else:
            raise
    try:
        recent = recent_metrics(raw)
    except ValueError:
        if lenient:
            recent = {}
        else:
            raise
    return {
        "platform": platform, "account_id": identifier, "url": url, "alias": alias, "source": source,
        "display_name": raw.get("display_name") or identifier,
        "country": code(raw.get("country"), COUNTRIES, lenient=lenient),
        "language": code(raw.get("language"), LANGUAGES, lenient=lenient),
        "followers": followers, "views": views,
        "bio": bio, "content": evidence, "email": email or None, "email_url": email_url or None, "email_state": state,
        **{field: (raw.get(field) or "").strip() or None for field in
           ("account_type", "collaboration", "submission_date", "bd")},
        "audience": audience,
        "audience_url": audience_url,
        "quote": quote_val,
        "estimated_quote": est_quote_val,
        **recent,
    }

def count_metric(raw, key, *, lenient=False):
    if raw.get(key):
        return count(raw[key], lenient=lenient)
    value = raw.get(key + "_k", "")
    if value and not re.search(r"[A-Za-z万千]", value):
        value += "K"
    return count(value, lenient=lenient)

def parse_quote(value):
    if not value.strip():
        return None
    match = re.fullmatch(r"\s*([A-Za-z]{3}|[$€£¥])\s*(\d+(?:\.\d{1,2})?)\s*(?:[-–~至]\s*(\d+(?:\.\d{1,2})?))?\s*",
                         value.replace(",", ""))
    if not match:
        match = re.fullmatch(r"\s*(\d+(?:\.\d{1,2})?)\s*(?:[-–~至]\s*(\d+(?:\.\d{1,2})?))?\s*([A-Za-z]{3})\s*",
                             value.replace(",", ""))
        if match:
            currency, low, high = match[3], match[1], match[2]
        else:
            raise ValueError("报价格式例：USD 800 或 USD 800-1200，未知留空")
    else:
        currency, low, high = match.groups()
    currency = {"$": "USD", "€": "EUR", "£": "GBP", "¥": "CNY"}.get(currency, currency.upper())
    if high is not None and float(high) < float(low):
        raise ValueError("报价上限需不小于下限")
    return {"currency": currency, "min": float(low), "max": float(high) if high is not None else None}

def parse_table(text, *, mapping=None, limit=200):
    clean = text.strip("\ufeff\r\n ")
    first = clean.partition("\n")[0]
    reader = csv.DictReader(StringIO(clean), delimiter="\t" if "\t" in first else ",")
    headers = {name: FIELDS.get(name.strip(), name.strip()) for name in reader.fieldnames or []}
    if mapping is not None:
        headers = {name: mapping.get(name.strip(), field) for name, field in headers.items()}
        headers = {name: field for name, field in headers.items() if field is not None}
    if "platform" not in headers.values() or not {"account_id", "url"} & set(headers.values()):
        raise ValueError("表头至少需要平台，以及账号ID或主页链接")
    if len(headers.values()) != len(set(headers.values())):
        raise ValueError("存在含义重复的导入列，请保留一列")
    rows = []
    for index, row in enumerate(reader, 2):
        if index > limit + 1:
            raise ValueError("每次最多导入 200 行")
        rows.append((index, {headers[key]: (value or "").strip() for key, value in row.items() if key in headers}))
    if not rows:
        raise ValueError("表格没有数据行")
    return rows

# --- V1.3 batch import field registry -------------------------------------
# Ordered business presentation order; each entry lists the canonical field,
# Chinese header, English aliases, whether it is required, and an example.
FIELD_CATALOG = [
    ("platform", "平台", "Platform", True, "YouTube"),
    ("account_id", "账号ID", "Account ID", False, "@creatorhandle"),
    ("url", "主页链接", "Profile URL", True, "https://www.youtube.com/@creatorhandle"),
    ("display_name", "达人昵称", "Creator Name", False, "Creator Studio"),
    ("country", "国家", "Country", False, "US"),
    ("language", "语种", "Language", False, "en"),
    ("followers", "粉丝量", "Followers", False, "125000"),
    ("views", "均播", "Average Views", False, "18000"),
    ("recent_average", "最近10条平均播放量", "Recent 10 Avg Views", False, "15400"),
    ("recent_median", "最近10条中位播放量", "Recent 10 Median Views", False, "14200"),
    ("recent_samples", "逐条播放量", "View Samples", False, "12000|15000|18000"),
    ("recent_count", "统计样本数", "Sample Count", False, "3"),
    ("recent_scope", "统计范围", "Sample Scope", False, "最近10条公开视频"),
    ("quote", "实际商务一轮报价", "First Round Quote", False, "USD 1200"),
    ("estimated_quote", "工具预估报价", "Estimated Quote", False, "USD 900"),
    ("collaboration", "合作记录", "Collaboration History", False, "2026Q3 已合作"),
    ("email", "联系方式", "Email", False, "biz@example.com"),
    ("email_state", "邮箱状态", "Email Status", False, "verified"),
    ("email_url", "邮箱来源", "Email Source", False, "https://example.com/about"),
    ("account_type", "账号类型", "Account Type", False, "creator"),
    ("bio", "简介", "Bio", False, "频道简介"),
    ("content_titles", "近期内容", "Recent Content", False, "标题A|标题B"),
    ("content_urls", "近期内容链接", "Recent Content URLs", False, "https://a|https://b"),
    ("content_tags", "平台Tag", "Platform Tags", False, "AI|VFX"),
    ("audience", "粉丝画像", "Audience", False, "北美 18-34 男性"),
    ("audience_url", "画像来源", "Audience Source", False, "https://example.com/report"),
    ("alias", "账号别名", "Channel Alias", False, "@handle"),
    ("bd", "BD", "BD", False, "Alice"),
]

FIELD_KEYS = [item[0] for item in FIELD_CATALOG]
FIELD_LABELS = {key: zh for key, zh, *_ in FIELD_CATALOG}
FIELD_NOTES = {
    "followers": "支持 125000、125K、1.15K、5万、0；未知留空",
    "views": "均播为原始播放数，未知留空",
    "quote": "例 USD 800 或 USD 800-1200，也可只填数字配合默认币种",
    "email_state": "verified / not_found / manual / unavailable",
    "recent_samples": "1 至 10 个非负整数，用 | 分隔",
}

BILINGUAL_ALIASES = {
    "platform": ("平台", "platform"),
    "account_id": ("账号id", "账号", "account id", "account", "handle", "channel id"),
    "url": ("主页链接", "主页", "链接", "profile url", "profile", "url", "channel url"),
    "display_name": ("达人昵称", "昵称", "名称", "creator name", "name", "display name", "channel name"),
    "country": ("国家", "所在国家", "country", "market"),
    "language": ("语种", "语言", "language", "lang"),
    "followers": ("粉丝量", "粉丝数", "订阅数", "订阅量", "粉丝", "follower", "followers",
                  "subscribers", "subs", "follower count"),
    "followers_k": ("粉丝量(k)", "粉丝数(k)", "订阅数(k)", "followers(k)", "followers_k", "subscribers(k)"),
    "views": ("均播", "平均播放", "日常均播", "最近10条阅读", "views", "avg views", "average views"),
    "views_k": ("均播(k)", "平均播放(k)", "views(k)", "views_k", "avg views(k)"),
    "recent_average": ("最近10条平均播放量", "近10条均播", "近期平均播放量", "recent_average",
                       "recent average", "recent 10 avg views", "last 10 avg views"),
    "recent_median": ("最近10条中位播放量", "近10条中位播放", "近期中位播放量", "recent_median",
                      "recent median", "recent 10 median views", "last 10 median views"),
    "recent_samples": ("逐条播放量", "近期逐条播放", "样本播放量", "recent_samples", "recent samples", "view samples"),
    "recent_count": ("统计样本数", "样本数", "recent_count", "sample count"),
    "recent_scope": ("统计范围", "样本范围", "recent_scope", "sample scope", "scope"),
    "quote": ("实际商务一轮报价", "一轮报价", "报价", "商务报价", "人工报价", "合作报价", "quote",
              "first round quote", "actual quote", "manual quote", "rate"),
    "estimated_quote": ("工具预估报价", "预估报价", "estimated_quote", "estimated quote", "est quote"),
    "collaboration": ("合作记录", "历史合作", "合作历史", "合作备注", "collaboration",
                      "collaboration history", "cooperation"),
    "email": ("联系方式", "邮箱", "商务邮箱", "联系邮箱", "email", "contact email", "business email"),
    "email_state": ("邮箱状态", "联系方式状态", "email_state", "email status"),
    "email_url": ("邮箱来源", "联系方式来源", "email_url", "email source"),
    "account_type": ("账号类型", "达人类型", "account_type", "account type", "creator type"),
    "bio": ("简介", "个人简介", "频道简介", "bio", "biography", "description"),
    "content_titles": ("近期内容", "代表作品标题", "作品标题", "content_titles", "recent content",
                       "video titles", "evidence_title"),
    "content_urls": ("近期内容链接", "代表作品", "代表作品链接", "作品链接", "content_urls",
                     "recent content urls", "video urls", "evidence_url"),
    "content_descriptions": ("近期文案", "作品描述", "content_descriptions", "content descriptions"),
    "content_tags": ("平台tag", "内容标签", "content_tags", "platform tags"),
    "audience": ("粉丝画像", "受众画像", "audience", "audience profile"),
    "audience_url": ("画像来源", "受众来源", "audience_url", "audience source"),
    "alias": ("账号别名", "频道别名", "alias", "channel alias"),
    "submission_date": ("日期", "提报日期", "submission_date", "submission date"),
    "bd": ("bd", "bd负责人", "负责人", "对接bd", "bd owner", "owner"),
}


def resolve_header(raw_header):
    """Map a Chinese or English header to a canonical field, or None."""
    if not raw_header:
        return None
    text = str(raw_header).replace("\ufeff", "").replace("（", "(").replace("）", ")")
    text = re.sub(r"[*＊]", "", text)
    text = re.sub(r"\((?:必填|可选|required|optional)\)", "", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip().casefold()
    if not text:
        return None
    direct = FIELDS.get(text)
    if direct:
        return direct
    for field, aliases in BILINGUAL_ALIASES.items():
        if text == field or text in aliases:
            return field
    for field, aliases in BILINGUAL_ALIASES.items():
        if any(text == alias or text.startswith(alias + " ") or text.endswith(" " + alias) for alias in aliases):
            return field
    return None
