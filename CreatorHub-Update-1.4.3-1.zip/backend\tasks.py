"""A single in-process worker with transactionally persisted search checkpoints."""
from contextlib import contextmanager
from hashlib import sha256
import logging
from threading import Event, Thread
from time import monotonic

from .domain import evaluate
from .providers import ProviderError, RuleClassifier
from .store import dump, load, now

LOG = logging.getLogger("creatorhub")
ACTIVE = ("queued", "running", "paused", "blocked")
TERMINAL = ("done", "cancelled")

class Tasks:
    def __init__(self, store, provider):
        self.store, self.provider = store, provider
        self.stop = Event()
        self.wake = Event()

    def start(self):
        self.thread = Thread(target=self.run, daemon=True)
        self.thread.start()

    def close(self):
        self.stop.set()
        self.wake.set()
        self.thread.join(timeout=18)

    def enqueue(self, project, criteria, options):
        key = sha256(dump([project, criteria, options]).encode()).hexdigest()
        with self.store.connection(True) as db:
            existing = db.execute("SELECT id FROM tasks WHERE fingerprint=? AND status IN "
                                  "('queued','running','paused','blocked')", (key,)).fetchone()
            if existing:
                return {"id": existing[0], "reused": True}
            stamp = now()
            task = db.execute("INSERT INTO tasks(project,fingerprint,criteria,options,status,stage,created_at,updated_at) "
                              "VALUES(?,?,?,?,'queued','library',?,?)",
                              (project, key, dump(criteria), dump(options), stamp, stamp)).lastrowid
        self.wake.set()
        return {"id": task, "reused": False}

    def control(self, task, action):
        with self.store.connection(True) as db:
            current = db.execute("SELECT status FROM tasks WHERE id=?", (task,)).fetchone()
            if not current:
                raise KeyError("搜索任务不存在")
            current = current[0]
            if action == "pause" and current in ("queued", "running"):
                state = "paused"
            elif action == "resume" and current in ("paused", "blocked"):
                state = "queued"
            elif action == "cancel" and current not in TERMINAL:
                state = "cancelled"
            else:
                raise ValueError("任务当前状态不支持这个操作")
            db.execute("UPDATE tasks SET status=?,error=NULL,updated_at=? WHERE id=?", (state, now(), task))
        self.wake.set()

    def run(self):
        maintenance = 0
        while not self.stop.is_set():
            row = None
            try:
                with self.store.connection(True) as db:
                    if monotonic() > maintenance:
                        self.store.purge(db)
                        maintenance = monotonic() + 3600
                    row = db.execute("SELECT * FROM tasks WHERE status='queued' ORDER BY id LIMIT 1").fetchone()
                    if row:
                        db.execute("UPDATE tasks SET status='running',updated_at=? WHERE id=?", (now(), row["id"]))
                if row:
                    self.step_loop(row["id"])
                    continue
            except Exception as error:
                if not isinstance(error, ProviderError):
                    LOG.exception("Task execution failed")
                message = str(error) if isinstance(error, ProviderError) else "任务处理失败，请联系维护人员并尝试续跑"
                if row:
                    with self.store.connection(True) as db:
                        db.execute("UPDATE tasks SET status='blocked',error=?,updated_at=? "
                                   "WHERE id=? AND status='running'", (message, now(), row["id"]))
            self.wake.wait(0.8)
            self.wake.clear()

    @contextmanager
    def provider_run(self, task, operation):
        started, timestamp = monotonic(), now()
        status, message = "ok", None
        try:
            yield
        except ProviderError as error:
            status, message = "failed", str(error)
            raise
        except Exception:
            status, message = "failed", "接口结果处理失败"
            raise
        finally:
            with self.store.connection(True) as db:
                db.execute("INSERT INTO provider_runs(task,provider,operation,result,message,started_at,elapsed_ms) "
                           "VALUES(?,?,?,?,?,?,?)", (task, self.provider.source, operation, status, message,
                                                   timestamp, round((monotonic() - started) * 1000)))

    def step_loop(self, task_id):
        while not self.stop.is_set():
            with self.store.connection() as db:
                task = dict(db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone())
            if task["status"] != "running":
                return
            options, criteria = load(task["options"]), load(task["criteria"])
            stage = task["stage"]
            if stage == "library":
                self.library(task, criteria, options)
            elif stage == "discover":
                self.discover(task, criteria, options)
            elif stage == "profiles":
                self.collect(task, criteria, options)
            else:
                with self.store.connection(True) as db:
                    db.execute("UPDATE tasks SET status='done',updated_at=? WHERE id=? AND status='running'",
                               (now(), task_id))

    @staticmethod
    def allowed(db, task):
        return db.execute("SELECT status FROM tasks WHERE id=?", (task,)).fetchone()[0] in ("running", "paused", "queued")

    def library(self, task, criteria, options):
        task_id, project = task["id"], task["project"]
        with self.store.connection() as db:
            ids = [row[0] for row in db.execute("SELECT id FROM accounts WHERE workspace_id=1 AND (expires_at IS NULL OR expires_at>?) ORDER BY id DESC", (now(),))]
        imported = 0
        for account_id in ids:
            if self.stop.is_set():
                return
            with self.store.connection(True) as db:
                if db.execute("SELECT status FROM tasks WHERE id=?", (task_id,)).fetchone()[0] != "running":
                    return
                account = self.store.account(db, account_id, "match")
                if not account or account["platform"] not in options["platforms"]:
                    continue
                basis = evaluate(account, criteria, use_topics=account["source"] != "youtube_api")
                if criteria.get("topics") and not criteria.get("pending") and account["source"] != "youtube_api" and not basis["topics"]:
                    continue
                self.store.match(db, project, account_id, basis)
                if basis["state"] == "excluded":
                    continue
                db.execute("INSERT OR IGNORE INTO task_accounts VALUES(?,?)", (task_id, account_id))
                imported = db.execute("SELECT count(*) FROM task_accounts WHERE task=?", (task_id,)).fetchone()[0]
                if imported >= options["limit"]:
                    break
        live = options["discover"] and "YouTube" in options["platforms"]
        with self.store.connection(True) as db:
            db.execute("UPDATE tasks SET imported=?,stage=?,status=?,updated_at=? WHERE id=? AND status='running'",
                       (imported, "discover" if live else "complete", "running" if live else "done", now(), task_id))

    def discover(self, task, criteria, options):
        if self.provider is None:
            raise ProviderError("YouTube 待授权。库内匹配已保存，项目维护人员配置 API Key 后可续跑。")
        task_id = task["id"]
        keywords = options.get("keywords") or criteria["keywords"]
        index = task["next_keyword"]
        if index >= min(4, len(keywords)) or task["found"] >= options["limit"]:
            with self.store.connection(True) as db:
                db.execute("UPDATE tasks SET stage='profiles',updated_at=? WHERE id=?", (now(), task_id))
            return
        with self.provider_run(task_id, "search"):
            identifiers = self.provider.discover(keywords[index])
        with self.store.connection(True) as db:
            if not self.allowed(db, task_id):
                return
            remaining = options["limit"] - task["found"]
            for identifier in identifiers:
                inserted = db.execute("INSERT OR IGNORE INTO task_candidates(task,provider_id) VALUES(?,?)",
                                      (task_id, identifier)).rowcount
                remaining -= inserted
                if remaining == 0:
                    break
            db.execute("UPDATE tasks SET next_keyword=next_keyword+1,found=(SELECT count(*) FROM task_candidates "
                       "WHERE task=?),updated_at=? WHERE id=?", (task_id, now(), task_id))

    def collect(self, task, criteria, options):
        if self.provider is None:
            raise ProviderError("YouTube 待授权，配置 API Key 后可续跑")
        task_id = task["id"]
        with self.store.connection() as db:
            identifiers = [r[0] for r in db.execute("SELECT provider_id FROM task_candidates "
                                                    "WHERE task=? AND state='pending' ORDER BY rowid LIMIT 10", (task_id,))]
        if not identifiers:
            with self.store.connection(True) as db:
                db.execute("UPDATE tasks SET stage='complete',status='done',updated_at=? WHERE id=? "
                           "AND status='running'", (now(), task_id))
            return
        with self.provider_run(task_id, "channels"):
            results = list(self.provider.profiles(identifiers))
        returned = {}
        for profile in results:
            key = str(int(profile["account_id"][-8:])) if self.store.scope == "demo" else profile["account_id"]
            returned[key] = profile
        with self.store.connection(True) as db:
            if not self.allowed(db, task_id):
                return
            for identifier in identifiers:
                profile = returned.get(identifier)
                state = "failed"
                if profile:
                    tags = RuleClassifier().analyze(profile) if profile["source"] == "fixture" else []
                    account, added = self.store.save_account(db, profile, tags)
                    match = self.store.apply_match(db, task["project"], account, criteria)
                    db.execute("INSERT OR IGNORE INTO task_accounts VALUES(?,?)", (task_id, account))
                    db.execute("UPDATE tasks SET analyzed=analyzed+1,added=added+?,duplicates=duplicates+?,"
                               "eligible=eligible+? WHERE id=?",
                               (int(added), int(not added), int(match == "eligible"), task_id))
                    state = "done"
                else:
                    db.execute("UPDATE tasks SET failed=failed+1 WHERE id=?", (task_id,))
                db.execute("UPDATE task_candidates SET state=? WHERE task=? AND provider_id=?",
                           (state, task_id, identifier))
            db.execute("UPDATE tasks SET updated_at=? WHERE id=?", (now(), task_id))
