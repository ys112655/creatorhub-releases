"""Release-pinned, single-batch authorization for the live entry point."""
from hashlib import sha256
import json
from pathlib import Path
import re


ROOT = Path(r"E:\AI-Apps\Temp\CreatorHub-Pilot")
POLICY_VERSION = "B1-2026-11-20"
PROJECT = "numeric-dialect-515305-j3"
# Set only in a reviewed release once platform eligibility and both approvals exist.
APPROVED_SHA256 = None


def authorized_batch(root, batch, consent, grant):
    if (APPROVED_SHA256 is None or root.resolve() != ROOT.resolve()
            or consent != POLICY_VERSION or not re.fullmatch(r"live-[a-z0-9-]{1,48}", batch)
            or type(grant) is not bytes or sha256(grant).hexdigest() != APPROVED_SHA256):
        return False
    try:
        return json.loads(grant) == {
            "project": PROJECT, "batch": batch, "policy": POLICY_VERSION,
            "platform_eligible": True, "gpt_approved": True, "user_approved": True,
        }
    except (ValueError, UnicodeError):
        return False
