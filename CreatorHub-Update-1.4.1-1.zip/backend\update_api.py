"""Thin web-facing update endpoints.

The running app delegates to the standalone updater CLI in a subprocess, so the
app's own files are never replaced in-process. `apply` blocks until the switch
and health check complete, then returns a restart flag for the desktop shell.
"""
from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
import threading
import time
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException

from .store import Store

router = APIRouter(prefix="/api/update")

# The updater root is the directory holding versions/, data/, current and
# update_public.pem. Defaults to two levels above this backend package when
# running inside versions/<v>/backend.
def _update_root() -> Path:
    env = os.environ.get("CREATORHUB_UPDATE_ROOT")
    if env:
        return Path(env)
    here = Path(__file__).resolve()
    # .../versions/<v>/backend/update_api.py -> [1]=<v>, [2]=versions, [3]=root
    return here.parents[3]


def _cli(args: list[str]) -> dict:
    root = _update_root()
    script = root / "updater" / "update_cli.py"
    cmd = [sys.executable, str(script), *args]
    completed = subprocess.run(
        cmd,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=600,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode != 0:
        raise HTTPException(status_code=400, detail=completed.stderr.strip() or completed.stdout.strip())
    try:
        return json.loads(completed.stdout.strip())
    except json.JSONDecodeError:
        return {"raw": completed.stdout.strip()}


def _config() -> dict:
    root = _update_root()
    config = root / "update.json"
    if config.exists():
        return json.loads(config.read_text(encoding="utf-8"))
    return {}


@router.get("/info")
def update_info():
    config = _config()
    root = _update_root()
    version = {}
    marker = root / "current"
    if marker.exists():
        vdir = root / "versions" / marker.read_text(encoding="utf-8").strip() / "version.json"
        if vdir.exists():
            version = json.loads(vdir.read_text(encoding="utf-8"))
    db_path = Path(os.environ.get("CREATORHUB_DB", str(root / "data" / "trial.sqlite3")))
    v12_candidates = [
        Path.home() / "Downloads" / "CreatorHub-V1.3" / "data",
        Path.home() / "Downloads" / "CreatorHub-V1.3" / "UserData",
        Path.home() / "Downloads" / "CreatorHub-V1.2" / "UserData",
        Path.home() / "Downloads" / "CreatorHub-V1.2" / "data",
        Path(os.environ.get("LOCALAPPDATA", "")) / "CreatorHub" / "data",
    ]
    v12_detected = next((str(p) for p in v12_candidates if (p / "trial.sqlite3").is_file()), None)
    accounts_count = 0
    if db_path.is_file():
        con = sqlite3.connect(db_path)
        try:
            accounts_count = con.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        except sqlite3.Error:
            accounts_count = 0
        finally:
            con.close()
    return {
        "version": version,
        "manifest_url": config.get("manifest_url", ""),
        "v12_detected": v12_detected,
        "db_path": str(db_path),
        "accounts_count": accounts_count,
    }


@router.post("/migrate-v12")
def update_migrate_v12(payload: dict = Body(default_factory=dict)):
    root = _update_root()
    src_raw = str((payload or {}).get("source_path") or "").strip()
    if not src_raw:
        info = update_info()
        src_raw = info.get("v12_detected") or ""
    if not src_raw:
        raise HTTPException(status_code=400, detail="未检测到 V1.2 UserData 目录，请手动填写路径")
    src_path = Path(src_raw)
    src_db = src_path / "trial.sqlite3" if src_path.is_dir() else src_path
    if not src_db.is_file():
        raise HTTPException(status_code=400, detail=f"未找到 V1.2 数据库文件：{src_db}")
    dst_db = Path(os.environ.get("CREATORHUB_DB", str(root / "data" / "trial.sqlite3")))
    if src_db.resolve() == dst_db.resolve():
        raise HTTPException(status_code=400, detail="源数据库与当前数据库相同，无需迁移")
    dst_db.parent.mkdir(parents=True, exist_ok=True)
    backup_path = None
    if dst_db.is_file():
        ts = time.strftime("%Y%m%d-%H%M%S")
        backup_path = root / "backups" / f"pre-v12-migrate-{ts}" / "trial.sqlite3"
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        s_con = sqlite3.connect(f"file:{dst_db}?mode=ro", uri=True)
        b_con = sqlite3.connect(backup_path)
        try:
            s_con.backup(b_con)
        finally:
            b_con.close()
            s_con.close()
    for sidecar in (dst_db.with_name(dst_db.name + "-wal"), dst_db.with_name(dst_db.name + "-shm")):
        sidecar.unlink(missing_ok=True)
    src_con = sqlite3.connect(f"file:{src_db}?mode=ro", uri=True)
    dst_con = sqlite3.connect(dst_db)
    try:
        src_con.backup(dst_con)
    finally:
        dst_con.close()
        src_con.close()
    store = Store(dst_db)
    store.setup()  # upgrade imported V1.2/V1.3 schema to the current version in place
    con = sqlite3.connect(dst_db)
    try:
        accounts = con.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        projects = con.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
    finally:
        con.close()
    return {
        "migrated_from": str(src_db),
        "backup_path": str(backup_path) if backup_path else None,
        "accounts_count": accounts,
        "projects_count": projects,
        "store_ready": bool(store),
    }


@router.post("/restart")
def update_restart():
    root = _update_root()
    (root / "restart.requested").write_text("1", encoding="utf-8")
    threading.Timer(0.25, lambda: os._exit(0)).start()
    return {"restarting": True}


@router.post("/check")
def update_check():
    config = _config()
    if not config.get("manifest_url"):
        raise HTTPException(status_code=400, detail="未配置更新清单地址")
    return _cli(["check", "--root", str(_update_root()), "--manifest", config["manifest_url"]])


@router.post("/apply")
def update_apply(overwrite: bool = False):
    config = _config()
    if not config.get("manifest_url"):
        raise HTTPException(status_code=400, detail="未配置更新清单地址")
    args = ["update", "--root", str(_update_root()), "--manifest", config["manifest_url"]]
    if overwrite:
        args.append("--overwrite")
    result = _cli(args)
    result["restart"] = True
    return result


@router.get("/status")
def update_status():
    root = _update_root()
    state = root / "update_state.json"
    if state.exists():
        return json.loads(state.read_text(encoding="utf-8"))
    return {"stage": "idle"}
