"""Single-origin app for a private local SQLite workspace."""
from contextlib import asynccontextmanager
from datetime import date, datetime, timezone
from io import BytesIO, StringIO
from pathlib import Path
import sqlite3
import csv
import logging
import os
from time import monotonic
from typing import Literal
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from openpyxl import Workbook
from pydantic import BaseModel, Field

from .domain import DIMENSIONS, PLATFORMS, COUNTRIES, LANGUAGES, code, count, evaluate, parse_brief
from .imports import parse_table, public_url
from .permissions import ImportPolicy, governed_profile, prepare_policy
from .providers import Demo, ProviderError, configured_model
from .store import Store, dump, load, now
from .tasks import Tasks
from . import batch_import
from . import freshness
from . import refresh
from . import update_api
from . import discovery
from . import intelligent_discovery
from . import intake

ROOT = Path(__file__).resolve().parents[1]
HEADERS = ("日期", "账号ID", "主页链接", "国家", "联系方式", "账号类型", "粉丝量(K)", "均播(K)", "平台", "报价", "BD")
FIELDS = {"min_followers", "max_followers", "email", "countries", "languages"}
LOG = logging.getLogger("creatorhub")

def read_local_env():
    path = ROOT / ".env"
    if path.is_file():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            key, sep, value = line.strip().partition("=")
            if sep and key in ("MINIMAX_API_KEY", "MINIMAX_ENABLE_INCLUDED_QUOTA",
                               "MINIMAX_REGION", "MINIMAX_MODEL"):
                os.environ.setdefault(key, value.strip().strip('"').strip("'"))

class PortraitRequest(BaseModel):
    allow_model: bool = False


class DiscoveryBrief(BaseModel):
    brief: str = Field(min_length=1, max_length=3000)
    platforms: list[Literal["YouTube", "Instagram", "TikTok", "X"]] | None = None


class DiscoveryText(BaseModel):
    text: str = Field(min_length=1, max_length=200_000)


class DiscoveryCandidate(BaseModel):
    platform: Literal["YouTube", "Instagram", "TikTok", "X"]
    account_id: str = Field(min_length=1, max_length=200)
    url: str = Field(min_length=8, max_length=2048)
    display_name: str = Field(min_length=1, max_length=200)
    followers: int | None = Field(default=None, ge=0, le=10**12)
    language: str | None = Field(default=None, max_length=20)
    creator_location: str | None = Field(default=None, max_length=80)
    audience_region: str | None = Field(default=None, max_length=80)
    evidence_url: str | None = Field(default=None, max_length=2048)
    evidence_title: str | None = Field(default=None, max_length=300)
    vertical: str | None = Field(default=None, max_length=40)
    status: str = Field(default="pending", max_length=20)
    discovered_at: str | None = Field(default=None, max_length=20)
    source: str = Field(default="operator_paste", max_length=40)


class DiscoveryApply(BaseModel):
    project: int
    candidates: list[DiscoveryCandidate] = Field(default_factory=list, max_length=200)
    existing_accounts: list[int] = Field(default_factory=list, max_length=200)
    # No defaults: the operator must state the source and the permission basis,
    # and must tick the confirmation box before anything is written.
    source_name: str = Field(min_length=1, max_length=120)
    permission: str = Field(min_length=1, max_length=500)
    operator: str = Field(min_length=1, max_length=120)
    # Chosen by the operator; no implicit export permission for internal-only data.
    purposes: list[Literal["view", "match", "export"]] = Field(min_length=1, max_length=3)
    confirmed: bool


class Brief(BaseModel):
    allow_model: bool = False
    brief: str = Field(min_length=1, max_length=3000)

class Project(Brief):
    name: str = Field(min_length=1, max_length=100)
    criteria: dict | None = None

class Start(BaseModel):
    project: int
    platforms: list[Literal["YouTube", "Instagram", "TikTok", "X"]] = Field(min_length=1, max_length=4)
    limit: int = Field(ge=1, le=50)
    discover: bool = False
    keywords: list[str] = Field(default_factory=list, max_length=4)
    manual_confirmation: bool = False

class Control(BaseModel):
    action: Literal["pause", "resume", "cancel"]

class Import(BaseModel):
    text: str = Field(min_length=1, max_length=650000)
    source: Literal["independent", "authorized"]
    confirmed: bool
    policy: ImportPolicy

class ManualTag(BaseModel):
    dimension: str
    label: str = Field(min_length=1, max_length=60)
    tier: Literal["core", "secondary"]
    url: str = Field(min_length=1, max_length=1200)
    basis: str = Field(min_length=1, max_length=500)

class Review(BaseModel):
    status: Literal["pending", "accepted", "rejected", "submitted"]
    note: str = Field(default="", max_length=1000)
    evidence_verified: bool = False


class FreshnessUpdate(BaseModel):
    ttls: dict[str, int | None]


class RefreshRequest(BaseModel):
    account_ids: list[int] = Field(min_length=1, max_length=200)
    project_id: int | None = None
    mode: Literal["public_feed", "mock"] = "public_feed"
    fields: list[str] | None = None
    force: bool = False
    budget_limit: int = Field(default=50, ge=1, le=200)


class RefreshControl(BaseModel):
    action: Literal["cancel", "retry"]


class ManualTemplateRequest(BaseModel):
    account_ids: list[int] = Field(min_length=1, max_length=500)

def clean_criteria(value):
    for group in ("hard", "preferences"):
        if not isinstance(value.get(group), dict) or not set(value[group]).issubset(FIELDS):
            raise ValueError("筛选字段无效")
        for key, condition in value[group].items():
            if key == "email" and condition is not True:
                raise ValueError("邮箱筛选值无效")
            if key in ("min_followers", "max_followers") and (type(condition) is not int or condition < 0):
                raise ValueError("粉丝门槛须为非负整数")
            if key in ("countries", "languages") and (not isinstance(condition, list) or len(condition) > 60 or
                                                       any(not isinstance(s, str) or len(s) > 8 for s in condition)):
                raise ValueError("地区或语言条件无效")
        if value[group].get("min_followers", 0) > value[group].get("max_followers", 10**12):
            raise ValueError("粉丝范围上下限冲突")
    topics, keywords = value.get("topics"), value.get("keywords")
    if (not isinstance(topics, list) or len(topics) > 60 or any(
            not isinstance(t, dict) or t.get("dimension") not in DIMENSIONS or
            not isinstance(t.get("label"), str) or not 1 <= len(t["label"]) <= 60 or
            not isinstance(t.get("preferred"), bool) for t in topics)):
        raise ValueError("标签筛选值无效")
    if not isinstance(keywords, list) or len(keywords) > 16 or any(not isinstance(k, str) or len(k) > 120 for k in keywords):
        raise ValueError("搜索关键词无效")
    return {key: value[key] for key in ("hard", "preferences", "topics", "keywords")}


def project_criteria(brief, submitted):
    baseline = parse_brief(brief)
    edited = clean_criteria(submitted if submitted is not None else baseline)
    if baseline["pending"]:
        edited["pending"] = baseline["pending"]
    if baseline["groups"]:
        edited["groups"] = baseline["groups"]
    if any(p["label"] == "地区组合" for p in baseline["pending"]) and "countries" in edited["hard"]:
        raise ValueError("该需求有无法直接表示的地区组合，请逐项人工核验")
    if baseline["groups"] or any("分类门槛" in p["label"] or "冲突" in p["label"]
                                 for p in baseline["pending"]):
        for key in ("min_followers", "max_followers"):
            if key in edited["hard"]:
                raise ValueError("请先核对分类或冲突门槛；本次只按可执行条件匹配")
    return edited

def get_project(db, identifier):
    item = db.execute("SELECT * FROM projects WHERE id=? AND workspace_id=1", (identifier,)).fetchone()
    if not item:
        raise HTTPException(404, "项目不存在")
    return {**dict(item), "criteria": load(item["criteria"])}

def task_dict(row):
    result = dict(row)
    result["options"] = load(result["options"])
    result.pop("fingerprint")
    result.pop("criteria")
    return result

def spreadsheet_cell(value):
    # Spreadsheet apps interpret formula-like imports on open, including in CSV.
    if isinstance(value, str) and value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return "'" + value
    return value

def export_row(account, fallback):
    raw, contact = account["raw"], account["contact"] or {}
    quote = raw.get("quote")
    price = ""
    if quote:
        price = f"{quote['currency']} {quote['min']:g}"
        if quote["max"] is not None:
            price += f"-{quote['max']:g}"
    return [account.get("submission_date") or raw.get("submission_date") or fallback or "",
            account["account_id"], account["url"], account["country"] or "",
            (contact.get("email") or "") if contact.get("state") == "verified" else "",
            raw.get("account_type") or "", None if account["followers"] is None else account["followers"] / 1000,
            None if account["views"] is None else account["views"] / 1000, account["platform"], price,
            account.get("bd") or raw.get("bd") or ""]

def render_export(rows, fmt):
    if fmt == "xlsx":
        book = Workbook()
        page = book.active
        page.title = "达人提报"
        page.append(HEADERS)
        for row_index, row in enumerate(rows, start=2):
            for column, value in enumerate(row, start=1):
                cell = page.cell(row_index, column, value)
                if isinstance(value, str):
                    cell.data_type = "s"
        page.freeze_panes = "A2"
        page.auto_filter.ref = page.dimensions
        for column, width in zip("ABCDEFGHIJK", (15, 26, 56, 10, 32, 16, 14, 14, 15, 21, 16)):
            page.column_dimensions[column].width = width
        stream = BytesIO()
        book.save(stream)
        return stream.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    stream = StringIO(newline="")
    writer = csv.writer(stream, delimiter="\t" if fmt == "tsv" else ",")
    writer.writerow(HEADERS)
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8-sig" if fmt == "csv" else "utf-8"), \
        ("text/tab-separated-values; charset=utf-8" if fmt == "tsv" else "text/csv; charset=utf-8")

def create_app(path=None, demo=False, provider=None, model=None, brief_model=None, model_service=None):
    if path is None:
        path = ROOT / "var" / ("demo.sqlite3" if demo else "creatorhub.sqlite3")
    store = Store(path, demo)
    tasks = Tasks(store, provider)
    refresher = refresh.RefreshService(store)
    v14_discovery = intelligent_discovery.IntelligentDiscoveryService(store)

    @asynccontextmanager
    async def lifespan(api):
        store.setup()
        if model_service:
            model_service.setup()
        tasks.start()
        refresher.start()
        try:
            yield
        finally:
            refresher.close()
            tasks.close()

    api = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

    @api.middleware("http")
    async def local_boundaries(request: Request, next_handler):
        host = request.headers.get("host", "")
        if host.partition(":")[0] not in ("127.0.0.1", "localhost", "testserver"):
            return JSONResponse({"detail": "当前版本仅支持本机访问"}, status_code=403)
        origin = request.headers.get("origin")
        if request.method not in ("GET", "HEAD") and (
                (origin and origin != "http://" + host) or request.headers.get("sec-fetch-site") == "cross-site"):
            return JSONResponse({"detail": "仅允许在本机应用内操作"}, status_code=403)
        result = await next_handler(request)
        result.headers["Cache-Control"] = "no-store"
        result.headers["X-Content-Type-Options"] = "nosniff"
        result.headers["Content-Security-Policy"] = (
            "default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        return result

    @api.exception_handler(ValueError)
    async def bad_input(request, exc):
        return JSONResponse({"detail": str(exc)}, status_code=400)

    @api.exception_handler(KeyError)
    async def missing(request, exc):
        return JSONResponse({"detail": str(exc.args[0])}, status_code=404)

    @api.get("/api/meta")
    def meta():
        return {"demo": demo, "platforms": dict.fromkeys(PLATFORMS, "仅库内"),
                "youtube": "模拟" if demo else "已配置，待调用" if provider else "待授权",
                "structured_model": bool(model_service), "model": model.name if model else "规则分类 rules-v1", "dimensions": DIMENSIONS,
                "countries": {k: v[0] for k, v in COUNTRIES.items()},
                "languages": {k: v[0] for k, v in LANGUAGES.items()}}

    from .brief_adapter import BriefAdapter
    parser = BriefAdapter(brief_model)
    live_parser = (BriefAdapter(model_service.brief, limit=None, timeout=model_service.timeout + 1,
                                source=model_service.provider.source) if model_service else None)

    @api.post("/api/parse")
    async def parse(body: Brief):
        if body.allow_model and live_parser:
            return await live_parser.parse(body.brief)
        return await parser.parse(body.brief)

    @api.get("/api/projects")
    def projects():
        with store.connection(True) as db:
            store.purge(db)
            items = []
            for row in db.execute("SELECT id,name,brief,created_at FROM projects WHERE workspace_id=1 ORDER BY id DESC"):
                matches = [match["status"] for match in db.execute(
                    "SELECT account,status FROM matches WHERE project=?", (row["id"],)
                ) if store.account(db, match["account"])]
                items.append({**dict(row), "total": len(matches),
                              "accepted": sum(status in ("accepted", "submitted") for status in matches)})
            return items

    @api.post("/api/projects")
    def add_project(body: Project):
        name, brief = body.name.strip(), body.brief.strip()
        if not name or not brief:
            raise ValueError("请输入项目名和品牌需求")
        criteria = project_criteria(brief, body.criteria)
        with store.connection(True) as db:
            identifier = db.execute("INSERT INTO projects(workspace_id,name,brief,criteria,created_at) VALUES(1,?,?,?,?)",
                                    (name, brief, dump(criteria), now())).lastrowid
        return {"id": identifier}

    @api.put("/api/projects/{project}")
    def update_project(project: int, body: Project):
        name, brief = body.name.strip(), body.brief.strip()
        if not name or not brief:
            raise ValueError("请输入项目名和品牌需求")
        criteria = project_criteria(brief, body.criteria)
        with store.connection(True) as db:
            get_project(db, project)
            db.execute("UPDATE projects SET name=?,brief=?,criteria=? WHERE id=?",
                       (name, brief, dump(criteria), project))
        return {"id": project}

    @api.get("/api/projects/{project}")
    def detail_project(project: int):
        return project_detail(project, "view")

    def project_detail(project, purpose):
        with store.connection(True) as db:
            store.purge(db)
            item = get_project(db, project)
            item["tasks"] = [task_dict(t) for t in db.execute(
                "SELECT * FROM tasks WHERE project=? ORDER BY id DESC LIMIT 20", (project,))]
            item["matches"] = []
            for row in db.execute("SELECT * FROM matches WHERE project=? ORDER BY CASE status "
                                  "WHEN 'pending' THEN 0 WHEN 'accepted' THEN 1 WHEN 'submitted' THEN 2 ELSE 3 END, account DESC", (project,)):
                account = store.account(db, row["account"], purpose)
                if account:
                    candidate = store.account(db, row["account"], "view+match") if purpose == "view" else None
                    stored_basis = load(row["basis"]) if row["basis"] else {}
                    basis = (evaluate(candidate, item["criteria"]) if candidate else {})
                    f_state = freshness.compute_freshness(db, account)
                    if basis:
                        basis["used_values"] = stored_basis.get("used_values") or freshness.match_snapshot(candidate, f_state)
                        if stored_basis.get("near_threshold"):
                            basis["near_threshold"] = True
                    account["freshness"] = {
                        "overall_status": f_state["overall_status"],
                        "stale_fields": f_state["stale_fields"],
                        "missing_fields": f_state["missing_fields"],
                        "failed_fields": f_state["failed_fields"],
                        "needs_refresh": f_state["needs_refresh"],
                    }
                    item["matches"].append({"account": account, "status": row["status"], "basis": basis,
                                            "note": row["review_note"], "submission_date": row["submission_date"]})
            return item

    @api.patch("/api/projects/{project}/matches/{account}")
    def review(project: int, account: int, body: Review):
        with store.connection(True) as db:
            item = get_project(db, project)
            if db.execute("SELECT 1 FROM project_intake WHERE project=? AND account=?", (project, account)).fetchone():
                raise ValueError("Please use the project intake review for this record")
            candidate = store.account(db, account)
            if not candidate:
                raise KeyError("达人不存在或数据已过期")
            note = body.note
            if item["criteria"].get("pending") and body.status in ("accepted", "submitted"):
                basis = evaluate(store.account(db, account, "view+match") or {}, item["criteria"])
                if (not body.evidence_verified or not note.strip() or basis["failed"]
                        or not candidate["raw"].get("content") or candidate["followers"] is None):
                    raise ValueError("请补充作品证据、粉丝量和核验备注，再确认未核验条件均已通过")
                note = "【证据已人工核验】" + note
            if not db.execute("UPDATE matches SET status=?,review_note=?,submission_date=? WHERE project=? AND account=?",
                              (body.status, note, date.today().isoformat() if body.status == "submitted" else None,
                               project, account)).rowcount:
                raise KeyError("项目匹配不存在")
            db.execute("INSERT INTO review_history(project,account,status,note,recorded_at) VALUES(?,?,?,?,?)",
                       (project, account, body.status, note, now()))
        return {"ok": True}

    @api.post("/api/tasks")
    def add_task(body: Start):
        with store.connection() as db:
            project = get_project(db, body.project)
        unresolved = project["criteria"].get("pending") or parse_brief(project["brief"])["pending"]
        if unresolved and not project["criteria"].get("pending"):
            raise ValueError("该项目采用旧版条件，请重新保存需求后再匹配")
        if unresolved and (not body.manual_confirmation or body.discover):
            raise ValueError("有待核验条件，请先确认仅匹配已有达人并人工核验")
        keywords = list(dict.fromkeys(k.strip() for k in body.keywords if k.strip()))
        if any(len(k) > 120 for k in keywords):
            raise ValueError("单条关键词最多 120 个字符")
        if body.discover and "YouTube" not in body.platforms:
            raise ValueError("所选平台尚未接入新达人发现，请使用库内搜索")
        return tasks.enqueue(body.project, project["criteria"],
                             {"platforms": sorted(set(body.platforms)), "limit": body.limit,
                              "discover": body.discover, "keywords": keywords})

    @api.get("/api/tasks/{task}")
    def get_task(task: int):
        with store.connection() as db:
            row = db.execute("SELECT * FROM tasks WHERE id=?", (task,)).fetchone()
            if not row:
                raise KeyError("搜索任务不存在")
            item = task_dict(row)
            item["calls"] = [dict(value) for value in db.execute(
                "SELECT provider,operation,result,count(*) AS total, sum(elapsed_ms) elapsed_ms "
                "FROM provider_runs WHERE task=? GROUP BY provider,operation,result", (task,))]
            return item

    @api.patch("/api/tasks/{task}")
    def change_task(task: int, body: Control):
        tasks.control(task, body.action)
        return get_task(task)

    @api.get("/api/accounts")
    def accounts(query: str = Query("", max_length=150), platform: str = "", country: str = "", language: str = "",
                 followers: str = "", views: str = "", email_state: str = "", tag: str = Query("", max_length=100),
                 bd: str = "",
                 limit: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0)):
        filters = dict(query=query, platform=platform, country=code(country, COUNTRIES),
                       language=code(language, LANGUAGES), followers=count(followers), views=count(views),
                       email_state=email_state, tag=tag, bd=bd, limit=limit, offset=offset)
        with store.connection(True) as db:
            store.purge(db)
            res = store.find_accounts(db, filters)
            ttls = freshness.get_ttl_settings(db)
            for item in res["items"]:
                if item:
                    f_state = freshness.compute_freshness(db, item, ttls)
                    item["freshness"] = {
                        "overall_status": f_state["overall_status"],
                        "stale_fields": f_state["stale_fields"],
                        "missing_fields": f_state["missing_fields"],
                        "failed_fields": f_state["failed_fields"],
                        "needs_refresh": f_state["needs_refresh"],
                    }
            return res

    @api.get("/api/accounts/{identifier}")
    def detail_account(identifier: int):
        with store.connection(True) as db:
            store.purge(db)
            account = store.account(db, identifier)
            if not account:
                raise KeyError("达人不存在或数据已过期")
            account["freshness"] = freshness.compute_freshness(db, account)
            return account

    @api.put("/api/accounts/{identifier}/bd")
    def update_bd(identifier: int, body: dict):
        if demo:
            raise ValueError("演示库不支持修改 BD")
        with store.connection(True) as db:
            updated = store.update_account_bd(db, identifier, str(body.get("bd") or ""))
        return {"ok": True, "bd": updated}

    @api.post("/api/accounts/import")
    def import_accounts(body: Import):
        if demo:
            raise ValueError("演示库只接收模拟数据，请使用业务版导入")
        if not body.confirmed:
            raise ValueError("请确认有权在 CreatorHub 保存这些资料")
        table = parse_table(body.text)
        grant = prepare_policy(body.policy, datetime.now(timezone.utc).date())
        batch_id = uuid4().hex
        totals = dict(added=0, duplicates=0, rejected=[], preserved_provider=0)
        with store.connection(True) as db:
            store.purge(db)
            for line, row in table:
                db.execute("SAVEPOINT import_row")
                try:
                    profile = governed_profile(row, body.source, grant, f"{batch_id}:{line}")
                    account, added = store.save_account(db, profile)
                    if db.execute("SELECT source FROM accounts WHERE id=?", (account,)).fetchone()[0] == "youtube_api":
                        totals["preserved_provider"] += 1
                    totals["added" if added else "duplicates"] += 1
                except (ValueError, OverflowError) as error:
                    db.execute("ROLLBACK TO import_row")
                    totals["rejected"].append({"line": line, "reason": str(error)})
                finally:
                    db.execute("RELEASE import_row")
            totals["receipt_id"] = db.execute(
                "INSERT INTO import_history(policy,result,recorded_at) VALUES(?,?,?)",
                (dump({**grant[0], "source": body.source, "batch_id": batch_id}), dump(totals), now()),
            ).lastrowid
        return totals

    @api.put("/api/accounts/{identifier}/tags")
    def edit_tag(identifier: int, body: ManualTag):
        label = body.label.strip()
        if body.dimension not in DIMENSIONS or not label or not body.basis.strip():
            raise ValueError("标签维度、名称或依据无效")
        public_url(body.url)
        with store.connection(True) as db:
            account = store.account(db, identifier)
            if not account:
                raise KeyError("达人不存在")
            if account["raw"].get("provenance"):
                raise ValueError("受治理账号仅可使用有授权依据的规则标签")
            db.execute("INSERT OR REPLACE INTO analyses VALUES(?,?,?,?,?,?)",
                       (identifier, body.dimension, label, body.tier, "manual",
                        dump([{"title": body.basis, "url": body.url, "kind": "review"}])))
        return detail_account(identifier)

    @api.delete("/api/accounts/{identifier}/tags")
    def delete_tag(identifier: int, dimension: str, label: str, model_name: str):
        with store.connection(True) as db:
            if not store.account(db, identifier):
                raise KeyError("达人不存在")
            db.execute("DELETE FROM analyses WHERE account=? AND dimension=? AND label=?",
                       (identifier, dimension, label))
        return detail_account(identifier)

    @api.post("/api/accounts/{identifier}/analyze")
    def analyze(identifier: int):
        if not model:
            raise ValueError("MiniMax 待授权，规则分类已用于导入和演示")
        account = detail_account(identifier)
        if account["source"] != "independent" or account["raw"].get("provenance"):
            raise ValueError("仅由独立公开来源导入的资料可提交给 MiniMax")
        timestamp, started = now(), monotonic()
        status, message = "ok", None
        try:
            tags = model.analyze({**account["raw"], "url": account["url"]})
            with store.connection(True) as db:
                current = store.account(db, identifier)
                if not current or current["raw"] != account["raw"]:
                    raise ProviderError("分析期间资料已更新，请重新分析")
                store.save_tags(db, identifier, tags, model.name)
        except ProviderError as error:
            status, message = "failed", str(error)
            raise HTTPException(502, message) from None
        finally:
            with store.connection(True) as db:
                db.execute("INSERT INTO provider_runs(account,provider,operation,result,message,started_at,elapsed_ms) VALUES(?,?,?,?,?,?,?)",
                           (identifier, model.name, "classify", status, message, timestamp, round((monotonic() - started) * 1000)))
        return detail_account(identifier)

    @api.get("/api/intake/templates")
    def intake_templates():
        with store.connection() as db:
            return {row["name"]: load(row["settings"]) for row in db.execute("SELECT * FROM intake_templates")}

    @api.get("/api/intake/{project}/metrics")
    def get_metrics(project: int):
        with store.connection() as db:
            get_project(db, project)
            config = intake.metric_config(db, project)
            return dict(config) if config else {"stat": None, "minimum": None}

    @api.put("/api/intake/{project}/metrics")
    def set_metrics(project: int, body: intake.ProjectMetrics):
        with store.connection(True) as db:
            get_project(db, project)
            db.execute("INSERT INTO project_metrics VALUES(?,?,?) ON CONFLICT(project) "
                       "DO UPDATE SET stat=excluded.stat,minimum=excluded.minimum",
                       (project, body.stat, body.minimum))
        return body

    @api.post("/api/intake/{project}")
    def batch_intake(project: int, body: intake.Intake):
        if demo:
            raise ValueError("Project intake requires the private workspace")
        with store.connection(True) as db:
            store.purge(db)
            return intake.import_rows(db, store, get_project(db, project), body)

    @api.get("/api/intake/{project}")
    def intake_detail(project: int):
        with store.connection(True) as db:
            store.purge(db)
            item = get_project(db, project)
            return [result for record in intake.records(db, project)
                    if (result := intake.information(store, db, item, record, "view"))]

    @api.post("/api/intake/{project}/portrait/{account_id}")
    async def intake_portrait(project: int, account_id: int, body: PortraitRequest):
        with store.connection(True) as db:
            store.purge(db)
            item = get_project(db, project)
            record = next((row for row in intake.records(db, project) if row["account"] == account_id), None)
            candidate = intake.information(store, db, item, record, "view+match") if record else None
            if not candidate:
                raise KeyError("Candidate is unavailable")
            fallback = {"source": "rules", "suggestion": candidate["suggestion"],
                        "reasons": candidate["basis"].get("topics", []), "evidence": [],
                        "mismatches": candidate["basis"]["failed"], "missing": candidate["missing"]}
            account = store.account(db, account_id, "view+match")
            # Only send material whose grant independently permits this exact use.
            raw = account["raw"]
            grants = raw.get("provenance", {}).get("fields", {})
            grant = grants.get("content", {})
            evidence = candidate["content"][:6]
            if (not model_service or not body.allow_model or not evidence or
                    "model" not in grant.get("purposes", [])):
                return fallback
            values = {
                "platform": account.get("platform"),
                "bio": raw.get("bio"),
                "followers": account.get("followers"),
                "recent_average": raw.get("recent_average"),
                "recent_median": raw.get("recent_median"),
            }
            context = {name: value for name, value in values.items()
                       if value is not None and value != "" and "model" in grants.get(name, {}).get("purposes", [])}
            for name in ("followers", "recent_average", "recent_median"):
                if name in context:
                    value = context[name]
                    provenance = grants[name]
                    context[name] = {
                        **(value if isinstance(value, dict) else {"value": value}),
                        "statistic": {"followers": "count", "recent_average": "mean",
                                      "recent_median": "median"}[name],
                        "source": provenance.get("source_name"),
                        "acquired_on": provenance.get("acquired_on"),
                        "record_updated_at": account.get("updated_at"),
                    }
        try:
            result = await model_service.portrait(item["brief"], evidence, context)
        except (TimeoutError, RuntimeError, ValueError, OSError, sqlite3.Error) as error:
            from .model_api import fallback_reason
            reason = fallback_reason(error)
            LOG.warning("portrait model fallback: %s", reason)
            return {**fallback, "source": "rules_fallback", "fallback_reason": reason}
        if candidate["suggestion"] != "submit" and result["suggestion"] == "submit":
            result["suggestion"] = candidate["suggestion"]
            result["missing"] = list(dict.fromkeys(result["missing"] + candidate["missing"]))
        return {**result, "source": model_service.provider.source,
                "evidence": [evidence[index-1] for index in result["evidence"]]}

    @api.post("/api/intake/{project}/review")
    def intake_review(project: int, body: intake.Decision):
        with store.connection(True) as db:
            store.purge(db)
            return intake.decide(store, db, get_project(db, project), body)

    @api.post("/api/intake/{project}/output")
    def intake_output(project: int, body: intake.Output):
        with store.connection(True) as db:
            store.purge(db)
            item = get_project(db, project)
            wanted = set(body.accounts)
            rows = []
            formulas = set(body.formula_columns)
            for record in intake.records(db, project):
                if record["account"] not in wanted:
                    continue
                candidate = intake.information(store, db, item, record, "view+export")
                if not candidate:
                    continue
                verified = (candidate["suggestion"] == "submit" and candidate["current_confirmation"]
                            and candidate["status"] in ("accepted", "submitted"))
                if (body.preliminary and (verified or candidate["suggestion"] != "hold"
                                          or candidate["status"] == "rejected")) or (not body.preliminary and not verified):
                    continue
                if body.preliminary:
                    candidate["values"][0] = "PREVIEW ONLY | " + candidate["values"][0]
                    candidate["values"][10] = "PREVIEW ONLY | " + candidate["values"][10]
                formulas.update(candidate["formula_columns"])
                rows.append(candidate["values"])
        return intake.output(rows, formulas, spreadsheet_cell, body.preliminary)

    @api.get("/api/projects/{project}/export")
    def export(project: int, fmt: Literal["xlsx", "csv", "tsv"] = "xlsx", approved: bool = True,
               preview: bool = False):
        item = project_detail(project, "export")
        rows = []
        with store.connection() as db:
            intake_accounts = {record["account"]: intake.information(store, db, item, record, "view+export")
                               for record in intake.records(db, project)}
        evidence_gate = bool(item["criteria"].get("pending") or parse_brief(item["brief"])["pending"])
        for match in item["matches"]:
            identifier = match["account"]["id"]
            if identifier in intake_accounts:
                candidate = intake_accounts[identifier]
                if not candidate or not (candidate["current_confirmation"] and candidate["suggestion"] == "submit"
                                         and candidate["status"] in ("accepted", "submitted")):
                    continue
            elif evidence_gate and (match["status"] not in ("accepted", "submitted")
                                  or not match["note"].startswith("【证据已人工核验】")):
                continue
            account = match["account"]
            if (approved and match["status"] not in ("accepted", "submitted")) or account["source"] == "youtube_api":
                continue
            row = export_row({**account, "submission_date": match["submission_date"]}, None)
            rows.append(row if fmt == "xlsx" or preview else [spreadsheet_cell(cell) for cell in row])
        if preview:
            return {"columns": HEADERS, "count": len(rows),
                    "missing": [sum(row[i] in (None, "") for row in rows) for i in range(len(HEADERS))]}
        filename = ("demo-" if demo else "") + f"creatorhub-project-{project}.{fmt}"
        body, mime = render_export(rows, fmt)
        return Response(body, media_type=mime, headers={"Content-Disposition": 'attachment; filename="' + filename + '"',
                                                        "X-CreatorHub-Rows": str(len(rows))})

    api.mount("/assets", StaticFiles(directory=ROOT / "frontend"), name="assets")

    @api.post("/api/discovery/suggest")
    def discovery_suggest(body: DiscoveryBrief):
        return discovery.suggest_keywords(body.brief, body.platforms)

    @api.post("/api/discovery/parse")
    def discovery_parse(body: DiscoveryText):
        with store.connection(True) as db:
            store.purge(db)
            rows = db.execute("SELECT platform, account_id, id FROM accounts").fetchall()
        known = {(platform, str(account).casefold()): identifier for platform, account, identifier in rows}
        return discovery.parse_candidates(body.text, known)

    @api.post("/api/discovery/apply")
    def discovery_apply(body: DiscoveryApply):
        if demo:
            raise ValueError("Project intake requires the private workspace")
        if not body.confirmed:
            raise ValueError("请先确认资料来源与使用权限")
        today = date.today()
        with store.connection(True) as db:
            store.purge(db)
            project = get_project(db, body.project)
            payload = [item.model_dump() for item in body.candidates]
            for item in payload:
                item["confirmed"] = True
            result = {"added": 0, "duplicates": 0, "rejected": [], "existing_linked": 0}
            if payload:
                text = discovery.build_csv(payload)
                intake_body = intake.Intake(
                    text=text, confirmed=True, source="independent",
                    settings=intake.Settings(currency="USD", formula_columns=[]),
                    policy=ImportPolicy(
                        source_name=body.source_name, permission=body.permission,
                        effective_on=today, acquired_on=today,
                        expires_on=date.fromordinal(today.toordinal() + 7),
                        deletion_owner=body.operator,
                        allowed_fields=discovery.CSV_FIELDS.split(","),
                        purposes=list(dict.fromkeys(body.purposes))))
                result.update(intake.import_rows(db, store, project, intake_body))
            result["existing_skipped"] = 0
            for account in body.existing_accounts:
                # Reuse keeps the account's original grants: if it is not licensed
                # for matching, it must not be pulled into a new project here.
                profile = store.account(db, account, "view+match")
                if not profile:
                    result["existing_skipped"] += 1
                    continue
                db.execute("INSERT OR IGNORE INTO project_intake(project,account,settings) VALUES(?,?,?)",
                           (project["id"], account, dump({"reading_stat": "unknown", "verified_views": None})))
                db.execute("INSERT OR IGNORE INTO matches(project,account,basis) VALUES(?,?,?)",
                           (project["id"], account, dump(evaluate(profile, project["criteria"]))))
                result["existing_linked"] += 1
            accounts = {}
            for row in db.execute("SELECT a.platform, a.account_id, a.id FROM accounts a "
                                  "JOIN project_intake p ON p.account=a.id WHERE p.project=?",
                                  (project["id"],)).fetchall():
                accounts[(row[0], str(row[1]).casefold())] = row[2]
            saved = discovery.save_candidates(db, project["id"], payload, accounts)
            for item in body.existing_accounts:
                row = db.execute("SELECT platform, account_id, url FROM accounts WHERE id=?", (item,)).fetchone()
                if row:
                    discovery.save_candidates(db, project["id"], [{
                        "platform": row[0], "account_id": row[1], "url": row[2],
                        "display_name": row[1], "followers": None, "language": None,
                        "creator_location": None, "audience_region": None,
                        "evidence_url": None, "evidence_title": None, "vertical": None,
                        "status": "existing", "source": "library_reuse", "discovered_at": today.isoformat(),
                        "confirmed": True}], accounts)
            result["saved"] = saved
            return result

    @api.get("/api/discovery/records")
    def discovery_records(project: int = Query(ge=1)):
        with store.connection(True) as db:
            store.purge(db)
            discovery.purge(db)
            return discovery.list_candidates(db, project)

    @api.get("/api/discovery/v14/config")
    def discovery_v14_config():
        return v14_discovery.config()

    @api.put("/api/discovery/v14/config")
    def discovery_v14_set_config(body: dict):
        return v14_discovery.set_config(bool((body or {}).get("experimental_ytdlp_enabled", False)))

    @api.post("/api/discovery/v14/keywords")
    def discovery_v14_keywords(body: dict):
        brief = str((body or {}).get("brief") or "").strip()
        return {"keywords": intelligent_discovery.brief_to_keywords(brief)}

    @api.post("/api/discovery/v14/jobs")
    def discovery_v14_start(body: dict):
        payload = body or {}
        return v14_discovery.start_job(
            brief=str(payload.get("brief") or ""),
            keywords=payload.get("keywords"),
            scale=str(payload.get("scale") or "standard"),
            project_id=payload.get("project_id"),
            mode=str(payload.get("mode") or "auto"),
            authorized_candidates=payload.get("authorized_candidates"),
        )

    @api.get("/api/discovery/v14/jobs/{job_id}")
    def discovery_v14_get(job_id: int):
        return v14_discovery.get_job(job_id)

    @api.post("/api/discovery/v14/jobs/{job_id}/control")
    def discovery_v14_control(job_id: int, body: dict):
        return v14_discovery.control_job(job_id, str((body or {}).get("action") or ""))

    @api.post("/api/discovery/v14/jobs/{job_id}/commit")
    def discovery_v14_commit(job_id: int, body: dict):
        payload = body or {}
        return v14_discovery.commit_candidates(
            job_id=job_id,
            candidate_ids=[int(x) for x in (payload.get("candidate_ids") or [])],
            project_id=payload.get("project_id"),
            source_name=str(payload.get("source_name") or ""),
            permission=str(payload.get("permission") or ""),
            operator=str(payload.get("operator") or ""),
            confirmed=bool(payload.get("confirmed", False)),
        )

    @api.get("/api/discovery/v14/jobs/{job_id}/export")
    def discovery_v14_export(job_id: int, approved: bool = True):
        body = v14_discovery.export_job_xlsx(job_id, only_approved=approved)
        name = f"CreatorHub-V1.4-Discovery-{job_id}.xlsx"
        return Response(
            body,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": 'attachment; filename="' + name + '"'},
        )

    @api.get("/api/imports/fields")
    def imports_fields():
        with store.connection() as db:
            templates = [{"name": row["name"], "mapping": load(row["settings"])}
                         for row in db.execute("SELECT * FROM intake_templates ORDER BY name")]
        return {"catalog": list(batch_import.CATALOG_BY_KEY.values()),
                "headers": batch_import.HEADERS, "templates": templates}

    @api.get("/api/imports/template")
    def imports_template(examples: int = 0):
        body = batch_import.build_template_xlsx(include_examples=bool(examples))
        name = "CreatorHub-Import-Template-Examples-V1.3.xlsx" if examples else "CreatorHub-Import-Template-V1.3.xlsx"
        return Response(body, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": 'attachment; filename="' + name + '"'})

    @api.post("/api/imports/upload")
    async def imports_upload(request: Request, filename: str = "", sheet: str = ""):
        if demo:
            raise ValueError("批量导入仅在业务工作区可用")
        raw = await request.body()
        parsed = batch_import.parse_uploaded_file(raw, filename, sheet)
        upload_id = batch_import.UPLOADS.put(parsed)
        mapping = batch_import.auto_mapping(parsed["headers"])
        with store.connection() as db:
            preview = batch_import.preview_batch(db, parsed, mapping)
        return {"upload_id": upload_id, "filename": parsed["filename"], "sheets": parsed["sheets"],
                "selected_sheet": parsed["selected_sheet"], "headers": parsed["headers"],
                "auto_mapping": mapping, "preview": preview}

    @api.post("/api/imports/preview")
    def imports_preview(body: batch_import.PreviewRequest):
        upload = batch_import.UPLOADS.get(body.upload_id)
        with store.connection() as db:
            return batch_import.preview_batch(db, upload, body.mapping, body.update_existing,
                                              body.preserve_manual_fields, body.default_currency)

    @api.post("/api/imports/commit")
    def imports_commit(body: batch_import.CommitRequest):
        if demo:
            raise ValueError("批量导入仅在业务工作区可用")
        upload = batch_import.UPLOADS.get(body.upload_id)
        return batch_import.commit_batch(store, store.connection, upload, body)

    @api.post("/api/imports/batch-links")
    def imports_batch_links(body: batch_import.BatchLinksRequest):
        if demo:
            raise ValueError("批量链接导入仅在业务工作区可用")
        return batch_import.batch_import_links(store, store.connection, body)

    @api.get("/api/freshness/settings")
    def get_freshness_settings():
        with store.connection(True) as db:
            return {"ttls": freshness.get_ttl_settings(db), "labels": freshness.FIELD_LABELS}

    @api.put("/api/freshness/settings")
    def put_freshness_settings(body: FreshnessUpdate):
        with store.connection(True) as db:
            return {"ttls": freshness.update_ttl_settings(db, body.ttls), "labels": freshness.FIELD_LABELS}

    @api.get("/api/accounts/{identifier}/freshness")
    def account_freshness(identifier: int):
        with store.connection(True) as db:
            account = store.account(db, identifier)
            if not account:
                raise KeyError("达人不存在或数据已过期")
            return freshness.compute_freshness(db, account)

    @api.post("/api/projects/{project}/prefilter")
    def prefilter_project_candidates(project: int):
        with store.connection(True) as db:
            store.purge(db)
            return refresh.prefilter_project(db, store, project)

    @api.post("/api/refresh/jobs")
    def start_refresh(body: RefreshRequest):
        effective_mode = "mock" if demo else body.mode
        return refresher.enqueue(
            body.account_ids, project_id=body.project_id, mode=effective_mode,
            fields=body.fields, force=body.force, budget_limit=body.budget_limit,
        )

    @api.get("/api/refresh/jobs/{job_id}")
    def get_refresh_job(job_id: int):
        return refresher.get_job(job_id)

    @api.post("/api/refresh/jobs/{job_id}/control")
    def control_refresh_job(job_id: int, body: RefreshControl):
        return refresher.control(job_id, body.action)

    @api.post("/api/refresh/manual-template")
    def download_manual_refresh_template(body: ManualTemplateRequest):
        with store.connection() as db:
            xlsx_bytes = refresh.export_manual_refresh_xlsx(db, store, body.account_ids)
        return Response(
            xlsx_bytes,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": 'attachment; filename="CreatorHub-Manual-Refresh-V1.3.xlsx"'},
        )

    api.include_router(update_api.router)

    @api.get("/", include_in_schema=False)
    def index():
        return FileResponse(ROOT / "frontend" / "index.html")

    return api

def runtime_app():
    read_local_env()
    demo = os.getenv("CREATORHUB_DEMO") == "1"
    provider = Demo() if demo else None
    path = Path(os.getenv("CREATORHUB_DB") or ROOT / "var" / ("demo.sqlite3" if demo else "creatorhub.sqlite3"))
    from .model_api import configured_service
    service = None if demo else configured_service(path.with_name(path.name + ".model.sqlite3"))
    return create_app(path, demo, provider, None if demo or service else configured_model(), model_service=service)






